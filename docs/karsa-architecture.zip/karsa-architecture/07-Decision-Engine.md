# Decision Engine

**Document ID:** KARSA-ARCH-007  
**Title:** Decision Engine Architecture  
**Version:** 1.0 (Draft)  
**Status:** Proposed Architecture  
**Author:** Karsa Architecture Team  
**Last Updated:** July 2026

---

# Purpose

The **Decision Engine** is the **brain of Karsa's orchestration layer**.

Its responsibility is to combine recommendations from multiple independent systems into **one deterministic trading decision**.

The Decision Engine **does not execute trades**.

It **does not calculate risk**.

It **does not place orders**.

Instead, it answers one question:

> **Should Karsa execute this trading opportunity?**

---

# Why a Decision Engine?

Today, trading decisions originate from multiple sources.

Examples:

- Technical Analysis
- AI Research
- Portfolio Allocation
- Funding Analysis
- Market Regime
- Risk Validation
- User Policies

Each component has valuable information.

However, there is currently **no central authority** responsible for combining these inputs.

Without a Decision Engine, business logic becomes scattered across services.

---

# Current Architecture

Today

```text
Analyzer

↓

Risk

↓

Execution
```

The Analyzer effectively decides the trade.

Risk either approves or rejects.

Execution executes.

While simple, this architecture becomes increasingly difficult to extend.

---

# Proposed Architecture

```text
                Trading Opportunity

                        │

                        ▼

                  Decision Engine

                        │

     ┌──────────────────┼────────────────────┐

     ▼                  ▼                    ▼

 Analyzer         Portfolio           AI Research

     ▼                  ▼                    ▼

 Funding          Market Regime          Policies

     ▼                  ▼                    ▼

        Recommendation Fusion

                 │

                 ▼

          Final Decision

                 │

                 ▼

           Risk Validation

                 │

                 ▼

            Execution
```

The Decision Engine becomes the **single authority** for recommendation fusion.

---

# Responsibilities

The Decision Engine owns:

- Recommendation aggregation
- Decision scoring
- Confidence calculation
- Conflict resolution
- Recommendation prioritization
- Decision explanation
- Decision events

It does **not** own:

- Risk calculations
- Position sizing
- Order execution
- Stop-loss calculations
- Portfolio persistence

---

# Design Principles

## Decision Before Execution

Execution should receive only two possible outcomes:

```
Approved

Rejected
```

Execution should never need to understand *why*.

---

## Recommendation, Not Commands

Every upstream component provides a recommendation.

Example

```
BUY BTC

Confidence = 0.82
```

The Decision Engine determines the final outcome.

---

## Deterministic Output

Inputs may include AI.

Outputs must remain deterministic.

Given the same inputs, the Decision Engine must always produce the same decision.

---

# Decision Pipeline

```text
Market Opportunity

↓

Collect Recommendations

↓

Normalize Scores

↓

Apply Policies

↓

Resolve Conflicts

↓

Calculate Confidence

↓

Generate Decision

↓

Publish Decision
```

Each stage has a single responsibility.

---

# Recommendation Sources

## Analyzer

Provides

- Technical signals
- Trend detection
- Breakout detection

Example

```json
{
  "action": "BUY",
  "confidence": 0.78
}
```

---

## Portfolio

Provides

- Allocation limits
- Sector exposure
- Position concentration

Example

```
Reduce AI Exposure
```

---

## Risk

Provides

- Maximum leverage
- Margin validation
- Exposure limits

Risk is **not** optional.

If Risk rejects,

the decision is rejected.

---

## Funding

Provides

- Funding rate
- Crowded trade detection

May reduce confidence.

---

## Market Regime

Provides

Examples

```
Trending

Ranging

Volatile

Risk-Off
```

Strategies may behave differently depending on regime.

---

## AI Research

Provides

- News interpretation
- Macro events
- Social sentiment
- Earnings analysis

This recommendation is advisory.

---

## Policy Engine

Provides

Business constraints.

Examples

```
No Trading Weekend

Maximum Daily Trades

Maximum Drawdown

Trading Freeze
```

Policies always override recommendations.

---

# Decision Flow

```text
Signal

↓

Analyzer

↓

Portfolio

↓

Funding

↓

Policy

↓

Decision Engine

↓

Risk

↓

Execution
```

Notice

Risk remains outside the Decision Engine.

Risk validates.

Decision recommends.

---

# Decision Aggregate

```text
Decision

├── DecisionId

├── Symbol

├── Strategy

├── Recommendation

├── Confidence

├── Contributors

├── Reason

├── Timestamp

├── Version

└── Metadata
```

The aggregate becomes part of the trade journal.

---

# Recommendation Model

Every recommendation follows the same structure.

```json
{
  "source": "Analyzer",
  "action": "BUY",
  "confidence": 0.82,
  "reason": "Breakout confirmed"
}
```

This enables plug-in contributors.

---

# Decision Actions

Possible outputs

```
BUY

SELL

HOLD

IGNORE

REJECT
```

Execution receives only BUY or SELL after Risk approval.

---

# Confidence Model

Confidence is calculated from multiple sources.

Example

```text
Analyzer

80%

Portfolio

90%

Funding

60%

AI

75%

↓

Weighted Confidence

78%
```

Weighting is configurable.

---

# Conflict Resolution

Example

Analyzer

```
BUY
```

Portfolio

```
SELL
```

Funding

```
Neutral
```

Decision Engine applies:

- priority
- confidence
- policies

before generating the final decision.

---

# Policy Integration

Policies are evaluated before approval.

Example

```text
BUY BTC

↓

Weekend Policy

↓

Trading Disabled

↓

Reject
```

The rejection reason is preserved.

---

# Decision States

```text
COLLECTING

↓

VALIDATING

↓

SCORING

↓

POLICY_CHECK

↓

APPROVED

↓

REJECTED
```

Each state is observable.

---

# Decision Events

Publishes

```
DecisionApproved

DecisionRejected

DecisionUpdated

ConfidenceCalculated
```

Subscribers

- Journal
- Metrics
- Dashboard
- Replay Engine

---

# Explainability

Every decision should answer:

- Why was this trade taken?
- Why was this trade rejected?
- Which component influenced the decision?
- Which policies applied?
- What confidence was calculated?

Example

```text
Decision

BUY BTC

Reason

Trend breakout confirmed.

Portfolio exposure acceptable.

Funding neutral.

Weekend policy passed.

Confidence

82%
```

This becomes part of the trade journal.

---

# Relationship with AI

AI contributes recommendations only.

Example

```text
Claude

↓

News Summary

↓

Decision Engine
```

AI never bypasses deterministic validation.

---

# Relationship with Risk

Decision Engine

↓

Recommend Trade

↓

Risk

↓

Approve

↓

Execution

Risk remains the final deterministic validator.

---

# Relationship with Position Manager

No direct interaction.

Position Manager manages positions after execution.

---

# Repository Design

Recommended package

```text
src/core/decision/

├── engine.py

├── recommendation.py

├── aggregator.py

├── scorer.py

├── policy_adapter.py

├── confidence.py

├── events.py

├── models.py

└── explainability.py
```

---

# Migration Strategy

## Phase 1

Analyzer continues current behavior.

Decision Engine disabled.

---

## Phase 2

Mirror Analyzer recommendations.

Compare outputs.

No production impact.

---

## Phase 3

Decision Engine becomes recommendation coordinator.

Analyzer simplified.

---

## Phase 4

Integrate Portfolio.

---

## Phase 5

Integrate Policies.

---

## Phase 6

Integrate AI Research.

---

## Phase 7

Decision Engine becomes production authority.

---

# Rollback Strategy

Feature flag

```text
decision_engine_enabled = false
```

Fallback

Analyzer feeds Risk directly.

---

# Testing Strategy

Decision Engine requires:

- Unit tests
- Recommendation tests
- Policy tests
- Historical replay
- Monte Carlo recommendation simulation

Every historical decision should remain reproducible.

---

# Success Criteria

Migration is complete when:

- Every trade recommendation passes through Decision Engine.
- Analyzer becomes a recommendation provider.
- AI contributes advisory input only.
- Policies are centrally enforced.
- Every decision is explainable.
- Historical decisions can be replayed.

---

# Risks

| Risk | Mitigation |
|------|------------|
| Over-engineering | Keep execution outside Decision Engine |
| AI bias | AI contributes advisory input only |
| Conflicting recommendations | Deterministic aggregation |
| Policy conflicts | Explicit priority rules |
| Increased latency | Keep aggregation lightweight |

---

# Future Extensions

Future recommendation providers may include:

- Macro Engine
- Correlation Engine
- Options Flow
- On-chain Analytics
- Whale Detection
- Economic Calendar
- Custom Strategies
- External Research APIs

The Decision Engine accepts new contributors without changing existing business logic.

---

# Architectural Benefits

The Decision Engine introduces a **decision orchestration layer** between analysis and execution.

Instead of allowing individual components to independently influence trading, every recommendation is evaluated through a single deterministic pipeline.

This architecture provides:

- Explainable decisions
- Policy-driven governance
- Plug-in recommendation providers
- AI integration without execution risk
- Centralized confidence scoring
- Consistent business rules
- Replayable decision history

Most importantly, the Decision Engine ensures that **thinking remains composable while execution remains deterministic**, reinforcing Karsa's core architectural principle of separating **Thinking** from **Doing**.