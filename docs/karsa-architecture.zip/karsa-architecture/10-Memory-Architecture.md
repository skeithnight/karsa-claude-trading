# Memory Architecture

**Document ID:** KARSA-ARCH-010  
**Title:** Memory Architecture  
**Version:** 1.0 (Draft)  
**Status:** Proposed Architecture  
**Author:** Karsa Architecture Team  
**Last Updated:** July 2026

---

# Purpose

The **Memory Architecture** enables Karsa to learn from its historical activities without placing Artificial Intelligence in the critical execution path.

Memory is **not** used to execute trades.

Memory exists to answer questions such as:

- What happened before?
- Why was this trade taken?
- What did we learn?
- What usually works?
- What mistakes keep repeating?

Memory transforms Karsa from a reactive trading system into a continuously improving trading platform.

---

# Why Memory?

Today, once a trade is completed:

```text
Trade

↓

Journal

↓

Database

↓

Done
```

The system stores data.

It does **not** accumulate knowledge.

Every AI analysis starts from scratch.

Historical experience is underutilized.

---

# Vision

Future

```text
Trade

↓

Journal

↓

Memory

↓

Knowledge

↓

Future Decisions
```

Instead of storing only historical records, Karsa stores **experience**.

---

# Architectural Principle

Memory is **read-only** from the perspective of the deterministic trading engine.

Execution never depends on memory.

Instead:

```text
Execution

↓

Trade Completed

↓

Memory Updated
```

Later

```text
Research

↓

Query Memory

↓

Generate Insight
```

Memory supports reasoning.

It never controls execution.

---

# Memory Categories

Memory is divided into independent domains.

```text
Memory

├── Trade Memory

├── Strategy Memory

├── Market Memory

├── Portfolio Memory

├── Risk Memory

├── Failure Memory

├── Research Memory

├── Knowledge Memory

└── User Memory
```

Each memory serves a different purpose.

---

# Trade Memory

Purpose

Remember every completed trade.

Stores:

- Entry
- Exit
- PnL
- Strategy
- Confidence
- Exit reason
- Holding time
- Market regime

Example

```text
Trade

BTCUSDT

Long

Entry

105,200

Exit

108,450

PnL

+3.1%

Exit

Trailing Stop
```

Questions it answers

- Which strategies perform best?
- Which exits produce higher returns?
- What mistakes repeat?

---

# Strategy Memory

Purpose

Track strategy performance over time.

Stores

- Win rate
- Profit factor
- Drawdown
- Average holding time
- Market suitability

Example

```text
Momentum Strategy

Trending

Win Rate

71%

Average R

2.3
```

Future

Adaptive strategy selection.

---

# Market Memory

Purpose

Remember historical market conditions.

Stores

- Volatility
- Funding
- Regime
- News
- Correlations
- Liquidity

Example

```text
BTC

Trending

High Volatility

Positive Funding

AI Sector Strong
```

Useful for similarity searches.

---

# Portfolio Memory

Purpose

Track portfolio evolution.

Stores

- Allocation history
- Sector exposure
- Drawdown history
- Cash utilization
- Correlation changes

Questions

- When was exposure highest?
- Which allocation performed best?

---

# Risk Memory

Purpose

Remember risk events.

Stores

- Margin calls
- High leverage
- Liquidation proximity
- Risk overrides
- Policy violations

Enables future audits.

---

# Failure Memory

Purpose

Learn from failures.

Examples

```text
Trade Rejected

Reason

Risk Limit
```

```text
Order Failed

Reason

Exchange Timeout
```

```text
Trailing Stop

Bug

Duplicate Exit
```

Questions

- Which failures happen most often?
- How frequently?

---

# Research Memory

Purpose

Store AI-generated knowledge.

Examples

- News summaries
- Macro analysis
- Earnings reports
- Sector research
- AI-generated insights

Avoid repeated analysis.

---

# Knowledge Memory

Purpose

Store durable facts.

Examples

```text
TAO

belongs to

AI Sector
```

```text
NVDA

strongly influences

AI tokens
```

Knowledge changes slowly.

---

# User Memory

Purpose

Remember user preferences.

Examples

- Preferred exchanges
- Risk profile
- Portfolio objectives
- Notification settings

Never influences deterministic execution directly.

---

# Memory Flow

```text
Trade Completed

↓

Journal

↓

Memory Manager

↓

Categorize

↓

Store

↓

Index
```

Future reasoning retrieves memory through queries.

---

# Memory Manager

The Memory Manager coordinates all writes.

Responsibilities

- Categorization
- Deduplication
- Indexing
- Retention
- Versioning

Memory writers never write directly.

---

# Memory Architecture

```text
                    Memory Manager

────────────────────────────────────────

Trade Memory

Strategy Memory

Market Memory

Portfolio Memory

Risk Memory

Failure Memory

Research Memory

Knowledge Memory

User Memory

────────────────────────────────────────

Storage

Vector Store

Relational DB

Object Storage
```

Different memories may use different storage technologies.

---

# Read Model vs Write Model

Writes

```text
Trade

↓

Memory Manager

↓

Persist
```

Reads

```text
Research Agent

↓

Memory Query

↓

Results
```

Execution never queries memory.

---

# Memory Schema

Example

```json
{
  "memoryId": "uuid",
  "type": "Trade",
  "timestamp": "...",
  "source": "ExitEngine",
  "tags": [
    "BTC",
    "Momentum",
    "Trending"
  ],
  "content": {}
}
```

Every memory is timestamped and versioned.

---

# Indexing

Memory should support:

- Symbol
- Strategy
- Time
- Tags
- Regime
- Sector
- Confidence

Future

Semantic vector search.

---

# Retention Policy

Not every memory lasts forever.

Examples

| Memory | Retention |
|---------|-----------|
| Trade | Permanent |
| Strategy | Permanent |
| Research | 90 Days |
| News | 30 Days |
| Market Snapshot | 1 Year |
| Logs | Configurable |

---

# Memory Query Examples

Example

```
Show losing BTC trades
during high funding.
```

Example

```
Find strategies
that outperform
during ranging markets.
```

Example

```
Summarize
last month's failures.
```

These become natural AI queries.

---

# Relationship with Journal

Journal

↓

Memory

The Journal records events.

Memory extracts knowledge.

---

# Relationship with Replay Engine

Replay

↓

Historical Events

↓

Memory

Replay reconstructs.

Memory summarizes.

---

# Relationship with Decision Engine

Decision Engine may query memory.

Example

```text
Similar Trade Found

↓

Historical Win Rate

↓

Recommendation
```

The Decision Engine remains deterministic.

Memory provides context only.

---

# Relationship with AI

AI reads memory.

AI writes research.

AI never modifies deterministic records.

---

# Repository Structure

Recommended package

```text
src/memory/

├── manager.py

├── repository.py

├── index.py

├── categorizer.py

├── retention.py

├── query.py

├── vector_store.py

├── embeddings.py

├── models.py

└── events.py
```

---

# Migration Strategy

## Phase 1

Trade Memory

Only.

---

## Phase 2

Strategy Memory.

---

## Phase 3

Failure Memory.

---

## Phase 4

Research Memory.

---

## Phase 5

Market Memory.

---

## Phase 6

Knowledge Memory.

---

## Phase 7

Semantic search.

---

# Rollback

Memory is append-only.

Disabling Memory Manager does not affect trading.

Existing records remain intact.

---

# Testing Strategy

Memory validation includes:

- Storage tests
- Retrieval tests
- Deduplication tests
- Retention tests
- Semantic search tests
- Replay integration tests

---

# Success Criteria

Memory implementation is complete when:

- Every completed trade generates Trade Memory.
- Research results are reusable.
- Similar historical situations can be retrieved.
- AI no longer repeats identical analysis.
- Memory remains isolated from deterministic execution.
- Replay and Memory produce consistent historical narratives.

---

# Risks

| Risk | Mitigation |
|------|------------|
| Memory growth | Retention policies |
| Duplicate knowledge | Deduplication |
| Stale research | Expiration rules |
| AI hallucination | Separate facts from opinions |
| Execution dependency | Strict read-only boundary |

---

# Future Evolution

Future capabilities include:

- Vector similarity search
- Retrieval-Augmented Generation (RAG)
- Cross-market reasoning
- Automatic pattern discovery
- Strategy recommendation
- Performance attribution
- Lessons learned generation
- Self-improving research reports

These features build on the same memory foundation without altering the deterministic trading engine.

---

# Architectural Benefits

The Memory Architecture gives Karsa **long-term institutional memory**.

Rather than treating every market event as independent, Karsa accumulates experience across trades, strategies, market conditions, failures, and research.

This enables:

- Historical reasoning
- Smarter research
- Better journaling
- Faster analysis
- Explainable AI
- Knowledge reuse
- Continuous learning

Most importantly, Memory preserves Karsa's core architectural principle:

> **Execution depends on deterministic rules.  
> Intelligence depends on accumulated experience.**

By keeping Memory outside the execution path, Karsa gains the benefits of learning without sacrificing predictability, auditability, or production safety.