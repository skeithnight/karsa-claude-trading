# Workflow Engine

**Document ID:** KARSA-ARCH-009  
**Title:** Workflow Engine Architecture  
**Version:** 1.0 (Draft)  
**Status:** Proposed Architecture  
**Author:** Karsa Architecture Team  
**Last Updated:** July 2026

---

# Purpose

The **Workflow Engine** is responsible for orchestrating **long-running business processes** within Karsa.

Unlike the Event Bus, which distributes discrete business events, or the Agent Runtime, which executes autonomous reasoning tasks, the Workflow Engine coordinates **stateful business processes** that span multiple events, multiple services, and potentially multiple days.

It answers the question:

> **"What should happen next?"**

rather than:

> **"Who should react to this event?"**

---

# Why a Workflow Engine?

Most trading systems focus on immediate execution.

However, trading is fundamentally a **long-running process**.

Examples include:

- Waiting for an order to fill
- Waiting until Break Even is reached
- Waiting for Trailing Stop activation
- Waiting for funding rate changes
- Waiting for macroeconomic events
- Waiting for a portfolio rebalance window

Today these behaviors are implemented through:

- background schedulers
- polling loops
- timers
- conditional checks

These approaches work, but they scatter business processes across multiple services.

---

# Current Architecture

Current runtime

```text
Scheduler

↓

Analyzer

↓

Risk

↓

Execution

↓

Position Manager

↓

Trailing Stop

↓

Stop Loss
```

Every component owns part of the business process.

No single component understands the complete lifecycle.

---

# Proposed Architecture

```text
                   Workflow Engine

                           │

          ┌────────────────┼────────────────┐

          ▼                ▼                ▼

 Trading Workflow   Portfolio Workflow   Research Workflow

          │                │                │

          ▼                ▼                ▼

     Event Bus      Agent Runtime     Deterministic Services
```

The Workflow Engine coordinates.

Other services execute.

---

# Responsibilities

The Workflow Engine owns:

- Workflow lifecycle
- Workflow state
- Step orchestration
- Waiting conditions
- Checkpointing
- Resume
- Timeouts
- Compensation
- Retry policies
- Workflow history

It does **not** own:

- Trading logic
- Risk calculations
- Order execution
- Position state
- AI reasoning

---

# Core Principles

## Workflows are Business Processes

A workflow represents an end-to-end business objective.

Examples:

- Execute Trade
- Review Portfolio
- Daily Research
- Weekly Rebalance

---

## Services Execute Steps

The Workflow Engine never performs business logic.

Instead it coordinates services.

Example

```text
Workflow

↓

Position Manager

↓

Execution

↓

Exit Engine
```

---

## Durable Execution

A workflow must survive:

- application restart
- process crash
- exchange disconnect
- server reboot

A workflow resumes from its last checkpoint.

---

# Workflow Lifecycle

```text
CREATED

↓

STARTED

↓

RUNNING

↓

WAITING

↓

RESUMED

↓

COMPLETED
```

Failure path

```text
RUNNING

↓

FAILED

↓

RETRYING

↓

RUNNING
```

Cancellation path

```text
RUNNING

↓

CANCELLED
```

---

# Workflow Types

---

## Trade Workflow

Purpose

Manage an entire trade lifecycle.

Example

```text
Signal

↓

Risk

↓

Execution

↓

Wait Fill

↓

Position Open

↓

Wait Break Even

↓

Wait Partial Exit

↓

Wait Trailing

↓

Exit

↓

Journal

↓

Complete
```

---

## Portfolio Workflow

Example

```text
Start Review

↓

Analyze Portfolio

↓

Check Allocation

↓

Generate Advice

↓

Notify User
```

---

## Research Workflow

Example

```text
Start

↓

Collect News

↓

Analyze Market

↓

Generate Summary

↓

Store Memory

↓

Publish Report
```

---

## Maintenance Workflow

Example

```text
Synchronize Exchange

↓

Reconcile Positions

↓

Repair

↓

Notify
```

---

# Workflow State Machine

```text
          CREATED

              │

              ▼

          STARTED

              │

              ▼

          RUNNING

              │

     ┌────────┼─────────┐

     ▼                  ▼

 WAITING            FAILED

     │                  │

     ▼                  ▼

 RESUMED           RETRYING

     │                  │

     └──────────┬───────┘

                ▼

            COMPLETED
```

---

# Workflow Components

```text
Workflow Engine

├── Workflow Registry

├── Workflow Scheduler

├── State Store

├── Checkpoint Manager

├── Timeout Manager

├── Retry Manager

├── Compensation Handler

├── Workflow Dispatcher

├── Event Listener

└── Metrics
```

---

# Workflow Definition

Every workflow consists of steps.

Example

```yaml
TradeWorkflow

steps:

- Analyze

- Validate

- Execute

- WaitFill

- OpenPosition

- WaitBreakEven

- WaitTrailing

- Close

- Journal
```

Each step is independently executable.

---

# Waiting Conditions

A distinguishing capability of the Workflow Engine is waiting.

Examples

```text
Wait Until

Order Filled
```

```text
Wait Until

Price > Break Even
```

```text
Wait Until

Funding Update
```

```text
Wait Until

Tomorrow 09:00 UTC
```

No polling loops are required.

The workflow resumes when the condition becomes true.

---

# Checkpointing

Every completed step is persisted.

Example

```text
Trade Workflow

↓

Step 5 Completed

↓

Checkpoint Saved

↓

Crash

↓

Restart

↓

Resume Step 6
```

No completed work is repeated.

---

# Compensation

Some workflows require rollback.

Example

```text
Order Submitted

↓

Database Failed

↓

Compensation

↓

Cancel Order
```

Compensation is workflow-specific.

---

# Retry Policy

Every step defines:

- maximum retries
- retry delay
- exponential backoff

Example

```text
Journal Generation

↓

LLM Timeout

↓

Retry

↓

Success
```

---

# Timeout Policy

Each workflow defines:

- workflow timeout
- step timeout

Example

```text
Order Fill

Timeout

10 Minutes
```

```text
Research Workflow

Timeout

30 Minutes
```

---

# Event Integration

Workflows consume business events.

Example

```
OrderFilled

↓

Resume Workflow
```

```
PositionClosed

↓

Complete Workflow
```

The Event Bus becomes the workflow trigger.

---

# Agent Runtime Integration

Workflow

↓

Execute Research

↓

Agent Runtime

↓

Research Agent

↓

Return Result

↓

Continue Workflow

The Workflow Engine orchestrates.

The Agent Runtime executes.

---

# Position Manager Integration

Workflow

↓

Open Position

↓

Position Manager

↓

PositionOpened

↓

Resume Workflow

The workflow never modifies position state directly.

---

# Exit Engine Integration

Workflow

↓

Wait Trailing

↓

Exit Engine

↓

Exit Triggered

↓

Resume Workflow

---

# Repository Structure

Recommended package

```text
src/workflow/

├── engine.py

├── workflow.py

├── registry.py

├── dispatcher.py

├── scheduler.py

├── checkpoint.py

├── timeout.py

├── retry.py

├── compensation.py

├── events.py

├── models.py

└── persistence.py
```

---

# Example Workflow

Trade Lifecycle

```text
SignalDetected

↓

Create Workflow

↓

Validate Risk

↓

Execute Trade

↓

Wait Order Filled

↓

Open Position

↓

Wait Break Even

↓

Activate Trailing

↓

Wait Exit

↓

Generate Journal

↓

Archive

↓

Complete
```

Every stage is durable.

---

# Persistence

Workflow persistence includes:

- current step
- completed steps
- timestamps
- retries
- metadata
- history

Persistence enables recovery after failure.

---

# Recovery

On restart

```text
Application Start

↓

Load Active Workflows

↓

Resume Waiting Steps

↓

Continue Processing
```

No workflow restarts from the beginning.

---

# Migration Strategy

## Phase 1

No Workflow Engine.

---

## Phase 2

Introduce Workflow Registry.

Observation only.

---

## Phase 3

Implement Research Workflow.

No production trading impact.

---

## Phase 4

Implement Journal Workflow.

---

## Phase 5

Implement Trade Workflow.

Shadow mode only.

---

## Phase 6

Trade Workflow becomes production coordinator.

---

# Rollback Strategy

Feature flag

```text
workflow_engine_enabled = false
```

Existing schedulers continue operating.

No workflow data is lost.

---

# Testing Strategy

Workflow testing includes:

- Unit tests
- Integration tests
- Failure injection
- Timeout simulation
- Replay tests
- Recovery tests

Every workflow must be restart-safe.

---

# Success Criteria

The Workflow Engine migration is complete when:

- Long-running business processes become explicit workflows.
- Waiting conditions no longer rely on polling loops.
- Every workflow is restartable.
- Workflow state survives process restarts.
- Trade lifecycle can be replayed from checkpoints.
- Existing deterministic services remain unchanged.

---

# Risks

| Risk | Mitigation |
|------|------------|
| Over-engineering | Start with non-critical workflows (Research, Journal) |
| Workflow explosion | Only model long-running business processes |
| State corruption | Durable checkpointing |
| Infinite retries | Configurable retry limits |
| Runtime overhead | Lazy workflow activation |

---

# Future Evolution

Future workflow types may include:

- Multi-leg strategy execution
- Dollar-cost averaging campaigns
- Portfolio rebalancing
- Options expiration management
- AI research pipelines
- Economic event monitoring
- Exchange failover workflows
- Disaster recovery workflows

The Workflow Engine provides a common orchestration framework for all of these without modifying the underlying business services.

---

# Relationship with Other Components

| Component | Responsibility |
|-----------|----------------|
| Event Bus | Distributes business events |
| Agent Runtime | Executes autonomous reasoning tasks |
| Workflow Engine | Orchestrates long-running business processes |
| Decision Engine | Produces trading recommendations |
| Position Manager | Owns position state |
| Exit Engine | Owns exit decisions |
| Execution | Places orders |
| OMS | Owns order lifecycle |

These responsibilities are intentionally non-overlapping.

---

# Architectural Benefits

The Workflow Engine transforms Karsa from an **event-reactive trading system** into a **process-aware trading platform**.

Instead of scattering long-running business logic across schedulers, timers, and service callbacks, workflows become explicit, durable, and observable.

This architecture provides:

- Durable execution
- Restart-safe business processes
- Explicit orchestration
- Simplified long-running logic
- Workflow history
- Checkpoint-based recovery
- Better observability
- Replay compatibility

Most importantly, the Workflow Engine enables Karsa to model trading as a **business process** rather than a sequence of independent function calls. It becomes the orchestration layer that coordinates deterministic services and AI agents while preserving production safety, auditability, and incremental evolution.