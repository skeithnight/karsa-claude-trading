# New Profit Enhancement Ideas

I looked at the remaining untouched parts of the system — memory, position scaling, funding carry, and the partial exit structure. Here are 4 distinct ideas, each with a different profit mechanism.

---

## Idea A — Activate the Trade Memory Feedback Loop
**Profit mechanism**: The LLM learns from its own wins and losses → win rate improves over time

### What exists (but is broken)
The `memory_retriever.py` already retrieves past trades using pgvector similarity search and injects them into the LLM prompt:
```python
PAST SIMILAR TRADES (learn from these):
- ✅ LONG BTCUSDT in TREND_BULL | Result: WIN (+2.3%) | Exit: profit_lock_1r | Hold: 4.2h
- ❌ LONG SOLUSDT in MEAN_REVERSION | Result: LOSS (-1.1%) | Exit: stop_loss | Hold: 1.3h
```

**The problem**: `store_trade_memory()` exists but is **never called**. There is no code that writes to `trade_memory` after a trade closes. The pgvector table is empty. The LLM reads past trades — but there are no past trades to read.

### The Fix (2 files)
1. **In `position_manager.py` — after `execute_partial_exit` succeeds**: call `store_trade_memory(...)` with the ticker, regime, outcome (WIN/LOSS), PnL%, and reasoning from the position's `signal_reasoning` field.
2. **In the trade close path (SOR or `_job_close_position`)**: same call on full close.

**Impact**: After 10-20 trades, the LLM starts seeing what setups win/lose on each coin. It will naturally start avoiding patterns that have historically failed. This is a compounding edge — gets stronger every day.

---

## Idea B — Scale Into Winners (Pyramiding)
**Profit mechanism**: On confirmed trend breakouts, add to a winning position → amplifies average winner

### Current state
The `PARTIAL_EXIT_TARGETS` only scales **out**:
```python
PARTIAL_EXIT_TARGETS = [
    {"r_multiple": 1.0, "exit_pct": 30, "reason": "partial_1r"},
    {"r_multiple": 2.0, "exit_pct": 30, "reason": "partial_2r"},
]
```
There is no mechanism to add to a winning position.

### The Idea
Add a **scale-in** check in `PositionManager`. When a position reaches `+1R` and:
- The 4H trend is still `bullish` (EMA confirmation)
- The regime is `FULL_TREND_ALIGNMENT`
- No second position exists in the same ticker

→ Add **25% more size** at the current price, with a stop at entry (the original stop is already profitable). This "free money" add-on costs nothing if it fails (stop is at entry = breakeven on the add).

```python
SCALE_IN_TARGETS = [
    {"r_multiple": 1.0, "add_pct": 25, "reason": "pyramid_1r",
     "conditions": ["regime==FULL_TREND_ALIGNMENT", "trend==bullish"]},
]
```

> [!IMPORTANT]
> This must be gated strictly by the Conservative profile's max_open_positions (2). If we're already at 2 positions, no pyramiding. The add-on still counts against the position slot.

**Impact**: Converts a standard +2R win into a +2.5R win on confirmed trend days. Over 50 trades, meaningful difference.

---

## Idea C — Enable the Funding Capture Strategy
**Profit mechanism**: Earns passive income (every 8 hours) from extremely crowded positions, independent of price direction

### What exists (dormant)
`FundingCaptureStrategy` in `src/strategies/funding_capture.py` is fully built:
- Scans 13 major pairs every 4 hours
- Triggers at >15% annualized funding rate
- Takes the **opposite side** of the crowd to earn the funding payment
- Completely independent of the momentum scanner

**The problem**: It is never called anywhere. The orchestrator/scheduler has no reference to it.

### The Fix
Wire `FundingCaptureStrategy.scan()` into the ASM scan loop (or as a separate 4H scheduled job). Add a simple check in `_run_loop`:

```python
# Every 4th iteration (4h), run funding scan
if iteration_count % 16 == 0:  # 16 x 15min = 4h
    funding_signals = await funding_strategy.scan(open_positions)
    for sig in funding_signals:
        await self._execute_signal(sig, chat_id)
```

**Why this is pure profit**: Funding at 15% annualized = +0.041% per 8-hour epoch. On a $5 position (Bybit minimum), that's ~$0.002 per epoch. Small per trade, but it compounds. More importantly, **extreme funding (>30%) is a contrarian momentum signal** — the market is dangerously crowded to one side and a reversal is very likely. We earn funding AND benefit from the reversion.

> [!NOTE]
> The funding strategy has its own separate $1 risk cap because it uses 2x leverage max, not the momentum book's leverage. These are carry trades, not directional bets.

---

## Idea D — Rebalance Partial Exit Ratios (Exit Less at 1R, More at 2R+)
**Profit mechanism**: Keeps more position size in the big winners → average win increases

### Current state
```python
PARTIAL_EXIT_TARGETS = [
    {"r_multiple": 1.0, "exit_pct": 30},  # take 30% off at +1R
    {"r_multiple": 2.0, "exit_pct": 30},  # take 30% off at +2R
    # 40% remains with trailing stop
]
```
Problem: by exiting 30% at +1R, you heavily reduce your position size right when you need it most — at the start of a breakout. If the trade goes to +5R, you're only riding 40% of the original size for the last +3R of the move.

### The Fix
Flip the ratio — take **less early, more mid-way**:
```python
PARTIAL_EXIT_TARGETS = [
    {"r_multiple": 1.0, "exit_pct": 15},  # take only 15% at +1R (lock some profit)
    {"r_multiple": 2.0, "exit_pct": 35},  # take 35% at +2R
    # 50% remains for the full runner with trailing stop
]
```
This means:
- At +1R: secure a tiny profit, move stop to breakeven (already implemented)
- At +2R: take a meaningful chunk
- Runner: 50% of the position catches the full move

**Impact**: On trades that go to +3R or +4R (the big winners), you earn significantly more. On trades that top out at +1.5R, the difference is minimal (you took 15% vs 30% — small).

---

## Summary Comparison

| Idea | Mechanism | Complexity | Estimated Impact |
|---|---|---|---|
| **A — Trade Memory** | LLM learns from history → win rate grows | Low (2 function calls) | High (compounds forever) |
| **B — Pyramiding** | Add to winners in confirmed trend | Medium (new logic) | Medium (regime-dependent) |
| **C — Funding Capture** | Earn passive 8h payments | Low (wire existing code) | Medium (steady, low-risk) |
| **D — Partial Exit Ratio** | Keep more size in big winners | Very Low (change 2 numbers) | Medium |

> [!TIP]
> **Recommended order**: D first (trivial, immediate), then A (compounding, no downside), then C (passive income), then B (most complex, highest ceiling).

Which would you like to build?
