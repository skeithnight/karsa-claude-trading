# Observability Architecture

**Document ID:** KARSA-ARCH-021  
**Title:** Observability Architecture  
**Version:** 1.0 (Draft)  
**Status:** Proposed Architecture  
**Author:** Karsa Architecture Team  
**Last Updated:** July 2026

---

# Purpose

This document defines the **Observability Architecture** for Karsa.

Unlike traditional monitoring, observability enables engineers to understand not only **what happened**, but also:

- Why did it happen?
- Which component caused it?
- Which workflow was affected?
- What was the business impact?
- Can it be replayed?

Observability is a first-class architectural concern because Karsa operates as a **production algorithmic trading platform** where every decision and every dollar must be explainable.

---

# Objectives

The observability platform must provide:

- Real-time system health
- Trading visibility
- Distributed tracing
- Event monitoring
- Replay integration
- Performance metrics
- Business metrics
- Incident investigation
- Production debugging

---

# Observability Philosophy

Traditional monitoring asks:

> Is the server alive?

Observability asks:

> Why did this trade happen?

Karsa prioritizes **business observability** over infrastructure monitoring.

---

# Pillars of Observability

```text
Observability

├── Metrics

├── Logs

├── Traces

├── Events

├── Health

├── Replay

├── Audit

└── Business KPIs
```

Every production issue should be diagnosable using these pillars.

---

# Architecture Overview

```text
                     Karsa Runtime

────────────────────────────────────────────

Decision Engine

Position Manager

Exit Engine

Workflow Engine

Agent Runtime

OMS

Policy Engine

────────────────────────────────────────────

        Metrics

        Logs

        Traces

        Events

────────────────────────────────────────────

     OpenTelemetry Collectors

────────────────────────────────────────────

 Prometheus

 Loki

 Tempo

 Event Store

 PostgreSQL

────────────────────────────────────────────

             Grafana
```

---

# Metrics

Metrics answer:

> **How healthy is the system?**

Examples

- CPU
- Memory
- Latency
- Event throughput
- Trade count
- Error rate

Metrics are numeric and aggregated.

---

# Logging

Logs answer:

> **What happened?**

Examples

```
Position Opened

Decision Rejected

Workflow Failed

Order Filled
```

Logs are human-readable.

Logs are not the source of truth.

---

# Distributed Tracing

Tracing answers:

> **Where was time spent?**

Example

```text
SignalDetected

↓

Decision Engine

12 ms

↓

Policy Engine

2 ms

↓

Risk Engine

5 ms

↓

Execution

18 ms

↓

OMS

145 ms

↓

Exchange
```

Tracing identifies bottlenecks.

---

# Business Events

Events answer:

> **Which business fact occurred?**

Examples

```
PositionOpened

TradeCompleted

PolicyRejected

WorkflowCompleted
```

Business events integrate with Replay.

---

# Replay

Replay answers:

> **Can we reproduce this?**

Replay reconstructs:

- trades
- workflows
- decisions
- positions

Replay complements metrics and logs.

---

# Audit Trail

Audit answers:

> **Who changed what and when?**

Examples

```
Policy Updated

↓

Admin

↓

09:15 UTC
```

Every administrative action is auditable.

---

# Monitoring Stack

Recommended stack

| Layer | Technology |
|--------|------------|
| Metrics | Prometheus |
| Logs | Loki |
| Traces | Tempo |
| Dashboards | Grafana |
| Instrumentation | OpenTelemetry |
| Alerting | Alertmanager |
| Replay | Event Store |

These technologies are interchangeable.

---

# OpenTelemetry

Every component should expose:

- Metrics
- Logs
- Traces

through OpenTelemetry.

Example

```text
Decision Engine

↓

OTel SDK

↓

Collector

↓

Prometheus

↓

Grafana
```

---

# Metrics Categories

```text
Metrics

├── Infrastructure

├── Runtime

├── Trading

├── Business

├── AI

├── Workflow

├── Replay

└── Security
```

---

# Infrastructure Metrics

Examples

- CPU
- Memory
- Disk
- Network
- Database Connections
- Redis Memory

---

# Runtime Metrics

Examples

- Requests/sec
- Event throughput
- Queue depth
- Thread count
- Active workflows
- Active agents

---

# Trading Metrics

Examples

- Orders Submitted
- Orders Filled
- Position Count
- Win Rate
- Drawdown
- Daily PnL
- Exposure
- Slippage

These are business-critical.

---

# Exit Metrics

Examples

```
Break Even Count

Trailing Count

Partial Exit Count

SL Trigger Count

Average R

Average Hold Time
```

---

# Decision Metrics

Examples

```
Signals

↓

Approved

↓

Rejected

↓

Ignored
```

Confidence distribution

Recommendation sources

Decision latency

---

# Position Metrics

Examples

```
Open Positions

Closed Positions

Average Duration

Largest Position

Exposure
```

---

# OMS Metrics

Examples

```
Order Latency

Fill Rate

Rejection Rate

Cancellation Rate

Partial Fill Rate
```

---

# Workflow Metrics

Examples

```
Workflow Started

Completed

Failed

Retry Count

Average Duration
```

---

# Agent Runtime Metrics

Examples

```
Tasks Executed

Retries

Timeouts

Failures

Average Runtime
```

---

# AI Metrics

Examples

```
Prompt Count

Latency

Tokens

Model Usage

Retry Count

Failure Rate
```

AI metrics must never be mixed with trading metrics.

---

# Replay Metrics

Examples

```
Replay Count

Replay Duration

Replay Accuracy

Replay Failures
```

---

# Security Metrics

Examples

```
Login Failures

Permission Denied

API Key Usage

Policy Violations
```

---

# Structured Logging

Every log should contain

```json
{
  "timestamp": "",
  "level": "INFO",
  "service": "DecisionEngine",
  "requestId": "",
  "correlationId": "",
  "tradeId": "",
  "workflowId": "",
  "message": ""
}
```

No free-form logs.

---

# Correlation IDs

Every request receives:

```
Correlation ID
```

Example

```text
SignalDetected

↓

Decision

↓

Risk

↓

Execution

↓

PositionOpened
```

Same correlation ID.

This enables distributed tracing.

---

# Trace IDs

Every distributed operation receives:

```
Trace ID
```

Trace IDs allow complete request visualization across services.

---

# Logging Levels

Supported levels

```
TRACE

DEBUG

INFO

WARN

ERROR

FATAL
```

Production default

```
INFO
```

---

# Business Dashboards

Dashboard categories

```text
Trading Dashboard

Operations Dashboard

Infrastructure Dashboard

Replay Dashboard

AI Dashboard

Executive Dashboard
```

---

# Trading Dashboard

Displays

- Open Positions
- PnL
- Exposure
- Win Rate
- Active Orders
- Drawdown
- Current Risk

---

# Operations Dashboard

Displays

- Service Health
- Queue Size
- Redis
- Database
- Exchange Status

---

# Replay Dashboard

Displays

- Replay History
- Differences
- Failed Replays
- Historical Comparison

---

# AI Dashboard

Displays

- Model Usage
- Prompt Volume
- Response Time
- Failure Rate

---

# Alerting

Alerts should be categorized.

```text
P0

Capital Risk
```

```text
P1

Trading Failure
```

```text
P2

Component Failure
```

```text
P3

Performance
```

```text
P4

Informational
```

---

# Critical Alerts

Immediate notification

- Duplicate Position
- Exchange Disconnect
- Database Offline
- Negative Balance
- Capital Mismatch
- Kill Switch
- Replay Failure

---

# Event Monitoring

Monitor

```
Events/sec

Queue Length

Subscriber Lag

Failed Deliveries
```

Event Bus health is critical.

---

# SLOs (Service Level Objectives)

| Component | Target |
|------------|---------|
| Decision Engine | < 100 ms |
| Risk Engine | < 50 ms |
| OMS | < 500 ms |
| Position Manager | < 100 ms |
| Event Bus | < 20 ms |
| Replay Engine | < 5 sec |
| Dashboard API | < 200 ms |

---

# SLIs (Service Level Indicators)

Examples

- Availability
- Latency
- Error Rate
- Throughput
- Replay Success
- Fill Success

---

# Error Budget

Examples

| Service | Availability |
|-----------|--------------|
| Trading Runtime | 99.99% |
| Dashboard | 99.5% |
| Replay | 99% |
| AI Runtime | Best Effort |

Trading runtime has the strictest SLA.

---

# Health Checks

Every service exposes

```text
/health

/readiness

/liveness
```

Health should validate

- database
- Redis
- exchange
- dependencies

---

# Incident Workflow

```text
Alert

↓

Dashboard

↓

Logs

↓

Trace

↓

Replay

↓

Root Cause

↓

Post Mortem
```

Replay becomes part of incident response.

---

# Observability Maturity

Stage 1

```
Logs
```

↓

Stage 2

```
Logs + Metrics
```

↓

Stage 3

```
Logs + Metrics + Traces
```

↓

Stage 4

```
Business Events
```

↓

Stage 5

```
Replay
```

↓

Stage 6

```
AI-assisted Incident Analysis
```

---

# Observability Ownership

| Area | Owner |
|------|-------|
| Infrastructure Metrics | DevOps |
| Business Metrics | Trading Platform |
| AI Metrics | AI Platform |
| Replay | Platform Engineering |
| Dashboards | Platform Engineering |
| Alerts | Operations |
| Audit | Security |

---

# Production Readiness Checklist

Before deployment:

- Metrics exported
- Structured logging enabled
- OpenTelemetry instrumentation complete
- Tracing validated
- Health checks implemented
- Dashboards created
- Alerts configured
- Replay integrated
- Correlation IDs propagated
- Documentation updated

---

# Success Metrics

The observability platform is successful when engineers can answer the following within minutes:

- Why was this trade executed?
- Why was it rejected?
- Which component failed?
- Which workflow is blocked?
- Which policy prevented execution?
- What changed between releases?
- Can the issue be replayed?
- Is capital currently at risk?

If these questions cannot be answered quickly, observability is incomplete.

---

# Future Evolution

Future enhancements include:

- AI-assisted anomaly detection
- Predictive infrastructure monitoring
- Automatic root cause analysis
- Trade performance heatmaps
- Portfolio observability
- Real-time dependency graphs
- Distributed event visualization
- Intelligent alert suppression

These capabilities build on the same observability foundation.

---

# Summary

Observability is more than monitoring infrastructure—it is the ability to understand the behavior of an entire trading platform.

Karsa combines:

- Metrics for health
- Logs for events
- Traces for execution flow
- Business Events for domain activity
- Replay for deterministic reconstruction
- Audit Trails for governance

Together, these capabilities provide complete visibility into both the technical and business behavior of the platform.

This architecture enables engineers to diagnose production issues, validate architectural changes, investigate incidents, and continuously improve Karsa while preserving deterministic execution, operational safety, and financial integrity.