# Position Manager

**Document ID:** KARSA-ARCH-005  
**Title:** Position Manager Architecture  
**Version:** 1.0 (Draft)  
**Status:** Proposed Architecture  
**Author:** Karsa Architecture Team  
**Last Updated:** July 2026

---

# Purpose

This document defines the **Position Manager**, the single authoritative owner of all trading position state within Karsa.

The Position Manager is **the most important architectural change** proposed for the platform because it establishes a **Single Source of Truth (SSOT)** for every position.

It does **not** replace OMS, Risk, or Exit Engine.

Instead, it coordinates them.

---

# Why Position Manager?

During the architecture audit, the largest structural issue identified was **fragmented position ownership**.

Today, multiple components can modify the same position independently.

Current contributors include:

- Execution
- Position Manager
- Position Sync
- Trailing Stop
- Profit Lock
- Stop Loss Engine
- Manual Close
- Exchange Synchronization

While each component is correct individually, together they create multiple writers to the same business entity.

---

# Current Architecture

Today

```text
                   Position
                      ▲
                      │
      ┌───────────────┼────────────────┐
      │               │                │
      ▼               ▼                ▼
 Execution     Position Sync     Trailing Stop
      │               │                │
      ▼               ▼                ▼
 Profit Lock      SL Engine      Manual Close
```

Problems

- Multiple state mutations
- Difficult reconciliation
- Race conditions
- Complex debugging
- Hidden side effects

---

# Proposed Architecture

Future

```text
                   Position
                      ▲
                      │
             Position Manager
                      ▲
      ┌───────────────┼────────────────┐
      │               │                │
      ▼               ▼                ▼
 Execution      Exit Engine      Exchange Sync
                      │
                Publish Events
```

Only **Position Manager** is allowed to mutate position state.

Everyone else submits requests or publishes events.

---

# Responsibilities

The Position Manager owns:

- Position lifecycle
- Position state
- Position persistence
- Position reconciliation
- Position updates
- Position events

It explicitly does **not** own:

- Risk calculations
- Stop-loss strategy
- Trailing algorithms
- Order execution
- Portfolio allocation

Those belong to their respective domains.

---

# Design Principles

## 1. Single Writer Principle

There must be exactly **one writer** to position state.

Bad

```text
Trailing Stop

↓

Update Position
```

Good

```text
Trailing Stop

↓

Position Update Request

↓

Position Manager

↓

Update Position
```

---

## 2. Position Is a Business Aggregate

A Position is not merely a database row.

It is an aggregate composed of:

- Entry
- Size
- Average Price
- Leverage
- Stop Loss
- Trailing Stop
- Exit Status
- PnL
- Lifecycle

All updates must preserve aggregate consistency.

---

## 3. Event Driven

Every successful state transition publishes a business event.

Example

```
PositionOpened

PositionUpdated

BreakEvenActivated

PositionClosed
```

Position Manager never calls Telegram directly.

---

## Position Lifecycle

The Position Manager owns the complete lifecycle.

```text
NEW

↓

OPENING

↓

OPEN

↓

BREAK_EVEN

↓

PARTIAL_EXIT

↓

TRAILING

↓

EXITING

↓

CLOSED
```

Every state transition is validated.

---

# Position Aggregate

Conceptually

```text
Position

├── PositionId

├── Symbol

├── Side

├── Entry Price

├── Current Size

├── Average Entry

├── Stop Loss

├── Trailing Stop

├── Realized PnL

├── Unrealized PnL

├── Current State

├── Created At

├── Updated At
```

Future versions may include:

- Strategy ID
- Signal ID
- Workflow ID
- Journal ID

---

# State Machine

```text
             NEW
              │
              ▼
          OPENING
              │
              ▼
            OPEN
              │
     ┌────────┼────────┐
     ▼        ▼        ▼
BREAK_EVEN PARTIAL TRAILING
     │        │        │
     └────────┼────────┘
              ▼
          EXITING
              │
              ▼
           CLOSED
```

Every transition is deterministic.

---

# Position Update Flow

Current

```text
Trailing Stop

↓

Update Database
```

Future

```text
Trailing Stop

↓

Request Update

↓

Position Manager

↓

Validate

↓

Persist

↓

Publish Event
```

---

# Position Commands

Components never modify positions directly.

Instead they issue commands.

Examples

```
OpenPosition

UpdateStopLoss

UpdateTrailing

ReducePosition

ClosePosition

SynchronizePosition
```

Commands represent intent.

The Position Manager decides whether the transition is valid.

---

# Position Events

The Position Manager publishes:

```
PositionOpened

PositionUpdated

PositionReduced

BreakEvenActivated

TrailingActivated

PositionClosed

PositionReconciled
```

Subscribers include:

- Telegram
- Metrics
- Journal
- Replay Engine
- Dashboard

---

# Validation Rules

Examples

Cannot close:

```
NEW
```

Cannot activate trailing:

```
Position Closed
```

Cannot reduce below zero:

```
Current Size < Reduction
```

Cannot update:

```
Unknown Position
```

Every mutation passes validation before persistence.

---

# Exchange Synchronization

Current

```
Exchange

↓

Position Sync

↓

Database
```

Future

```
Exchange

↓

Position Sync

↓

Position Manager

↓

Database
```

The synchronization layer no longer writes state.

It becomes an adapter.

---

# Relationship with OMS

OMS owns:

- Orders

Position Manager owns:

- Positions

Relationship

```text
OMS

↓

Order Filled

↓

Position Manager

↓

Open Position
```

OMS never owns position state.

---

# Relationship with Exit Engine

Exit Engine owns:

- Exit decisions

Position Manager owns:

- Exit execution state

Example

```text
Exit Engine

↓

Close Position

↓

Position Manager

↓

Update Position

↓

Publish PositionClosed
```

---

# Relationship with Risk

Risk Service may recommend:

```
Reduce Exposure

Close Position

Reject Trade
```

Position Manager executes only valid position transitions.

Risk never mutates state directly.

---

# Repository Design

Recommended package

```text
src/core/position/

├── manager.py

├── aggregate.py

├── repository.py

├── commands.py

├── events.py

├── state_machine.py

├── validator.py

└── reconciliation.py
```

Current components gradually migrate into this package.

---

# Persistence

The Position Manager is responsible for:

- Loading positions
- Saving positions
- Version control
- Optimistic locking
- Event publishing

No other component writes directly to position storage.

---

# Recovery

On restart

```text
Startup

↓

Load Open Positions

↓

Synchronize Exchange

↓

Resolve Differences

↓

Resume Runtime
```

The Position Manager becomes the recovery coordinator.

---

# Reconciliation

Periodic reconciliation

```text
Exchange

↓

Current Positions

↓

Position Manager

↓

Local Database

↓

Differences?

↓

Repair
```

This eliminates duplicated reconciliation logic.

---

# Migration Strategy

## Phase 1

No changes.

---

## Phase 2

Introduce Position Manager.

Mirror existing updates.

No ownership yet.

---

## Phase 3

Route new writes through Position Manager.

Old code remains as fallback.

---

## Phase 4

Remove direct writers.

Position Manager becomes sole authority.

---

## Phase 5

Enable replay support.

---

# Rollback Strategy

Feature flag

```
position_manager_enabled = false
```

Fallback

Current implementation continues.

Rollback requires no schema changes.

---

# Success Criteria

Migration is complete when:

- Position has exactly one writer.
- All updates go through Position Manager.
- Exit Engine no longer writes state.
- Position Sync no longer writes state.
- OMS publishes events only.
- Position lifecycle becomes deterministic.
- Replay reconstructs identical state.

---

# Risks

| Risk | Mitigation |
|------|------------|
| Duplicate updates | Versioning |
| Lost updates | Optimistic locking |
| Race conditions | Single writer |
| Exchange mismatch | Reconciliation |
| Restart inconsistency | Startup synchronization |

---

# Benefits

Introducing the Position Manager provides:

- Single Source of Truth
- Deterministic lifecycle
- Clear ownership
- Easier debugging
- Simplified reconciliation
- Cleaner Event Bus integration
- Replay compatibility
- Better testing
- Reduced race conditions

---

# Architectural Decision

The Position Manager is **not** another business service.

It is the **authoritative aggregate manager** for every trading position.

Its responsibility is not to decide *what* should happen—that remains the responsibility of Risk, Exit Engine, and Strategy.

Its responsibility is to ensure that **every position transition is valid, consistent, persisted exactly once, and observable through business events**.

For this reason, the Position Manager is considered the cornerstone of Karsa's future event-driven architecture and should be introduced before Workflow Engine, Agent Runtime, or AI orchestration.