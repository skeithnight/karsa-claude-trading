# Migration Strategy

**Document ID:** KARSA-ARCH-012  
**Title:** Production Migration Strategy  
**Version:** 1.0 (Draft)  
**Status:** Proposed Architecture  
**Author:** Karsa Architecture Team  
**Last Updated:** July 2026

---

# Purpose

This document defines the **incremental migration strategy** for evolving Karsa from its current service-oriented architecture into an event-driven, AI-assisted trading platform.

The primary objective is **not architectural modernization**.

The primary objective is:

> **Improve the architecture while maintaining production stability.**

---

# Executive Principle

## Never Rewrite Production

Karsa is an actively operating trading platform.

Therefore:

**No migration phase may require a complete rewrite.**

Every architectural improvement must satisfy:

- Backward compatible
- Incrementally deployable
- Feature flag controlled
- Observable
- Rollback capable
- Production safe

---

# Migration Philosophy

Instead of this:

```text
Current

↓

Rewrite

↓

New System
```

Karsa evolves through:

```text
Current

↓

Small Improvement

↓

Production

↓

Validate

↓

Next Improvement
```

Every phase delivers value.

---

# Migration Principles

## Principle 1

Preserve production behavior.

Architecture changes must not alter trading behavior.

---

## Principle 2

Infrastructure before business logic.

Introduce:

- Event Bus
- Position Manager
- Replay

before changing trading logic.

---

## Principle 3

One architectural concern per phase.

Avoid combining multiple major changes.

---

## Principle 4

Every phase is independently deployable.

---

## Principle 5

Every phase has a rollback plan.

---

# Current State

Today

```text
Analyzer

↓

Risk

↓

Execution

↓

OMS

↓

Exchange
```

Communication

Mostly synchronous.

Position ownership

Distributed.

Exit logic

Distributed.

---

# Target State

```text
                  Karsa Runtime

------------------------------------------------

Workflow Engine

Agent Runtime

Decision Engine

Event Bus

Replay Engine

Policy Engine

------------------------------------------------

Thinking Layer

Analyzer

Research

Advisor

Journal

------------------------------------------------

Doing Layer

Position Manager

Exit Engine

Execution

OMS

Exchange

------------------------------------------------
```

---

# Migration Roadmap

The migration consists of **nine production phases**.

Each phase is independently deployable.

---

# Phase 0 — Baseline

## Objective

Freeze architecture.

Measure current behavior.

No code changes.

---

### Deliverables

- Baseline metrics
- Architecture inventory
- Event catalog
- Component ownership
- Replay baseline

---

### Success Criteria

Current production behavior documented.

---

# Phase 1 — Event Bus

## Objective

Introduce internal Event Bus.

No behavioral changes.

---

### Current

```text
Execution

↓

Telegram
```

---

### Future

```text
Execution

↓

Publish Event

↓

Telegram
```

Execution still behaves identically.

---

### Deliverables

- Event Bus
- Publisher API
- Subscriber API
- Event Registry

---

### Risks

Very Low.

---

### Rollback

Disable Event Bus.

Existing service calls remain.

---

# Phase 2 — Observer Migration

## Objective

Convert passive components into subscribers.

---

### Components

- Telegram
- Metrics
- Dashboard
- Journal

---

### Before

```text
Execution

↓

Telegram
```

---

### After

```text
Execution

↓

PositionOpened

↓

Event Bus

↓

Telegram
```

---

### Benefits

Lower coupling.

No business logic changes.

---

### Risks

Low.

---

# Phase 3 — Position Manager

## Objective

Introduce single ownership.

---

### Current

```text
Execution

↓

Database
```

```text
Trailing Stop

↓

Database
```

---

### Future

```text
Execution

↓

Position Manager

↓

Database
```

All writes centralized.

---

### Deliverables

- Position Aggregate
- Position Repository
- Position Events

---

### Risks

Medium.

---

### Rollback

Disable Position Manager feature flag.

Return to direct writes.

---

# Phase 4 — Exit Engine

## Objective

Centralize exit decisions.

---

### Current

- Trailing Stop
- Profit Lock
- Stop Loss

---

### Future

Exit Engine

↓

Strategies

↓

Decision

↓

Position Manager

---

### Deliverables

- Exit Engine
- Strategy Interface
- Exit Events

---

### Risks

Medium.

---

### Rollback

Restore existing exit modules.

---

# Phase 5 — Decision Engine

## Objective

Separate recommendations from execution.

---

### Current

Analyzer

↓

Risk

↓

Execution

---

### Future

Analyzer

↓

Decision Engine

↓

Risk

↓

Execution

---

### Deliverables

- Recommendation Aggregator
- Confidence Model
- Explainability

---

### Risks

Medium.

---

### Rollback

Analyzer publishes directly to Risk.

---

# Phase 6 — Replay Engine

## Objective

Replay production history.

---

### Deliverables

- Event Store
- Replay Engine
- Timeline Reconstruction

---

### Risks

Very Low.

Replay is read-only.

---

# Phase 7 — Policy Engine

## Objective

Externalize trading rules.

---

Examples

- Maximum leverage
- Daily loss
- Weekend trading
- Portfolio exposure

---

### Deliverables

- Policy Registry
- Policy Evaluation
- Policy Events

---

### Risks

Low.

---

# Phase 8 — Agent Runtime

## Objective

Standardize AI lifecycle.

---

### Initial Agents

- Analyzer
- Advisor
- Journal

No deterministic services migrate.

---

### Deliverables

- Runtime
- Registry
- Scheduler
- Retry

---

### Risks

Medium.

---

### Rollback

Disable Agent Runtime.

Agents execute directly.

---

# Phase 9 — Workflow Engine

## Objective

Model long-running business processes.

---

### Initial Workflows

- Research
- Journal

Later

Trade Workflow.

---

### Deliverables

- Workflow Runtime
- Checkpointing
- Resume
- Workflow History

---

### Risks

Medium.

---

### Rollback

Existing schedulers continue.

---

# Migration Timeline

```text
Current

↓

Phase 1

Event Bus

↓

Phase 2

Subscribers

↓

Phase 3

Position Manager

↓

Phase 4

Exit Engine

↓

Phase 5

Decision Engine

↓

Phase 6

Replay

↓

Phase 7

Policy

↓

Phase 8

Agent Runtime

↓

Phase 9

Workflow Engine
```

Every phase builds on the previous one.

---

# Deployment Strategy

Every phase follows the same deployment model.

```text
Development

↓

Unit Test

↓

Integration Test

↓

Replay Validation

↓

Paper Trading

↓

Shadow Mode

↓

Production

↓

Observe

↓

Enable
```

No feature skips validation.

---

# Feature Flags

Every architectural component is independently configurable.

Example

```yaml
features:

  event_bus: true

  position_manager: false

  exit_engine: false

  decision_engine: false

  replay_engine: false

  policy_engine: false

  agent_runtime: false

  workflow_engine: false
```

Every migration supports immediate rollback.

---

# Parallel Running

Critical components should run in **shadow mode** before becoming authoritative.

Example

```text
Current Position Logic

↓

Position Manager

↓

Compare

↓

Identical?

↓

Enable
```

The new implementation observes first, then takes ownership.

---

# Validation Gates

Every phase must satisfy the following before progressing.

## Functional

- Existing features unchanged.
- No regression.

---

## Performance

- Latency unchanged.
- Throughput unchanged.

---

## Reliability

- No increase in failures.
- No duplicate trades.

---

## Observability

- Metrics available.
- Events visible.
- Logs consistent.

---

## Replay

Historical replay produces identical outcomes.

---

# Rollback Strategy

Every phase supports rollback.

General process

```text
Disable Feature Flag

↓

Restart Component

↓

Resume Previous Behavior
```

Rollback must require **no database migration** whenever possible.

---

# Testing Strategy

Each phase includes:

### Unit Tests

Business logic.

---

### Integration Tests

Component interaction.

---

### Replay Tests

Historical validation.

---

### Paper Trading

Real market.

No real orders.

---

### Shadow Mode

New architecture observes production.

No execution.

---

### Production

Gradual rollout.

---

# Risk Assessment

| Phase | Risk | Notes |
|--------|------|-------|
| Phase 1 | Very Low | Infrastructure only |
| Phase 2 | Low | Passive subscribers |
| Phase 3 | Medium | Position ownership |
| Phase 4 | Medium | Exit coordination |
| Phase 5 | Medium | Recommendation layer |
| Phase 6 | Very Low | Read-only replay |
| Phase 7 | Low | Policy evaluation |
| Phase 8 | Medium | AI orchestration |
| Phase 9 | Medium | Workflow coordination |

No phase is classified as High Risk because every phase is independently deployable and reversible.

---

# Success Metrics

The migration is successful when:

## Architecture

- Components communicate primarily through events.
- Position has one authoritative owner.
- Exit logic is centralized.
- AI lifecycle is standardized.

---

## Operations

- Zero production downtime.
- Zero duplicate trades.
- Replay validates production behavior.
- Rollback completed within minutes.

---

## Engineering

- Reduced coupling.
- Faster feature delivery.
- Higher test coverage.
- Simpler debugging.

---

# Anti-Goals

The migration explicitly avoids:

- Complete rewrites
- Big-bang deployments
- Replacing stable deterministic services
- Introducing AI into execution
- Distributed infrastructure before necessary
- Premature optimization

---

# Architectural Evolution

The migration should be viewed as an architectural evolution.

```text
Current Architecture

↓

Event Driven

↓

Single Ownership

↓

Deterministic Core

↓

AI Runtime

↓

Workflow Platform

↓

Karsa Trading Operating System
```

At no point should production stability be sacrificed for architectural elegance.

---

# Final Recommendation

The recommended migration strategy prioritizes **business continuity over architectural perfection**.

Rather than rebuilding Karsa, the platform evolves through a sequence of small, measurable improvements that progressively introduce stronger ownership, better coordination, and richer platform capabilities.

The migration order is intentional:

1. **Decouple communication** (Event Bus)
2. **Establish ownership** (Position Manager)
3. **Centralize business rules** (Exit Engine)
4. **Separate reasoning from execution** (Decision Engine)
5. **Improve observability** (Replay Engine)
6. **Externalize governance** (Policy Engine)
7. **Standardize AI orchestration** (Agent Runtime)
8. **Model long-running business processes** (Workflow Engine)

Following this roadmap allows Karsa to mature into an AI-assisted trading operating system while preserving the deterministic, reliable execution required for production algorithmic trading.