# Profit Enhancement Analysis

I traced the entire pipeline — signal generation → entry → holding → exit — to find where the system either leaves money on the table or turns winners into losers. Here are the findings, ordered by profit impact.

---

## 🔴 HIGH IMPACT

### 1. The LLM Analyst Only Sees 4H Candles — Misses Entries by Hours
**File**: `src/agents/crypto_analyst.py` — line 289

```python
ohlcv = await self.mcp.get_ohlcv(ticker, "CRYPTO", timeframe="4h", limit=200)
```

The analyst fetches **4-hour candles** for every technical indicator (RSI, Bollinger, MACD, ATR). The problem: a 4H candle is a *lagging* picture. If BTC is in a major breakout at 10:37am, the analyst is reading data from a candle that started at 8:00am. It will miss the entry by up to 4 hours. By the time the signal is generated, price has already moved.

**Enhancement**: Multi-timeframe analysis — use **1H** for signals and **4H** for trend confirmation.

```python
# Confirmation: 4H trend direction
ohlcv_4h = await self.mcp.get_ohlcv(ticker, "CRYPTO", timeframe="4h", limit=100)
# Entry timing: 1H for precise trigger
ohlcv_1h = await self.mcp.get_ohlcv(ticker, "CRYPTO", timeframe="1h", limit=100)
```

---

### 2. Trailing Stop is Too Wide — Gives Back 2x ATR of Profits
**File**: `src/risk/trailing_stop.py` — lines 27-32

```python
REGIME_TRAIL_MULTIPLIER = {
    "TREND_BULL": 2.0,  # trails 2x ATR behind price
    "TREND_BEAR": 2.0,
    "MEAN_REVERSION": 1.5,
    "CHOP": 0,
}
```

For a $5 position at 2x ATR, the trailing stop could be $0.50-$1.50 behind the current price. When combined with our $1 max risk, this means we can give back the *entire profit* before the stop triggers.

**Enhancement**: Tighten the trail as profits stack. Start at 2.0x ATR, compress to 1.0x when at +2R, compress to 0.5x at +3R.

```python
REGIME_TRAIL_MULTIPLIER = {
    "TREND_BULL": 1.5,   # tighter by default
    "TREND_BEAR": 1.5,
    "MEAN_REVERSION": 1.0,
    "CHOP": 0,
}
# Then ProfitLockManager further tightens at +0.25R, +1R, +2R, +3R (already implemented)
```

---

### 3. Scan Interval is 15 Minutes — Fast Breakouts Are Missed
**File**: `src/agents/autonomous_session.py` — line 35

```python
DEFAULT_INTERVAL_MIN = 15
```

With a 15-minute scan interval, any breakout that starts and consolidates in under 15 minutes could be partially missed for entry — you'd enter after the initial momentum, at a worse price and tighter reward. This is a structural problem for short-to-medium trend trades.

**Enhancement**: Add an "event-driven scan" trigger. When the Bybit WebSocket detects unusual volume or a price spike on a tracked coin, immediately fire a scan for that coin without waiting for the 15-min cycle.

---

### 4. Conservative Profile Min Confidence = 70 — LLM Prompt Says 50+
**File**: `src/agents/crypto_analyst.py` — lines 32-33, 58-60

The base system prompt says:
```
Only generate a signal when confidence >= 50.
High confidence (70+) requires all 4 conditions aligned.
```
But the conservative profile guidance says `>= 70`. The LLM reads the base prompt first and sees `50` as the baseline — it may interpret `70` as a "hard" mode, not the minimum. This creates **signal inflation** where the LLM generates 55-65 confidence signals that pass its own mental check but would fail the risk manager's 70 threshold — wasting LLM tokens and scan time.

**Enhancement**: Synchronize the base prompt confidence threshold with the active profile, so the LLM's internal floor matches the actual minimum.

---

## 🟡 MEDIUM IMPACT

### 5. Position Judge Allows 3 Consecutive HOLDs on Negative Positions
**File**: `src/risk/performance_gate.py` — lines 35-37

```
- Consecutive holds >= 3 on negative positions → auto-exit
```

3 checkpoints for STANDARD bucket are at 1H, 4H, 12H — meaning a losing position can be "HOLD"ed by the AI judge for up to **12 hours** before auto-exit triggers. That's 12 hours of holding a loser.

**Enhancement**: For the Conservative profile, reduce max consecutive holds to **2**. Cut losers faster.

---

### 6. No Volume-Weighted Entry — Bot Buys at Market Price
**File**: `src/risk/sor.py` (Smart Order Router)

The SOR executes at market price. For a Sniper strategy on a $15M+ volume coin, market slippage is minimal — but better than "buy market" is **buy limit at mid-spread** (half-way between bid and ask). On a coin doing $15M volume, the bid-ask spread is often $0.01-$0.05. Over 100 trades, this saves $1-5 in slippage, which equals 1-5 extra free trades.

**Enhancement**: For non-urgent entries, use IOC (Immediate-or-Cancel) limit orders at the mid-spread instead of market orders.

---

### 7. `SQUEEZE_ALERT` Regime Has No Directional Filter — Can Enter Wrong Way
**File**: `src/advisory/strategy_selector.py` — lines 173-187

The SQUEEZE_ALERT regime says:
```
Prepare exact trigger levels at upper/lower bands.
Trade the breakout IMMEDIATELY when price crosses the band with high volume.
```

But there is no check for **macro trend direction** inside SQUEEZE_ALERT. A squeeze can break up or down. The analyst might enter long into a squeeze that breaks down, or short into a squeeze that breaks up. The fix is to require the squeeze breakout direction to match the 4H trend before entering.

---

## 🟢 LOW HANGING FRUIT (Quick Wins)

### 8. `FULL_ALIGNMENT` Regime Has 1.5x Size Multiplier But We Cap at $1
Because we now hard-cap all risk at $1, the `FULL_ALIGNMENT` `size_multiplier: 1.5` does nothing — it would size to $1.50 risk but gets capped to $1. To actually benefit from high-confidence setups, we should use the size multiplier to **boost the notional** instead (more contracts for the same $1 risk), which reduces stop distance required.

---

## Summary Table

| # | Issue | Impact | Effort |
|---|---|---|---|
| 1 | 4H-only candles — late entries | 🔴 High | Low |
| 2 | 2x ATR trailing too wide — gives back profit | 🔴 High | Low |
| 3 | 15min scan misses fast breakouts | 🔴 High | High |
| 4 | LLM base prompt confidence doesn't match profile | 🟡 Medium | Low |
| 5 | 3 consecutive HOLDs allows 12h losing positions | 🟡 Medium | Low |
| 6 | Market orders instead of mid-spread limits | 🟡 Medium | Medium |
| 7 | SQUEEZE_ALERT no directional filter | 🟡 Medium | Low |
| 8 | FULL_ALIGNMENT size multiplier wasted under $1 cap | 🟢 Low | Low |

> [!IMPORTANT]
> **Items 1 and 2 are the biggest profit leaks.** Late entries on 4H data + trailing stops that give back 2x ATR before triggering can easily turn a +$3 winner into a +$0.50 winner. These two changes alone would noticeably improve the average win.

Shall I implement Items 1, 2, 4, 5, and 7 (the Low/Medium effort ones)?
