# Exit Engine

**Document ID:** KARSA-ARCH-006  
**Title:** Exit Engine Architecture  
**Version:** 1.0 (Draft)  
**Status:** Proposed Architecture  
**Author:** Karsa Architecture Team  
**Last Updated:** July 2026

---

# Purpose

The **Exit Engine** is responsible for **all position exit decisions** within Karsa.

Its purpose is to centralize every exit-related rule into a single deterministic component.

Unlike the current implementation where exit logic is distributed across multiple modules, the Exit Engine becomes the **only component responsible for deciding when and how a position should be exited**.

The Position Manager owns the position.

The Exit Engine owns the exit decision.

---

# Why an Exit Engine?

During the architecture review, exit logic was found to be fragmented across multiple components.

Current implementations include:

- Stop Loss
- Trailing Stop
- Profit Lock
- Time Exit
- Manual Close
- Exchange Liquidation Protection

Each component evaluates exit conditions independently.

Although functional, this architecture introduces:

- duplicated logic
- conflicting decisions
- inconsistent state transitions
- difficult debugging
- difficult testing

---

# Current Architecture

Current exit flow

```text
Market Price

      │

      ▼

Trailing Stop

      │

      ▼

Profit Lock

      │

      ▼

Stop Loss

      │

      ▼

Manual Close

      │

      ▼

Exchange
```

Every component independently decides whether a position should close.

There is no central coordinator.

---

# Proposed Architecture

```text
                  Market Events

                       │

                       ▼

                 Exit Engine

      ┌──────────┼───────────┬───────────┐

      ▼          ▼           ▼           ▼

 Initial SL  Break Even  Trailing   Time Exit

      │          │           │           │

      └──────────┴───────────┴───────────┘

                       ▼

                Exit Decision

                       ▼

               Position Manager

                       ▼

                Execution Layer

                       ▼

                   Exchange
```

Every exit strategy contributes information.

Only one component produces the final exit decision.

---

# Responsibilities

The Exit Engine owns:

- Initial Stop Loss
- Break Even
- Partial Exit
- Dynamic Trailing
- Time-based Exit
- Emergency Exit
- Exit Priority
- Exit Validation

It does **not** own:

- Position persistence
- Order execution
- Risk calculations
- Portfolio allocation

---

# Design Principles

## Single Decision Point

Only one component decides:

> Should this position exit now?

All exit strategies return recommendations.

The Exit Engine produces the final decision.

---

## Strategy Composition

Every exit mechanism is implemented as an independent strategy.

Example

```text
Exit Engine

├── Stop Loss Strategy

├── Break Even Strategy

├── Partial Exit Strategy

├── Trailing Strategy

├── Time Exit Strategy

├── Emergency Strategy

└── Liquidation Protection
```

Strategies remain isolated.

---

## Deterministic

The Exit Engine never depends on AI.

Every decision must be:

- reproducible
- testable
- deterministic

---

# Exit Lifecycle

Every position progresses through exit stages.

```text
Position Open

↓

Initial Protection

↓

Break Even

↓

Profit Protection

↓

Trailing

↓

Exit Pending

↓

Closed
```

The Exit Engine owns this lifecycle.

---

# Exit Pipeline

Each market update passes through the same evaluation sequence.

```text
Price Update

↓

Validate Position

↓

Emergency Check

↓

Stop Loss Check

↓

Break Even Check

↓

Partial Exit Check

↓

Trailing Check

↓

Time Exit Check

↓

Generate Decision
```

Every stage may:

- Continue
- Modify protection
- Close position

---

# Exit Strategies

---

## Initial Stop Loss

Purpose

Protect capital immediately after entry.

Trigger

Position Opened

Actions

- Calculate SL
- Register protection
- Publish StopLossCreated

---

## Break Even Strategy

Purpose

Remove downside risk.

Trigger

Profit exceeds configured threshold.

Example

```
+1R
```

Actions

Move Stop Loss to Entry.

Publish

```
BreakEvenActivated
```

---

## Partial Exit Strategy

Purpose

Lock partial profits.

Example

```
50%

at

+2R
```

Actions

- Reduce position
- Update remaining size
- Publish PositionReduced

---

## Trailing Strategy

Purpose

Protect profits while allowing trend continuation.

Current proposal

ATR-based dynamic trailing.

Supports

- volatility adaptation
- regime-aware multiplier
- highest-price tracking

---

## Time Exit Strategy

Purpose

Close stagnant trades.

Example

```
48 hours

AND

Profit < 1%
```

Close trade.

---

## Emergency Exit

Highest priority.

Examples

- Exchange outage
- Portfolio kill switch
- Maximum drawdown
- Risk freeze
- Manual override

Emergency Exit bypasses all other strategies.

---

# Exit Priority

Not every strategy has equal priority.

Priority order

```text
Emergency Exit

↓

Liquidation Protection

↓

Stop Loss

↓

Time Exit

↓

Trailing

↓

Partial Exit

↓

Break Even
```

The first valid strategy wins.

---

# Exit Decision

Every evaluation produces:

```json
{
  "decision": "CLOSE",
  "reason": "TrailingStopTriggered",
  "strategy": "ATRTrailing",
  "confidence": 1.0
}
```

Possible decisions

```
CONTINUE

UPDATE_SL

PARTIAL_EXIT

FULL_EXIT

EMERGENCY_EXIT
```

---

# Strategy Interface

Recommended abstraction

```python
class ExitStrategy:

    def evaluate(position, market):

        return ExitDecision
```

Every strategy shares the same interface.

The Exit Engine coordinates execution.

---

# State Machine

```text
ACTIVE

↓

PROTECTED

↓

BREAK_EVEN

↓

PARTIAL

↓

TRAILING

↓

EXIT_PENDING

↓

EXITED
```

State transitions remain deterministic.

---

# Event Integration

Consumes

```
PositionOpened

MarketUpdated

FundingUpdated

PolicyChanged

ManualExitRequested
```

Publishes

```
BreakEvenActivated

PositionReduced

TrailingUpdated

ExitTriggered

TradeCompleted
```

---

# Relationship with Position Manager

Position Manager owns:

- position state

Exit Engine owns:

- exit decision

Flow

```text
Exit Engine

↓

Exit Decision

↓

Position Manager

↓

Persist

↓

Publish PositionClosed
```

---

# Relationship with Execution

Execution never evaluates exits.

Execution only executes orders.

```text
Exit Engine

↓

Close Position

↓

Execution

↓

Exchange
```

Responsibilities remain separate.

---

# Relationship with Policy Engine

Future

Policy Engine provides rules.

Example

```
Maximum Holding Time

↓

Exit Engine
```

The Exit Engine enforces policy.

---

# Configuration

Example

```yaml
exit:

  stop_loss:

    enabled: true

  break_even:

    enabled: true

    trigger_r: 1

  partial_exit:

    enabled: true

    percentage: 50

    trigger_r: 2

  trailing:

    enabled: true

    method: atr

  time_exit:

    enabled: true

    max_hours: 48

  emergency:

    enabled: true
```

Strategies become configurable.

---

# Migration Strategy

## Phase 1

Current implementation.

---

## Phase 2

Extract strategy interfaces.

No behavior changes.

---

## Phase 3

Wrap existing:

- trailing_stop.py
- profit_lock.py
- sl_engine.py

as strategies.

---

## Phase 4

Introduce Exit Engine coordinator.

---

## Phase 5

Remove duplicated exit logic.

---

## Phase 6

Enable replay.

---

# Rollback

Feature flag

```text
exit_engine_enabled = false
```

Fallback

Existing strategy implementations continue independently.

---

# Testing Strategy

Every strategy receives:

- unit tests
- integration tests
- replay tests

Combined Exit Engine receives:

- scenario tests
- regression tests
- historical replay

Every exit decision must be reproducible.

---

# Success Criteria

Migration is complete when:

- All exits originate from Exit Engine.
- No module independently closes positions.
- Position Manager becomes the only state writer.
- Exit decisions are replayable.
- Strategies are independently testable.
- New exit strategies require no modification to existing code.

---

# Risks

| Risk | Mitigation |
|------|------------|
| Duplicate exits | Position version validation |
| Conflicting strategies | Exit priority |
| Strategy ordering | Central pipeline |
| Incorrect trailing | Replay testing |
| Regression | Historical trade replay |

---

# Future Extensions

Future strategies may include:

- Volatility Exit
- Portfolio Drawdown Exit
- Correlation Exit
- Funding Exit
- AI Recommendation Exit (Advisory only)
- News-based Exit
- Circuit Breaker Exit

These integrate without modifying the Exit Engine core.

---

# Architectural Benefits

The Exit Engine transforms exit management from a collection of independent services into a **single deterministic orchestration layer**.

Benefits include:

- Single exit authority
- Centralized business rules
- Easier testing
- Cleaner Position Manager integration
- Event-driven architecture
- Replay compatibility
- Strategy plug-in architecture
- Simplified future enhancements

Most importantly, the Exit Engine allows Karsa to evolve sophisticated exit strategies—such as ATR trailing, portfolio-level exits, or policy-driven liquidation—without scattering business logic across multiple components. It becomes the authoritative orchestration layer for every decision that ends a trade while preserving deterministic execution and production safety.