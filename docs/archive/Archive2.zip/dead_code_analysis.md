# Unused Functions Audit

I ran a static analysis across the `src/` directory to find functions that are defined but never called elsewhere in the codebase. 

Out of 841 total functions, here are the **120 potentially unused functions** (dead code). Many of these appear to be API endpoints, admin commands, fallback utilities, or half-built features that were abandoned.

### Architecture & Engine
- `src/architecture/agent_runtime/runtime.py`: `all_runs`, `get_run`
- `src/architecture/common/interfaces.py`: `get_by_id`, `list_all`
- `src/architecture/events/registry.py`: `all_events`, `publishers_of`, `subscribers_of`
- `src/architecture/events/subscribers.py`: `get_event_counts`
- `src/architecture/feature_flags.py`: `all_flags`, `enable`
- `src/architecture/position/manager.py`: `recover_stop_loss`, `update_stop_loss`, `update_current_price`, `open_position`, `all_positions`, `get_position`
- `src/architecture/replay/engine.py`: `store_events`, `replay_all`
- `src/architecture/workflow/engine.py`: `get_workflow`

### API & Routes
- `src/api/crypto_control.py`: `asm_stop`, `watchdog_status`, `asm_status`, `emergency_status`, `asm_start`, `emergency_resume`, `watchdog_diagnostic`, `asm_resume`
- `src/api/routes.py`: `update_risk_profile`, `get_risk_profile_history`, `get_universe`, `get_universe_scores`, `get_risk_profile`

### Advisory & Intelligence
- `src/advisory/crypto_market_watch.py`: `get_market_snapshot`, `get_briefing_data`
- `src/advisory/crypto_universe.py`: `get_pair_config`
- `src/advisory/idx_intelligence.py`: `get_ihsg_support_resistance`
- `src/advisory/strategy_selector.py`: `get_history`

### Agents
- `src/agents/crypto_analyst.py`: `wipe_memory`
- `src/agents/crypto_auditor.py`: `prefilter_signal`, `save_recommendations`
- `src/agents/memory_retriever.py`: `store_trade_memory` *(Note: We just planned to fix this!)*

### Risk & Position Management
- `src/risk/calibration_engine.py`: `invalidate_cache`
- `src/risk/circuit_breaker.py`: `get_active_breakers`
- `src/risk/crypto_risk_manager.py`: `check_kill_switch`, `is_kill_switch_active`, `deactivate_kill_switch_redis`, `check_all_positions_health`
- `src/risk/dlq.py`: `clear_queue`, `get_exhausted`
- `src/risk/funding_tracker.py`: `get_alerts`, `should_exit_for_funding`
- `src/risk/idx_limits.py`: `is_settled`
- `src/risk/performance_gate.py`: `_get_dynamic_stop`, `_reset_peak_gain`
- `src/risk/position_manager.py`: `check_break_even_stops`
- `src/risk/position_sync.py`: `reconcile_balances`, `reconcile_orders`
- `src/risk/profile_manager.py`: `validate_signal`, `calculate_position_size`
- `src/risk/sor.py`: `execute_twap_order`, `execute_iceberg_order`

### Research & AODE
- `src/research/developer_intel.py`: `get_commit_activity`
- `src/research/learning_engine.py`: `record_outcome`, `generate_post_mortem`, `recalibrate_weights`
- `src/research/monitoring_engine.py`: `persist_alert`
- `src/research/narrative_intel.py`: `persist_narratives`
- `src/research/onchain_intel.py`: `get_tvl`, `get_holder_data`
- `src/research/portfolio_bucker.py`: `allocate`, `get_position_size`, `persist_allocation`
- `src/research/research_orchestrator.py`: `get_watchlist`

### Data Clients
- `src/data/bybit_client.py`: `validate_api_key`, `_retry_call`
- `src/data/coingecko_client.py`: `get_global_data`
- `src/data/defillama_client.py`: `get_stablecoins`, `get_chain_tvl`, `get_yields`, `get_top_protocols_by_chain`
- `src/data/dexscreener_client.py`: `get_token_pairs`
- `src/data/github_client.py`: `get_commit_count`
- `src/data/onchain_client.py`: `get_eth_balance`

### Backtesting
- `src/backtest/engine.py`: `backtest_crypto_trend`, `to_dict`, `backtest_rsi_mean_reversion`

### Metrics & Monitoring
- `src/metrics/crypto_metrics.py`: `update_net_roi`, `record_position_size`, `update_llm_confidence`, `record_trading_fee`, `update_daily_trade_count`, `record_llm_tokens`
- `src/monitoring/anomaly_detector.py`: `get_all_zscores`
- `src/monitoring/watchdog.py`: `register_level2_handler`, `register_level1_handler`

### Bot & Core
- `src/bot/crypto_main.py`: `debug_telegram_app`, `alertmanager_webhook`
- `src/bot/main.py`: `telegram_webhook`
- `src/main.py`: `_job_expire_approvals`
- `src/config.py`: `valid_trading_mode`, `live_mode_requires_broker_keys`, `password_must_be_set`, `telegram_token_should_be_set`
- `src/execution/websocket_manager.py`: `get_realtime_price`
- `src/models/database.py`: `get_pool_status`

### Utilities
- `src/utils/error_classification.py`: `describe_error`
- `src/utils/format.py`: `underline`, `link`, `strike`
- `src/utils/formatters/__init__.py`: `format_sl_alert`, `format_tp_alert`, `get_regime_display`
- `src/utils/market_hours.py`: `should_scan_market`, `get_next_market_open`
- `src/utils/telegram_helpers.py`: `escape_html`
- `src/utils/trader_format.py`: `regime_banner`, `briefing_block`, `market_snapshot_card`, `perf_dashboard`
- `src/strategies/funding_capture.py`: `get_allocation`

> [!NOTE]  
> Some of these (like API routes, Telegram webhooks, or utilities) might be called externally or dynamically, so they aren't strictly "dead". However, internal trading logic like `execute_twap_order`, `check_break_even_stops`, or the entire `learning_engine.py` appear to be genuinely unused.
