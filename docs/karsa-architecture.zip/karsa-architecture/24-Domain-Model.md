# Domain Model

**Document ID:** KARSA-ARCH-024  
**Title:** Domain Model & Business Entities  
**Version:** 1.0 (Draft)  
**Status:** Architecture Contract  
**Author:** Karsa Architecture Team  
**Last Updated:** July 2026

---

# Purpose

This document defines the **business domain model** for Karsa.

Unlike implementation classes or database tables, the Domain Model represents the **business language** of the trading platform.

Every architectural component should communicate using these business entities.

The objectives are to:

- establish a common ubiquitous language
- define ownership
- define relationships
- define aggregate boundaries
- reduce coupling
- support event-driven architecture

---

# Domain Philosophy

Karsa follows **Domain-Driven Design (DDD)** principles.

Business concepts should drive architecture—not database tables or API endpoints.

Every entity must answer:

- What business concept does it represent?
- Who owns it?
- What is its lifecycle?
- Which events affect it?
- Which aggregate does it belong to?

---

# Domain Overview

```text
                        Portfolio
                            │
              ┌─────────────┼─────────────┐
              ▼                           ▼
         Position                    Decision
              │                           │
              ▼                           ▼
            Order                     Signal
              │                           │
              ▼                           ▼
          Execution                 Market Data

                       ▼

                  Workflow

                       ▼

                    Journal

                       ▼

                    Memory
```

---

# Domain Categories

```text
Business Domain

├── Market

├── Trading

├── Portfolio

├── Intelligence

├── Governance

├── Workflow

├── Knowledge

└── Infrastructure
```

---

# Aggregate Ownership

| Aggregate | Owner |
|------------|------------------|
| Signal | Analyzer |
| Decision | Decision Engine |
| Policy | Policy Engine |
| Risk Assessment | Risk Engine |
| Order | OMS |
| Position | Position Manager |
| Exit Strategy | Exit Engine |
| Portfolio | Portfolio Service |
| Workflow | Workflow Engine |
| Journal | Journal Service |
| Memory | Memory Service |
| Replay Session | Replay Engine |

Each aggregate has exactly one owner.

---

# Core Business Entities

---

# Market

Represents the live financial market.

Owner

Market Data Service

Attributes

- Symbol
- Exchange
- Bid
- Ask
- Last Price
- Volume
- Funding Rate
- Open Interest
- Volatility
- Market Regime

Lifecycle

Always changing.

Events

```
MarketUpdated

VolatilityUpdated

MarketRegimeChanged
```

---

# Signal

Represents a trading opportunity detected by analysis.

Owner

Analyzer

Attributes

- Symbol
- Direction
- Confidence
- Strategy
- Timestamp
- Indicators

Lifecycle

```text
Detected

↓

Validated

↓

Expired
```

Events

```
SignalDetected

SignalRejected
```

---

# Decision

Represents the platform's recommendation after evaluating a signal.

Owner

Decision Engine

Attributes

- Recommendation
- Confidence
- Reasons
- Supporting Evidence
- Risk Summary

Lifecycle

```text
Created

↓

Scored

↓

Approved

↓

Rejected
```

Events

```
DecisionApproved

DecisionRejected
```

---

# Policy

Represents business governance rules.

Owner

Policy Engine

Attributes

- Name
- Rule
- Priority
- Version
- Status

Lifecycle

```text
Draft

↓

Approved

↓

Active

↓

Deprecated
```

Events

```
PolicyChanged

PolicyRejected
```

---

# Risk Assessment

Represents the financial validation of a decision.

Owner

Risk Engine

Attributes

- Position Size
- Leverage
- Risk %
- Margin
- Exposure

Lifecycle

```text
Pending

↓

Calculated

↓

Approved

↓

Rejected
```

Events

```
RiskApproved

RiskRejected
```

---

# Order

Represents an instruction sent to an exchange.

Owner

OMS

Attributes

- Order ID
- Symbol
- Side
- Type
- Quantity
- Price
- Status

Lifecycle

```text
Created

↓

Submitted

↓

Filled

↓

Cancelled
```

Events

```
OrderSubmitted

OrderFilled

OrderCancelled
```

---

# Position

Represents an active market exposure.

Owner

Position Manager

Attributes

- Position ID
- Symbol
- Direction
- Entry Price
- Quantity
- Stop Loss
- Take Profit
- Current PnL
- Unrealized PnL

Lifecycle

```text
Opening

↓

Open

↓

Protected

↓

Closing

↓

Closed
```

Events

```
PositionOpened

PositionUpdated

PositionClosed
```

---

# Exit Strategy

Represents the protection and exit logic associated with a position.

Owner

Exit Engine

Attributes

- Stop Loss
- Break Even
- Trailing Stop
- Partial Exit
- Time Exit

Lifecycle

```text
Initialized

↓

Monitoring

↓

Triggered

↓

Completed
```

Events

```
TrailingActivated

PartialExitExecuted

TradeCompleted
```

---

# Portfolio

Represents the entire trading account.

Owner

Portfolio Service

Attributes

- Equity
- Cash
- Margin
- Drawdown
- Exposure
- Holdings

Lifecycle

Continuous.

Events

```
PortfolioUpdated

ExposureChanged

AllocationChanged
```

---

# Workflow

Represents a long-running business process.

Owner

Workflow Engine

Examples

- Trade Workflow
- Research Workflow
- Journal Workflow

Lifecycle

```text
Created

↓

Running

↓

Waiting

↓

Completed
```

Events

```
WorkflowStarted

WorkflowCompleted
```

---

# Agent

Represents an AI worker.

Owner

Agent Runtime

Examples

- Research Agent
- Advisor Agent
- Journal Agent

Lifecycle

```text
Ready

↓

Running

↓

Completed
```

Events

```
AgentStarted

AgentCompleted
```

---

# Journal

Represents a trading narrative.

Owner

Journal Service

Attributes

- Summary
- Reasoning
- Lessons
- Tags
- Attachments

Events

```
JournalGenerated
```

---

# Memory

Represents long-term knowledge.

Owner

Memory Service

Types

- Trade Memory
- Strategy Memory
- Market Memory
- Research Memory

Memory is read-only during execution.

Events

```
MemoryStored

MemoryIndexed
```

---

# Replay Session

Represents a deterministic reconstruction.

Owner

Replay Engine

Attributes

- Session ID
- Trade ID
- Event Count
- Result
- Duration

Lifecycle

```text
Created

↓

Running

↓

Completed
```

Events

```
ReplayStarted

ReplayCompleted
```

---

# Relationships

## Signal → Decision

```text
Signal

1

↓

1..N

Decision
```

One signal may produce multiple decision evaluations.

---

## Decision → Risk

```text
Decision

1

↓

1

Risk Assessment
```

---

## Risk → Order

```text
Risk

1

↓

0..1

Order
```

Rejected risk produces no order.

---

## Order → Position

```text
Order

1

↓

0..1

Position
```

Only filled orders create positions.

---

## Position → Exit Strategy

```text
Position

1

↓

1

Exit Strategy
```

Every position must have protection.

---

## Position → Journal

```text
Position

1

↓

1

Journal
```

---

## Position → Memory

```text
Position

1

↓

0..N

Memory
```

Historical trades contribute knowledge.

---

## Workflow → Agent

```text
Workflow

1

↓

N

Agent
```

---

## Portfolio → Position

```text
Portfolio

1

↓

N

Position
```

---

# Aggregate Boundaries

```text
Portfolio Aggregate

├── Positions

├── Cash

├── Exposure

└── Allocation
```

---

```text
Position Aggregate

├── Entry

├── Exit

├── Stop Loss

├── Quantity

└── PnL
```

---

```text
Decision Aggregate

├── Signal

├── Research

├── Confidence

└── Recommendation
```

Each aggregate enforces its own invariants.

---

# Domain Events

| Entity | Primary Events |
|----------|----------------|
| Signal | SignalDetected |
| Decision | DecisionApproved |
| Risk | RiskApproved |
| Order | OrderFilled |
| Position | PositionOpened |
| Exit | TradeCompleted |
| Portfolio | PortfolioUpdated |
| Workflow | WorkflowCompleted |
| Agent | AgentCompleted |
| Journal | JournalGenerated |
| Replay | ReplayCompleted |

---

# Business Invariants

These rules must always hold.

### Position

- Quantity ≥ 0
- Entry price > 0
- Symbol cannot change

---

### Order

- Immutable after fill
- Quantity > 0
- Valid symbol

---

### Portfolio

- Exposure ≤ configured maximum
- Cash cannot be negative

---

### Decision

- Confidence between 0 and 1
- Exactly one recommendation

---

### Policy

- One active version per policy

---

# Value Objects

The following should be implemented as immutable value objects.

```text
Money

Price

Quantity

Percentage

Leverage

ATR

Timestamp

Confidence

R-Multiple
```

They have no identity.

Only value.

---

# Entity Identity

| Entity | Identity |
|----------|-----------|
| Signal | Signal ID |
| Decision | Decision ID |
| Policy | Policy ID |
| Order | Order ID |
| Position | Position ID |
| Workflow | Workflow ID |
| Replay | Replay ID |

Identity never changes.

---

# Domain Services

Business logic that does not belong to a single entity.

Examples

- Decision Engine
- Risk Engine
- Exit Engine
- Replay Engine
- Policy Engine

Entities contain state.

Services contain business operations.

---

# Repository Ownership

| Repository | Owner |
|-------------|-------|
| Position Repository | Position Manager |
| Order Repository | OMS |
| Policy Repository | Policy Engine |
| Workflow Repository | Workflow Engine |
| Journal Repository | Journal Service |
| Replay Repository | Replay Engine |

Only owners write.

---

# Ubiquitous Language

The following terms have precise meanings and should be used consistently.

| Term | Meaning |
|------|----------|
| Signal | Market opportunity |
| Decision | Recommendation |
| Risk | Financial validation |
| Order | Exchange instruction |
| Position | Market exposure |
| Exit | Position termination |
| Portfolio | Trading account |
| Workflow | Long-running business process |
| Replay | Historical reconstruction |
| Memory | Long-term knowledge |

Avoid synonyms in implementation.

---

# Domain Evolution Rules

A new entity may only be introduced if:

- It represents a real business concept.
- It has a clearly defined owner.
- It has an identity or is a value object.
- Its lifecycle is documented.
- Events are defined.
- Relationships are documented.
- Replay compatibility is considered.

---

# Summary

The Domain Model defines the **business vocabulary** of Karsa.

It establishes:

- Common language
- Aggregate boundaries
- Ownership
- Relationships
- Business invariants
- Domain events
- Repository ownership

This model provides the conceptual foundation for all other architecture documents and ensures that the implementation remains aligned with the business rather than with infrastructure or technology choices.