# Architecture Rules

**Document ID:** KARSA-ARCH-023  
**Title:** Architecture Rules & Dependency Governance  
**Version:** 1.0 (Draft)  
**Status:** Mandatory Architecture Standard  
**Author:** Karsa Architecture Team  
**Last Updated:** July 2026

---

# Purpose

This document defines the **non-negotiable architectural rules** that every component inside Karsa must follow.

Unlike the component architecture documents, this document answers:

- What is each component allowed to know?
- What is each component forbidden from accessing?
- Which dependencies are legal?
- Which dependencies are architectural violations?
- How should new components be introduced?

The objective is to **prevent architecture erosion** as the platform grows.

---

# Why Architecture Rules?

Large systems rarely fail because of algorithms.

They fail because:

- dependencies become tangled
- ownership becomes unclear
- components begin bypassing boundaries
- business logic leaks into infrastructure
- AI gains unintended control over execution

Architecture Rules exist to prevent these problems.

---

# Architecture Philosophy

Every component should satisfy three questions.

1. **What do I own?**
2. **Who may I communicate with?**
3. **What must I never know?**

If these questions cannot be answered, the component is not properly designed.

---

# Core Principles

## Rule 1 — Single Ownership

Every business concept has exactly one owner.

| Domain | Owner |
|----------|----------------|
| Signal | Analyzer |
| Decision | Decision Engine |
| Policy | Policy Engine |
| Risk | Risk Engine |
| Position | Position Manager |
| Exit | Exit Engine |
| Order | OMS |
| Workflow | Workflow Engine |
| Memory | Memory Service |
| Replay | Replay Engine |

No shared ownership.

---

## Rule 2 — AI Never Executes Trades

AI may

- analyze
- recommend
- summarize
- explain
- prioritize

AI may never

- place orders
- modify positions
- cancel orders
- update balances
- bypass policies
- override risk

AI always operates in the **Thinking Layer**.

---

## Rule 3 — Business Logic Lives in Business Components

Incorrect

```text
Telegram Bot

↓

Risk Validation
```

Correct

```text
Telegram Bot

↓

Trading API

↓

Risk Engine
```

Interfaces never contain business logic.

---

## Rule 4 — Infrastructure Never Owns Business Logic

Redis

PostgreSQL

Kafka

Docker

should never contain trading decisions.

Infrastructure stores data.

Business components make decisions.

---

## Rule 5 — Communication Through Events

Whenever possible

```text
Producer

↓

Event Bus

↓

Consumer
```

instead of

```text
Producer

↓

Direct Call

↓

Consumer
```

---

## Rule 6 — Commands Change State

Commands mutate.

Example

```
OpenPosition()
```

---

## Rule 7 — Queries Never Change State

Queries read only.

Example

```
GetPosition()
```

---

## Rule 8 — Every State Change Produces an Event

Examples

```
PositionOpened

OrderFilled

TradeCompleted

PolicyRejected
```

No silent mutations.

---

# Layering Rules

```text
Presentation

↓

Thinking

↓

Coordination

↓

Execution

↓

Infrastructure
```

Dependencies only flow downward.

Never upward.

---

# Allowed Dependencies

```text
Presentation

↓

Thinking

↓

Coordination

↓

Execution

↓

Infrastructure
```

Never

```text
Infrastructure

↓

Execution
```

---

# Component Dependency Matrix

## Analyzer

### Owns

- Market analysis
- Signal generation

### May Call

- Market Data
- Memory

### May Publish

- SignalDetected

### Must Never Call

- Exchange
- OMS
- Position Manager

---

## Decision Engine

### Owns

- Recommendation aggregation
- Decision scoring

### May Call

- Policy Engine
- Portfolio
- Memory

### May Publish

- DecisionApproved
- DecisionRejected

### Must Never Call

- Exchange
- Database
- Telegram

---

## Policy Engine

### Owns

- Business rules
- Governance

### May Call

- Policy Repository

### Must Never Call

- Exchange
- Database directly
- AI

---

## Risk Engine

### Owns

- Risk validation
- Position sizing

### May Call

- Portfolio

### Must Never Call

- Telegram
- Workflow
- AI

---

## Execution Service

### Owns

- Trade execution

### May Call

- OMS

### Must Never Call

- Analyzer
- AI
- Telegram

---

## OMS

### Owns

- Order lifecycle

### May Call

- Exchange Adapter

### Must Never Call

- AI
- Workflow
- Position calculations

---

## Position Manager

### Owns

- Position lifecycle
- Position persistence

### May Call

- Repository

### May Publish

- PositionOpened
- PositionClosed

### Must Never Call

- Telegram
- AI
- Exchange

---

## Exit Engine

### Owns

- Exit decision

### May Call

- Position Manager

### Must Never Call

- Exchange directly
- Telegram
- Database

---

## Workflow Engine

### Owns

- Business orchestration

### May Call

- Agent Runtime
- APIs

### Must Never Call

- Exchange

---

## Agent Runtime

### Owns

- AI lifecycle

### May Call

- LLM Providers
- Memory

### Must Never Call

- OMS
- Exchange
- Position Manager

---

## Replay Engine

### Owns

- Historical reconstruction

### May Call

- Event Store

### Must Never Call

- Execution
- OMS
- Exchange

Replay is read-only.

---

## Memory

### Owns

- Knowledge retrieval

### May Call

- Vector Database

### Must Never Call

- Exchange
- OMS
- Position Manager

---

# Forbidden Dependencies

The following dependencies are architectural violations.

| Source | Forbidden Target | Reason |
|----------|------------------|--------|
| Analyzer | Exchange | Analysis cannot trade |
| Decision Engine | Exchange | Decisions don't execute |
| AI | OMS | AI cannot place orders |
| AI | Position Manager | AI cannot mutate state |
| Exit Engine | Telegram | Publish events instead |
| Position Manager | AI | Deterministic ownership |
| Replay | Exchange | Replay is read-only |
| Workflow | Exchange | Use Execution Service |
| Telegram | Database | Use APIs |
| Dashboard | Redis | Use Services |

---

# Event Rules

Every business event

- immutable
- versioned
- replayable
- published once

Never

- update
- delete
- overwrite

events.

---

# Database Rules

Only owners write.

Example

Position table

Only

```
Position Manager
```

may write.

Everyone else reads.

---

# Configuration Rules

Configuration must never:

- contain business logic
- replace code
- bypass policies

Configuration changes should be versioned.

---

# Feature Flag Rules

Every major feature requires a feature flag.

Examples

```
EventBus

Replay

Workflow

Agent Runtime
```

Rollback should require configuration only.

---

# Logging Rules

Every log includes

- correlationId
- requestId
- service
- timestamp

Never log

- secrets
- API keys
- passwords

---

# API Rules

Internal APIs must

- be versioned
- be idempotent
- distinguish commands from queries
- publish business events

---

# State Machine Rules

Every aggregate requires

- owner
- state machine
- valid transitions
- invalid transitions
- replay support

No aggregate without lifecycle documentation.

---

# Replay Rules

Replay

- never executes
- never mutates
- never publishes commands

Replay reconstructs history only.

---

# Workflow Rules

Workflow coordinates.

Workflow never owns business logic.

Business rules remain inside services.

---

# Memory Rules

Memory provides context.

Memory never becomes a source of truth.

---

# Error Handling Rules

Business failures

↓

Business Events

Infrastructure failures

↓

Retry / Recovery

Never mix the two.

---

# Dependency Review Checklist

Every new component must answer:

- What do I own?
- Which layer am I in?
- Which APIs do I expose?
- Which events do I publish?
- Which events do I consume?
- Which components may call me?
- Which components may I call?
- What must I never know?

---

# Pull Request Checklist

Before merging:

- No forbidden dependencies introduced
- No ownership violations
- Events documented
- State machine updated
- API contract updated
- Replay impact reviewed
- Architecture documents updated

---

# Architectural Smells

Examples of architecture violations

❌ AI calling Exchange

❌ Position updates from multiple services

❌ Direct database writes across modules

❌ Circular dependencies

❌ Hidden business logic in controllers

❌ Infrastructure making business decisions

❌ Business services reading UI state

❌ Multiple owners for the same entity

---

# Dependency Validation Matrix

| Component | Can Call | Cannot Call |
|------------|----------|-------------|
| Analyzer | Market Data, Memory | Exchange, OMS |
| Decision Engine | Policy, Portfolio | Exchange |
| Policy Engine | Repository | Exchange |
| Risk Engine | Portfolio | AI |
| Execution | OMS | AI |
| OMS | Exchange Adapter | Position Manager |
| Position Manager | Repository | Exchange |
| Exit Engine | Position Manager | Telegram |
| Workflow Engine | APIs | Exchange |
| Agent Runtime | AI Providers | OMS |
| Replay | Event Store | Exchange |
| Memory | Vector DB | Execution |

---

# Evolution Rules

Every architectural change must satisfy:

1. Backward compatible
2. Replay compatible
3. Observable
4. Rollback capable
5. Feature flagged
6. Deterministic
7. Documented

If any condition is not met, the change should not be deployed.

---

# Architecture Governance

Every new component requires:

- Architecture Review
- API Contract
- Event Registration
- State Machine
- Sequence Diagram
- Failure Scenario
- Test Strategy
- Migration Plan

Documentation precedes implementation.

---

# Success Criteria

The architecture is considered healthy when:

- Every business entity has one owner.
- Dependencies remain acyclic.
- AI cannot directly execute trades.
- Business logic is isolated from infrastructure.
- Every state change emits an event.
- Every component has a clearly defined responsibility.
- Replay can reconstruct all business operations.
- New engineers can determine component responsibilities without reading implementation code.

---

# Summary

Architecture Rules define the **governance model** for Karsa.

While other documents describe **how the platform works**, this document defines **how the platform is allowed to evolve**.

These rules protect the architecture against:

- dependency creep
- ownership ambiguity
- tight coupling
- business logic leakage
- unsafe AI integration
- uncontrolled growth

By enforcing these principles consistently, Karsa can scale in both functionality and team size while preserving the deterministic, maintainable, and production-safe architecture required for an algorithmic trading platform.