# Implementation Plan: Profit Enhancement — Round 2

## Background
Four enhancements from the profit ideas analysis. Ordered by lowest risk first:
- **Idea D**: Partial exit rebalance — 2 numbers changed
- **Idea A**: Trade memory write activation — 2 call sites added
- **Idea C**: Funding capture activation — scheduler cron fix
- **Idea B**: Scale-in pyramiding — new `check_scale_in()` method

---

## Change 1 — Idea D: Partial Exit Ratio Rebalance
**File**: `src/risk/position_manager.py`  
**Complexity**: ⬜ Trivial (2 numbers)

### Current
```python
PARTIAL_EXIT_TARGETS = [
    {"r_multiple": 1.0, "exit_pct": 30, "reason": "partial_1r"},
    {"r_multiple": 2.0, "exit_pct": 30, "reason": "partial_2r"},
    # 40% runner with trailing stop
]
```
Exit 30% at +1R means position is already 60% of full size on the best part of the move (from +1R onward).

### Proposed
```python
PARTIAL_EXIT_TARGETS = [
    {"r_multiple": 1.0, "exit_pct": 15, "reason": "partial_1r"},   # lock a tiny slice, not a third
    {"r_multiple": 2.0, "exit_pct": 35, "reason": "partial_2r"},   # meaningful exit at confirmed +2R
    # 50% runner — more size catches the full move
]
```
**Why**: +1R exit now locks only 15% (instead of 30%), leaving 85% of the position live. When a trade runs to +3R or +4R, the runner earns significantly more. On trades that top out at +1.5R, the difference is negligible.

#### Files
- [MODIFY] [position_manager.py](file:///Users/dwiki.nugraha/dwikicode/karsa-claude-trading/src/risk/position_manager.py) — Lines 26-30: update `PARTIAL_EXIT_TARGETS`

---

## Change 2 — Idea A: Activate Trade Memory Writes
**Files**: `src/risk/position_manager.py`, `src/risk/performance_gate.py`  
**Complexity**: 🟢 Low (2 call-site additions)

### Current State
`store_trade_memory()` in `memory_retriever.py` is fully implemented and correct. The pgvector table schema exists. But **nobody calls it**. Every closed trade vanishes without being recorded. The LLM has no history to learn from.

### The Two Write Sites

**Site 1 — `position_manager.py` `execute_partial_exit()`** (line ~227): after `record_signal_outcome("WIN")` is called on a profitable partial, also write to memory:
```python
# After record_signal_outcome call at line 227
try:
    from src.agents.memory_retriever import store_trade_memory
    hold_hours = (datetime.now(timezone.utc) - pos.opened_at.replace(
        tzinfo=timezone.utc if pos.opened_at.tzinfo is None else pos.opened_at.tzinfo
    )).total_seconds() / 3600
    await store_trade_memory(
        ticker=pos.ticker,
        regime=getattr(pos, "regime_at_entry", "UNKNOWN") or "UNKNOWN",
        strategy=getattr(pos, "signal_source", "unknown") or "unknown",
        thesis=getattr(pos, "signal_reasoning", f"{pos.side} {pos.ticker}") or f"{pos.side} {pos.ticker}",
        outcome="WIN" if pnl_usdt > 0 else "LOSS",
        pnl_pct=float(pnl_pct),
        exit_reason=reason,
        hold_duration_hours=hold_hours,
    )
except Exception:
    pass  # memory write is non-blocking, never crash the trade close
```

**Site 2 — `performance_gate.py`** `_execute_exit()` or the scheduler that acts on `GateAction.EXIT`: add the same `store_trade_memory` call when a position is fully closed by the gate. The position already has `regime_at_entry`, `signal_source`, and `signal_reasoning` fields.

> [!NOTE]
> The `try/except pass` wrapper is critical — trade memory is an enhancement, not a dependency. If pgvector or sentence-transformers fails, the trade still closes cleanly.

#### Files
- [MODIFY] [position_manager.py](file:///Users/dwiki.nugraha/dwikicode/karsa-claude-trading/src/risk/position_manager.py) — After `record_signal_outcome` call in `execute_partial_exit`
- [MODIFY] [performance_gate.py](file:///Users/dwiki.nugraha/dwikicode/karsa-claude-trading/src/risk/performance_gate.py) — After `GateAction.EXIT` execution path

---

## Change 3 — Idea C: Enable Funding Capture (Fix Cron)
**File**: `src/main_crypto.py`  
**Complexity**: 🟢 Low (1 cron entry tweak)

### Discovery
`_job_scan_funding` **is already scheduled** at lines 384-386:
```python
s.add_job(self._job_scan_funding, "cron", hour="1,5,9,13,17,21", minute=10,
          id="funding_capture", ...)
```
The job fires at 01:10, 05:10, 09:10, 13:10, 17:10, 21:10 UTC — every 4 hours, aligned with funding epochs.

**The actual gap**: The job runs but there is **no feature flag guard** and no Telegram notification when a funding position is opened. User never knows it fired. The logic is correct but silent and invisible.

### Proposed Changes (2 small additions)

**Addition 1**: After a successful funding execution (line ~1119), send a Telegram alert so the user can monitor:
```python
if result.get("success"):
    logger.info("funding_position_opened", ...)
    # Notify user
    try:
        chat_id = await self.redis_client.get("karsa:telegram_chat_id")
        if chat_id:
            from src.bot.crypto_main import send_message
            msg = (
                f"💸 <b>Funding Capture</b>\n"
                f"  Opened <b>{signal['direction']}</b> {signal['ticker']}\n"
                f"  Funding: <b>{signal.get('_funding_annualized', 0):+.1f}%</b> annualized\n"
                f"  Earning from crowded {'longs' if signal.get('_funding_direction') == 'positive' else 'shorts'}"
            )
            await send_message(int(chat_id), msg)
    except Exception:
        pass
```

**Addition 2**: Also call `store_trade_memory` when a funding position exits (in `should_exit` call path), tagged with `strategy="funding_capture"` so the LLM can distinguish funding wins/losses from momentum ones.

#### Files
- [MODIFY] [main_crypto.py](file:///Users/dwiki.nugraha/dwikicode/karsa-claude-trading/src/main_crypto.py) — `_job_scan_funding()` around line 1119: add Telegram notification after success

---

## Change 4 — Idea B: Scale-In Pyramiding on Winners
**File**: `src/risk/position_manager.py`  
**Complexity**: 🟡 Medium (new method + caller integration)

### Logic
When a position reaches **+1R** profit AND the regime is confirmed trending (`FULL_TREND_ALIGNMENT`, `TREND_BULL`, or `FULL_ALIGNMENT`), add **25% more size** with a stop at the **original entry price** (the add-on risks nothing if it fails, because our stop is now at breakeven on the first unit).

### New Method: `check_scale_in()`
Add to `PositionManager` class:

```python
SCALE_IN_CONFIG = {
    "r_multiple":  1.0,          # trigger: position at +1R
    "add_pct":     25,           # add 25% of original size
    "reason":      "pyramid_1r",
    "allowed_regimes": {"FULL_TREND_ALIGNMENT", "FULL_ALIGNMENT", "TREND_BULL"},
}

async def check_scale_in(
    self, positions: list[CryptoPosition], current_regime: str = "UNKNOWN"
) -> list[dict]:
    """Check if any winning positions qualify for a pyramid add-on."""
    actions = []
    
    # Gate: only pyramid in strong trend regimes
    if current_regime not in SCALE_IN_CONFIG["allowed_regimes"]:
        return []
    
    for pos in positions:
        if pos.status != "OPEN":
            continue
        if getattr(pos, "scale_in_taken", False):
            continue  # already pyramided

        entry = Decimal(str(pos.entry_price))
        current = Decimal(str(pos.current_price or 0))
        stop = Decimal(str(pos.stop_loss or pos.trailing_stop_price or 0))
        
        if stop == 0 or entry == 0:
            continue

        risk = (entry - stop) if pos.side == "Buy" else (stop - entry)
        reward = (current - entry) if pos.side == "Buy" else (entry - current)
        
        if risk <= 0 or reward / risk < SCALE_IN_CONFIG["r_multiple"]:
            continue  # not at +1R yet

        add_size = Decimal(str(pos.size)) * SCALE_IN_CONFIG["add_pct"] / 100
        actions.append({
            "position_id": pos.id,
            "ticker": pos.ticker,
            "side": pos.side,
            "action": "scale_in",
            "add_pct": SCALE_IN_CONFIG["add_pct"],
            "add_size": float(add_size),
            "new_stop": float(entry),  # move stop to entry for the add-on
            "reason": SCALE_IN_CONFIG["reason"],
            "r_multiple": float(reward / risk),
        })
    
    return actions
```

> [!IMPORTANT]
> **Safety Gate**: `check_scale_in` must check that `open_position_count < max_positions` before adding. The scale-in does NOT count as a new position slot (it's an add to existing), but the total risk exposure must respect the max drawdown limits. Also requires a new DB column `scale_in_taken BOOLEAN DEFAULT FALSE` to prevent double-pyramiding.

#### Files
- [MODIFY] [position_manager.py](file:///Users/dwiki.nugraha/dwikicode/karsa-claude-trading/src/risk/position_manager.py) — Add `SCALE_IN_CONFIG` constant and `check_scale_in()` method
- [MODIFY] `src/main_crypto.py` or the scheduler that calls `check_partial_exits` — also call `check_scale_in(positions, current_regime)`
- [NEW] DB migration — add `scale_in_taken` boolean column to `crypto_positions` table

---

## Verification Plan

### Syntax Check (all changes)
```bash
python3 -m py_compile \
  src/risk/position_manager.py \
  src/risk/performance_gate.py \
  src/main_crypto.py
```

### Manual Spot Checks
| Check | Pass Condition |
|---|---|
| `PARTIAL_EXIT_TARGETS[0]["exit_pct"]` | `15` (not 30) |
| `PARTIAL_EXIT_TARGETS[1]["exit_pct"]` | `35` (not 30) |
| `store_trade_memory` called after a partial exit | Check logs for `trade_memory_stored` |
| Funding job Telegram | Message appears in bot when funding > 15% annualized |
| `check_scale_in()` returns empty in MEAN_REVERSION regime | Confirmed |
| `check_scale_in()` returns action in TREND_BULL when position at +1R | Confirmed |

---

## Execution Order

| # | Change | Risk | Time |
|---|---|---|---|
| 1 | Idea D — Partial exit ratio | None | 5 min |
| 2 | Idea A — Trade memory writes | None (non-blocking) | 20 min |
| 3 | Idea C — Funding Telegram notify | None | 10 min |
| 4 | Idea B — Pyramiding (+ DB migration) | Low | 45 min |
