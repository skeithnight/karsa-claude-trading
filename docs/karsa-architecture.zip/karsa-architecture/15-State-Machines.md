# State Machines

**Document ID:** KARSA-ARCH-015  
**Title:** Business State Machines  
**Version:** 1.0 (Draft)  
**Status:** Architecture Contract  
**Author:** Karsa Architecture Team  
**Last Updated:** July 2026

---

# Purpose

This document defines every **business state machine** used within Karsa.

Unlike workflows, which describe long-running business processes, state machines define **the lifecycle of a single business entity**.

Examples include:

- Orders
- Positions
- Decisions
- Workflows
- Agents

Every state transition must be:

- deterministic
- valid
- auditable
- replayable

---

# Why State Machines?

Without explicit state machines:

- Invalid transitions become possible.
- Lifecycle logic becomes scattered.
- Recovery becomes difficult.
- Replay becomes unreliable.

State machines ensure every business entity follows a predictable lifecycle.

---

# Design Principles

## Explicit States

Every entity must have a finite set of states.

---

## Explicit Transitions

Every transition must be defined.

---

## Single Owner

Only one component owns each state machine.

---

## Event Driven

Transitions produce business events.

---

## Deterministic

Given identical inputs, the state machine always reaches the same state.

---

# Order State Machine

**Owner:** OMS

---

## States

```text
NEW

↓

VALIDATED

↓

SUBMITTED

↓

PARTIALLY_FILLED

↓

FILLED

↓

CANCELLED

↓

REJECTED

↓

EXPIRED
```

---

## Diagram

```text
                NEW
                 │
                 ▼
            VALIDATED
                 │
                 ▼
            SUBMITTED
          ┌──────┴──────┐
          ▼             ▼
PARTIALLY_FILLED    REJECTED
          │
          ▼
       FILLED
```

Alternative paths

```text
SUBMITTED

↓

CANCELLED
```

```text
SUBMITTED

↓

EXPIRED
```

---

## Valid Transitions

| From | To |
|------|----|
| NEW | VALIDATED |
| VALIDATED | SUBMITTED |
| SUBMITTED | PARTIALLY_FILLED |
| SUBMITTED | FILLED |
| SUBMITTED | CANCELLED |
| SUBMITTED | REJECTED |
| SUBMITTED | EXPIRED |
| PARTIALLY_FILLED | FILLED |
| PARTIALLY_FILLED | CANCELLED |

---

## Invalid Transitions

Examples

```
FILLED

↓

SUBMITTED
```

```
REJECTED

↓

FILLED
```

---

## Published Events

```
OrderCreated

OrderSubmitted

OrderPartiallyFilled

OrderFilled

OrderCancelled

OrderRejected
```

---

# Position State Machine

**Owner:** Position Manager

---

## States

```text
CREATED

↓

OPENING

↓

OPEN

↓

BREAK_EVEN

↓

PARTIAL_EXIT

↓

TRAILING

↓

EXIT_PENDING

↓

CLOSED
```

---

## Diagram

```text
                CREATED
                    │
                    ▼
                OPENING
                    │
                    ▼
                  OPEN
          ┌─────────┼──────────┐
          ▼         ▼          ▼
 BREAK_EVEN    PARTIAL_EXIT TRAILING
          │         │          │
          └─────────┼──────────┘
                    ▼
              EXIT_PENDING
                    │
                    ▼
                 CLOSED
```

---

## Valid Transitions

| From | To |
|------|----|
| CREATED | OPENING |
| OPENING | OPEN |
| OPEN | BREAK_EVEN |
| OPEN | PARTIAL_EXIT |
| OPEN | TRAILING |
| BREAK_EVEN | TRAILING |
| PARTIAL_EXIT | TRAILING |
| TRAILING | EXIT_PENDING |
| EXIT_PENDING | CLOSED |

---

## Published Events

```
PositionOpened

BreakEvenActivated

TrailingActivated

PositionReduced

PositionClosed
```

---

# Exit State Machine

**Owner:** Exit Engine

---

## States

```text
UNPROTECTED

↓

STOP_LOSS_SET

↓

BREAK_EVEN

↓

PARTIAL_LOCKED

↓

TRAILING

↓

EXIT_TRIGGERED

↓

COMPLETED
```

---

## Diagram

```text
UNPROTECTED

↓

STOP_LOSS_SET

↓

BREAK_EVEN

↓

PARTIAL_LOCKED

↓

TRAILING

↓

EXIT_TRIGGERED

↓

COMPLETED
```

---

## Events

```
StopLossCreated

BreakEvenActivated

PartialExitExecuted

TrailingActivated

TradeCompleted
```

---

# Decision State Machine

**Owner:** Decision Engine

---

## States

```text
CREATED

↓

COLLECTING

↓

VALIDATING

↓

SCORING

↓

POLICY_CHECK

↓

APPROVED

↓

REJECTED
```

---

## Diagram

```text
CREATED

↓

COLLECTING

↓

VALIDATING

↓

SCORING

↓

POLICY_CHECK

↓

APPROVED
```

Alternative

```text
POLICY_CHECK

↓

REJECTED
```

---

## Events

```
DecisionApproved

DecisionRejected

DecisionExplained
```

---

# Workflow State Machine

**Owner:** Workflow Engine

---

## States

```text
CREATED

↓

STARTED

↓

RUNNING

↓

WAITING

↓

RESUMED

↓

COMPLETED
```

Failure path

```text
RUNNING

↓

FAILED

↓

RETRYING

↓

RUNNING
```

Cancellation

```text
RUNNING

↓

CANCELLED
```

---

## Diagram

```text
             CREATED
                 │
                 ▼
             STARTED
                 │
                 ▼
             RUNNING
          ┌──────┼─────────┐
          ▼                ▼
      WAITING          FAILED
          │                │
          ▼                ▼
      RESUMED         RETRYING
          │                │
          └──────┬─────────┘
                 ▼
            COMPLETED
```

---

## Events

```
WorkflowStarted

WorkflowWaiting

WorkflowResumed

WorkflowCompleted

WorkflowFailed
```

---

# Agent State Machine

**Owner:** Agent Runtime

---

## States

```text
CREATED

↓

INITIALIZING

↓

READY

↓

RUNNING

↓

WAITING

↓

COMPLETED
```

Failure

```text
RUNNING

↓

FAILED

↓

RETRYING

↓

READY
```

---

## Diagram

```text
          CREATED
              │
              ▼
      INITIALIZING
              │
              ▼
           READY
              │
              ▼
          RUNNING
       ┌──────┼──────┐
       ▼             ▼
 COMPLETED       FAILED
                     │
                     ▼
                 RETRYING
                     │
                     ▼
                   READY
```

---

## Events

```
AgentStarted

AgentCompleted

AgentFailed
```

---

# Replay State Machine

**Owner:** Replay Engine

---

## States

```text
CREATED

↓

LOADING

↓

REPLAYING

↓

COMPARING

↓

COMPLETED
```

Failure

```text
REPLAYING

↓

FAILED
```

---

## Events

```
ReplayStarted

ReplayCompleted

ReplayFailed
```

---

# Policy State Machine

**Owner:** Policy Engine

---

## States

```text
DRAFT

↓

REVIEW

↓

APPROVED

↓

ACTIVE

↓

DEPRECATED

↓

ARCHIVED
```

---

## Events

```
PolicyApproved

PolicyActivated

PolicyDeprecated
```

---

# Strategy State Machine

**Owner:** Strategy Registry

---

## States

```text
CREATED

↓

TESTING

↓

PAPER_TRADING

↓

SHADOW_MODE

↓

ACTIVE

↓

DISABLED

↓

RETIRED
```

---

## Events

```
StrategyActivated

StrategyDisabled

StrategyRetired
```

---

# Portfolio State Machine

**Owner:** Portfolio Service

---

## States

```text
INITIALIZED

↓

ACTIVE

↓

REBALANCING

↓

STABLE
```

Emergency

```text
ACTIVE

↓

FROZEN
```

---

## Events

```
PortfolioUpdated

PortfolioRebalanced

PortfolioFrozen
```

---

# Risk Evaluation State Machine

**Owner:** Risk Engine

---

## States

```text
PENDING

↓

CALCULATING

↓

VALIDATED

↓

APPROVED

↓

REJECTED
```

---

## Events

```
RiskApproved

RiskRejected

ExposureExceeded
```

---

# Trading Session State Machine

**Owner:** Trading Runtime

---

## States

```text
STARTING

↓

READY

↓

TRADING

↓

PAUSED

↓

STOPPING

↓

STOPPED
```

---

## Events

```
ApplicationStarted

TradingPaused

TradingResumed

ApplicationStopped
```

---

# Emergency State Machine

**Owner:** Policy Engine

---

## States

```text
NORMAL

↓

WARNING

↓

EMERGENCY

↓

RECOVERY

↓

NORMAL
```

---

## Events

```
EmergencyTriggered

TradingSuspended

TradingResumed
```

---

# Cross-State Dependencies

Some state machines depend on others.

```text
Order Filled
        │
        ▼
Position Open
        │
        ▼
Exit Protection
        │
        ▼
Workflow Continue
```

Another example:

```text
Decision Approved
        │
        ▼
Risk Approved
        │
        ▼
Execution
        │
        ▼
Order Submitted
```

The dependency direction is always one-way.

---

# State Ownership Matrix

| Entity | Owner |
|----------|----------------|
| Order | OMS |
| Position | Position Manager |
| Exit | Exit Engine |
| Decision | Decision Engine |
| Workflow | Workflow Engine |
| Agent | Agent Runtime |
| Replay | Replay Engine |
| Policy | Policy Engine |
| Portfolio | Portfolio Service |
| Risk | Risk Engine |
| Trading Session | Runtime |
| Emergency | Policy Engine |

Each entity has exactly one authoritative owner.

---

# State Transition Rules

Every state transition must satisfy:

1. Current state is valid.
2. Target state is defined.
3. Transition is allowed.
4. Validation passes.
5. State is persisted.
6. Business event is published.

If any step fails, the transition is rejected.

---

# Recovery Rules

After a restart:

- Orders reload from OMS.
- Positions reload from Position Manager.
- Workflows resume from checkpoints.
- Agents return to READY.
- Replay remains stateless.
- Policies reload active versions.

Recovery must preserve the last committed state.

---

# Replay Requirements

Every state transition must be reproducible.

Given:

- identical events,
- identical configuration,
- identical policy version,

the replay engine must reconstruct the same state transitions.

This requirement ensures deterministic debugging and regression testing.

---

# Validation Checklist

Before introducing a new business entity, verify:

- Does it have a defined state machine?
- Is there exactly one owner?
- Are all transitions documented?
- Are invalid transitions rejected?
- Are business events published?
- Can the state be replayed?
- Can it recover after restart?

If any answer is **No**, the implementation is incomplete.

---

# Summary

State machines define the **authoritative lifecycle** of every major business entity within Karsa.

Together they provide:

- Deterministic state transitions
- Single ownership
- Explicit lifecycle management
- Event-driven integration
- Replay compatibility
- Safe recovery
- Production consistency

These state machines serve as the canonical reference for implementation, testing, replay validation, and future architectural evolution.