# Karsa Architecture Repository

> **Architecture documentation for the evolution of Karsa from a modular algorithmic trading system into an AI-assisted, event-driven Trading Operating System.**

---

# Overview

This repository contains the complete architectural blueprint for **Karsa**.

It is **not** a source code repository.

Instead, it documents:

- the current production architecture,
- architectural problems,
- target architecture,
- migration strategy,
- design decisions,
- implementation guidelines,
- and long-term platform vision.

The goal is to evolve the existing production system **without rewriting it**.

---

# Vision

Karsa is designed around one core philosophy:

> **Thinking and Doing are different responsibilities.**

Artificial Intelligence is responsible for **thinking**:

- Market Research
- Analysis
- Recommendation
- Planning
- Journaling

Deterministic services are responsible for **doing**:

- Risk Validation
- Order Execution
- Position Management
- Exit Decisions
- Portfolio Updates

This separation ensures that production trading remains:

- deterministic
- reproducible
- explainable
- auditable
- safe

---

# Architecture Principles

The architecture is guided by the following principles.

## 1. Deterministic Execution

Trading execution must never depend on an LLM.

---

## 2. Single Source of Truth

Every business entity has exactly one owner.

Examples

| Domain | Owner |
|---------|-------|
| Orders | OMS |
| Positions | Position Manager |
| Exit Decisions | Exit Engine |
| Business Policies | Policy Engine |
| Workflows | Workflow Engine |

---

## 3. Event Driven

Components communicate using business events instead of direct dependencies whenever practical.

---

## 4. Incremental Evolution

The production platform evolves gradually.

No big-bang rewrites.

---

## 5. Production First

Working software always has priority over architectural perfection.

---

# Repository Structure

```text
karsa-architecture/

├── README.md
│
├── docs/
│
│   ├── 00-executive-summary.md
│   ├── 01-current-architecture.md
│   ├── 02-runtime-architecture.md
│   ├── 03-code-mapping.md
│   ├── 04-event-bus.md
│   ├── 05-position-manager.md
│   ├── 06-exit-engine.md
│   ├── 07-decision-engine.md
│   ├── 08-agent-runtime.md
│   ├── 09-workflow-engine.md
│   ├── 10-memory.md
│   ├── 11-replay-engine.md
│   ├── 12-migration-strategy.md
│   ├── 13-policy-engine.md
│   │
│   ├── adr/
│   │
│   ├── rfc/
│   │
│   └── diagrams/
│
└── assets/
```

---

# Documentation Guide

The documents are intended to be read in order.

---

## 00 Executive Summary

Provides:

- platform vision
- architecture philosophy
- long-term direction

Read first.

---

## 01 Current Architecture

Documents:

- existing production architecture
- responsibilities
- strengths
- technical debt

---

## 02 Runtime Architecture

Explains:

- startup
- shutdown
- runtime lifecycle
- background workers
- recovery

---

## 03 Code Mapping

Maps:

Architecture

↓

Source Code

↓

Migration Targets

This document is the bridge between design and implementation.

---

## 04 Event Bus

Introduces:

- business events
- publishers
- subscribers
- event contracts

First migration phase.

---

## 05 Position Manager

Defines:

- single ownership
- position lifecycle
- state transitions

Core architectural improvement.

---

## 06 Exit Engine

Centralizes:

- Stop Loss
- Break Even
- Trailing
- Partial Exit
- Time Exit

---

## 07 Decision Engine

Separates:

Thinking

↓

Execution

Provides recommendation fusion.

---

## 08 Agent Runtime

Standardizes AI lifecycle.

Responsible for:

- scheduling
- retries
- lifecycle
- orchestration

---

## 09 Workflow Engine

Coordinates long-running business processes.

Examples:

- Trade Workflow
- Research Workflow
- Journal Workflow

---

## 10 Memory

Introduces long-term knowledge.

Not used for execution.

Used for reasoning.

---

## 11 Replay Engine

Reconstructs historical trading activity.

Supports:

- debugging
- replay
- regression testing

---

## 12 Migration Strategy

Production roadmap.

Defines:

- migration phases
- rollout
- rollback
- validation

---

## 13 Policy Engine

Centralizes:

- governance
- business rules
- compliance
- operational policies

---

# Architecture Layers

The target architecture consists of four logical layers.

```text
Presentation Layer

↓

Thinking Layer

↓

Coordination Layer

↓

Execution Layer

↓

Infrastructure Layer
```

---

## Presentation Layer

Examples

- Telegram
- Dashboard
- CLI
- APIs

---

## Thinking Layer

Examples

- Analyzer
- Advisor
- Research
- Planner
- Journal

AI-assisted.

---

## Coordination Layer

Examples

- Decision Engine
- Workflow Engine
- Policy Engine
- Event Bus

Coordinates business logic.

---

## Execution Layer

Examples

- Risk
- Position Manager
- Exit Engine
- Execution
- OMS

Deterministic.

---

## Infrastructure Layer

Examples

- Redis
- Database
- Exchange
- Monitoring
- Metrics

---

# Architectural Evolution

Current

```text
Analyzer

↓

Risk

↓

Execution

↓

OMS
```

Target

```text
Thinking

↓

Decision Engine

↓

Policy Engine

↓

Risk

↓

Position Manager

↓

Exit Engine

↓

Execution

↓

OMS
```

The migration is evolutionary.

---

# Migration Roadmap

The recommended implementation order is:

| Phase | Component |
|--------|-----------|
| 0 | Baseline & Architecture Audit |
| 1 | Event Bus |
| 2 | Position Manager |
| 3 | Exit Engine |
| 4 | Decision Engine |
| 5 | Replay Engine |
| 6 | Policy Engine |
| 7 | Agent Runtime |
| 8 | Workflow Engine |
| 9 | Memory & Advanced Intelligence |

Every phase is:

- backward compatible
- independently deployable
- reversible

---

# Design Goals

The target platform should achieve:

- Deterministic execution
- Single ownership
- Replayability
- Explainability
- Event-driven communication
- AI-assisted reasoning
- Operational safety
- High observability
- Incremental evolution

---

# What This Repository Is Not

This repository is **not** intended to describe:

- Trading strategies
- Financial indicators
- Exchange integrations
- Source code implementation details
- Infrastructure provisioning
- Deployment scripts

Those belong in the implementation repositories.

This repository focuses exclusively on architecture.

---

# Intended Audience

This documentation is intended for:

- Software Engineers
- Solution Architects
- Technical Leads
- AI Engineers
- DevOps Engineers
- Platform Engineers
- Contributors
- Future maintainers

---

# How to Use This Repository

For new contributors:

1. Read the Executive Summary.
2. Understand the Current Architecture.
3. Review the Runtime Architecture.
4. Study the Code Mapping.
5. Read the Migration Strategy.
6. Review the component architecture relevant to your work.
7. Review the associated ADRs and RFCs before implementation.

For architecture changes:

1. Update the relevant architecture document.
2. Create or update an ADR.
3. Submit an RFC if the change affects production behavior.
4. Review migration impact.
5. Update diagrams.
6. Validate with Replay before production rollout.

---

# Guiding Philosophy

Karsa is **not** being redesigned from scratch.

It is being **carefully evolved**.

Every new architectural component must satisfy one fundamental question:

> **Does this improve the production system without increasing operational risk?**

If the answer is **no**, the change should not be implemented.

This philosophy ensures that Karsa grows through **continuous architectural refinement** rather than disruptive rewrites.

---

# Repository Status

| Area | Status |
|-------|--------|
| Architecture Vision | ✅ Complete |
| Current Architecture | ✅ Complete |
| Runtime Architecture | ✅ Complete |
| Code Mapping | ✅ Complete |
| Core Components | ✅ Defined |
| Migration Strategy | ✅ Defined |
| Production Safety | ✅ Addressed |
| ADR Framework | 🚧 In Progress |
| RFC Framework | 🚧 In Progress |
| Diagrams | 🚧 In Progress |
| C4 Model | 📋 Planned |
| Sequence Diagrams | 📋 Planned |
| Deployment Architecture | 📋 Planned |

---

# Long-Term Goal

The long-term objective of this repository is to become the **single source of truth** for Karsa's architecture.

Every significant architectural decision should be documented here before implementation.

By combining deterministic execution, event-driven coordination, AI-assisted reasoning, and incremental migration, Karsa aims to evolve into a **production-grade AI Trading Operating System** that is scalable, explainable, maintainable, and resilient.