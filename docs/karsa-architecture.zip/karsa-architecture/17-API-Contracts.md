# API Contracts

**Document ID:** KARSA-ARCH-017  
**Title:** Internal Service API Contracts  
**Version:** 1.0 (Draft)  
**Status:** Architecture Contract  
**Author:** Karsa Architecture Team  
**Last Updated:** July 2026

---

# Purpose

This document defines the **internal API contracts** between Karsa services.

Unlike REST APIs, these contracts describe the **service interfaces** used inside the trading platform.

The goal is to ensure that every component communicates through **stable, versioned, deterministic contracts**.

---

# Design Principles

## Stable Interfaces

Business logic should evolve without breaking service consumers.

---

## Commands vs Queries

Every API belongs to one of two categories.

Commands

> Change state.

Queries

> Read state.

Commands never return business objects.

Queries never modify state.

---

## Single Owner

Every business entity has one authoritative API.

Example

| Entity | Owner |
|----------|----------------|
| Position | Position Manager |
| Orders | OMS |
| Decisions | Decision Engine |
| Policies | Policy Engine |

---

## Versioned

Breaking changes require:

```
v2
```

instead of modifying

```
v1
```

---

# API Categories

```text
Internal APIs

├── Decision Engine

├── Policy Engine

├── Risk Engine

├── Position Manager

├── Exit Engine

├── OMS

├── Workflow Engine

├── Replay Engine

├── Memory

└── Agent Runtime
```

---

# Standard Request Metadata

Every request contains:

```json
{
  "requestId": "UUID",
  "correlationId": "UUID",
  "timestamp": "ISO-8601",
  "version": "v1"
}
```

---

# Standard Response

```json
{
  "status": "SUCCESS",
  "requestId": "...",
  "data": {},
  "errors": []
}
```

Possible status values

```
SUCCESS

FAILED

REJECTED

PENDING
```

---

# Standard Error

```json
{
  "code": "POSITION_NOT_FOUND",
  "message": "...",
  "retryable": false
}
```

---

# Decision Engine

Owner

Decision Engine

---

## Evaluate Trading Opportunity

Command

```
evaluateDecision()
```

Purpose

Combine recommendations into one decision.

### Request

```json
{
  "signal": {},
  "portfolio": {},
  "market": {},
  "research": {}
}
```

### Response

```json
{
  "decision": "BUY",
  "confidence": 0.84,
  "reason": "Momentum confirmed"
}
```

### Events

Publishes

```
DecisionApproved

DecisionRejected
```

---

## Explain Decision

Query

```
getDecisionExplanation()
```

Returns

- confidence
- contributors
- reasoning
- policy results

---

# Policy Engine

Owner

Policy Engine

---

## Evaluate Policies

Command

```
evaluatePolicies()
```

### Request

```json
{
  "decision": {},
  "portfolio": {}
}
```

### Response

```json
{
  "status": "PASS",
  "violations": []
}
```

Possible results

```
PASS

WARN

REJECT
```

---

## Get Active Policies

Query

```
getPolicies()
```

Returns

Current policy set.

---

# Risk Engine

Owner

Risk Engine

---

## Validate Trade

Command

```
validateTrade()
```

### Request

```json
{
  "symbol": "",
  "quantity": 0,
  "price": 0
}
```

### Response

```json
{
  "approved": true,
  "maxLeverage": 5
}
```

### Events

```
RiskApproved

RiskRejected
```

---

## Calculate Position Size

Query

```
calculatePositionSize()
```

Returns

Recommended size.

---

# OMS

Owner

OMS

---

## Submit Order

Command

```
submitOrder()
```

### Request

```json
{
  "symbol": "",
  "side": "BUY",
  "quantity": 1
}
```

### Response

```json
{
  "orderId": "...",
  "status": "SUBMITTED"
}
```

### Events

```
OrderSubmitted

OrderFilled

OrderRejected
```

---

## Cancel Order

Command

```
cancelOrder()
```

---

## Get Order

Query

```
getOrder()
```

---

# Position Manager

Owner

Position Manager

---

## Open Position

Command

```
openPosition()
```

### Request

```json
{
  "order": {}
}
```

### Response

```json
{
  "positionId": "...",
  "status": "OPEN"
}
```

### Events

```
PositionOpened
```

---

## Update Stop Loss

Command

```
updateStopLoss()
```

---

## Reduce Position

Command

```
reducePosition()
```

---

## Close Position

Command

```
closePosition()
```

---

## Get Position

Query

```
getPosition()
```

Returns

Current aggregate.

---

# Exit Engine

Owner

Exit Engine

---

## Evaluate Exit

Command

```
evaluateExit()
```

### Request

```json
{
  "position": {},
  "market": {}
}
```

### Response

```json
{
  "decision": "CONTINUE"
}
```

Possible decisions

```
CONTINUE

UPDATE_SL

PARTIAL_EXIT

FULL_EXIT
```

---

## Register Strategy

Command

```
registerStrategy()
```

---

# Workflow Engine

Owner

Workflow Engine

---

## Start Workflow

Command

```
startWorkflow()
```

### Request

```json
{
  "workflow": "TradeWorkflow"
}
```

### Response

```json
{
  "workflowId": "...",
  "status": "RUNNING"
}
```

---

## Resume Workflow

Command

```
resumeWorkflow()
```

---

## Cancel Workflow

Command

```
cancelWorkflow()
```

---

## Get Workflow

Query

```
getWorkflow()
```

---

# Agent Runtime

Owner

Agent Runtime

---

## Execute Task

Command

```
executeTask()
```

### Request

```json
{
  "agent": "Research",
  "task": {}
}
```

### Response

```json
{
  "status": "RUNNING"
}
```

---

## Get Agent Status

Query

```
getAgentStatus()
```

Returns

- health
- state
- metrics

---

# Replay Engine

Owner

Replay Engine

---

## Replay Trade

Command

```
replayTrade()
```

### Request

```json
{
  "tradeId": ""
}
```

### Response

```json
{
  "status": "COMPLETED",
  "identical": true
}
```

---

## Replay Workflow

Command

```
replayWorkflow()
```

---

## Compare Replay

Query

```
compareReplay()
```

---

# Memory

Owner

Memory Manager

---

## Store Memory

Command

```
storeMemory()
```

---

## Search Memory

Query

```
searchMemory()
```

### Request

```json
{
  "query": "...",
  "filters": {}
}
```

---

## Similar Trades

Query

```
findSimilarTrades()
```

---

# Portfolio Service

Owner

Portfolio

---

## Update Portfolio

Command

```
updatePortfolio()
```

---

## Get Portfolio

Query

```
getPortfolio()
```

---

## Calculate Exposure

Query

```
calculateExposure()
```

---

# Market Service

Owner

Market Data

---

## Get Latest Price

Query

```
getPrice()
```

---

## Get OHLCV

Query

```
getCandles()
```

---

## Get Funding

Query

```
getFundingRate()
```

---

# Exchange Adapter

Owner

Exchange Gateway

---

## Submit Order

Command

```
placeExchangeOrder()
```

---

## Cancel Order

Command

```
cancelExchangeOrder()
```

---

## Get Position

Query

```
getExchangePosition()
```

---

# API Dependency Matrix

| Service | Allowed Calls |
|----------|---------------|
| Analyzer | Market Service |
| Decision Engine | Policy, Portfolio |
| Policy Engine | Policy Repository |
| Risk Engine | Portfolio |
| Execution | OMS |
| OMS | Exchange |
| Position Manager | Repository |
| Exit Engine | Position Manager |
| Workflow Engine | Agent Runtime |
| Replay Engine | Event Store |
| Memory | Vector Store |

Services should **never bypass ownership boundaries**.

---

# Forbidden Dependencies

The following interactions are prohibited.

| From | Forbidden Target | Reason |
|------|------------------|--------|
| Analyzer | Exchange | Execution belongs to OMS |
| Decision Engine | Database | Uses repositories only |
| Exit Engine | Telegram | Publish events instead |
| Position Manager | AI | Must remain deterministic |
| Workflow Engine | Exchange | Use services |
| Agent Runtime | OMS | AI cannot execute trades |

---

# Idempotency

Commands modifying state must support idempotency.

Example

```
submitOrder(requestId)
```

Repeated requests with the same request ID must not create duplicate orders.

---

# Timeouts

Recommended defaults

| Service | Timeout |
|----------|---------|
| Decision | 1 sec |
| Policy | 500 ms |
| Risk | 1 sec |
| OMS | 5 sec |
| Exchange | 10 sec |
| Replay | Configurable |
| Agent Runtime | 30 sec |
| Memory | 5 sec |

---

# Retry Policy

Only retry when:

- timeout
- temporary network failure
- service unavailable

Never retry:

- validation errors
- policy rejection
- insufficient balance
- duplicate order

---

# Contract Evolution

Every contract change follows:

```text
Draft

↓

Review

↓

Implementation

↓

Shadow Validation

↓

Production

↓

Deprecation

↓

Removal
```

Breaking changes require a new version.

---

# API Governance Checklist

Before introducing a new API:

- Does one service own it?
- Is it a command or a query?
- Is it idempotent?
- Does it publish events?
- Is it replayable?
- Does it require versioning?
- Are timeout and retry behavior defined?
- Are failure responses documented?

If any answer is **No**, the API is not ready for production.

---

# Summary

The API Contracts document defines the **official internal interfaces** between Karsa components.

It ensures:

- Stable service boundaries
- Single ownership
- Versioned interfaces
- Deterministic communication
- Replay compatibility
- Production-safe evolution

Together with the **Event Catalog**, **State Machines**, and **Sequence Diagrams**, these contracts provide a complete blueprint for implementing and evolving Karsa while maintaining architectural consistency and operational safety.