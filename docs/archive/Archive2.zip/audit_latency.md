# Execution Latency & Slippage Audit

I analyzed the critical path from **Signal Generation → Risk Gate → Execution** to find microseconds/seconds being wasted, which translates directly to slippage (worse entry prices on breakouts).

### The Verdict: High Slippage Risk in the SOR
The signal generation and risk evaluation are very fast, but the **Smart Order Router (`src/risk/sor.py`)** introduces artificial delays that will cost money during high-volatility breakouts.

### Key Findings

**1. Hardcoded Polling Delays (`sor.py`)**
When a market order is placed, the SOR doesn't use the WebSocket to instantly confirm the fill. Instead, it arbitrarily sleeps and polls:
```python
# sor.py line 204
await asyncio.sleep(1)  # Brief wait for fill to register
status = await self.bybit.get_order_status(ticker, order_id)
```
Waiting 1 full second before placing the Stop-Loss and Take-Profit is dangerous. If price dumps in that 1 second, the SL isn't there to protect you.

**2. Aggressive Backoff Sleeps**
If an API call fails or rate-limits, the retry logic uses a heavy multiplier:
```python
await asyncio.sleep(1 * (attempt + 1))
```
If placing an SL fails on attempt 1, the bot sleeps for 2 full seconds before trying again. In crypto, 2 seconds is an eternity.

### Recommendation: "Speed Up the Router"
**Action 1**: Reduce the fill-polling sleep from `1.0s` to `0.2s` or `0.1s`. Market orders on Bybit fill in <50ms. 
**Action 2**: Reduce the retry backoff for SL/TP placement from `1s, 2s, 3s` to `0.2s, 0.4s, 0.8s`. Protective orders must be placed immediately.
