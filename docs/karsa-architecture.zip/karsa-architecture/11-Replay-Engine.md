# Replay Engine

**Document ID:** KARSA-ARCH-011  
**Title:** Replay Engine Architecture  
**Version:** 1.0 (Draft)  
**Status:** Proposed Architecture  
**Author:** Karsa Architecture Team  
**Last Updated:** July 2026

---

# Purpose

The **Replay Engine** provides deterministic reconstruction of every trading decision, workflow, and system event.

Unlike logging, which records what happened, the Replay Engine reconstructs **how and why** it happened.

Replay enables Karsa to answer questions such as:

- Why did this trade occur?
- Why did the position close?
- Why did Risk reject this signal?
- What sequence of events led to this decision?
- Can we reproduce this bug?

Replay is the foundation for:

- debugging
- post-mortem analysis
- regression testing
- historical simulation
- AI learning
- compliance
- explainability

---

# Why Replay?

Traditional trading systems rely on logs.

Example

```text
INFO

BUY BTC

INFO

Position Closed

INFO

Trailing Stop Triggered
```

Logs tell us **what happened**.

They rarely explain:

- the decision sequence
- state transitions
- dependencies
- timing relationships

Replay reconstructs the complete execution path.

---

# Architectural Vision

Instead of replaying logs,

Replay rebuilds business execution.

```text
Historical Events

↓

Replay Engine

↓

Reconstruct Runtime

↓

Replay Result
```

Replay should recreate exactly what the system would have seen.

---

# Core Principles

## Replay Never Changes History

Replay is read-only.

It never:

- modifies state
- places orders
- writes positions

It only reconstructs.

---

## Deterministic

Given:

- identical events
- identical configuration
- identical strategy version

Replay must produce the same result.

---

## Event Driven

Replay consumes business events.

It does not parse application logs.

---

## Side-Effect Free

Replay never sends:

- Telegram messages
- Exchange orders
- Notifications

External integrations remain disabled.

---

# Replay Architecture

```text
                 Event Store

                       │

                       ▼

                Replay Engine

      ┌─────────┼─────────┬─────────┐

      ▼         ▼         ▼         ▼

 Position   Decision   Workflow   Metrics

      ▼         ▼         ▼         ▼

 Reconstructed Timeline

                       │

                       ▼

                  Replay Report
```

---

# Responsibilities

The Replay Engine owns:

- Event replay
- Timeline reconstruction
- State reconstruction
- Scenario playback
- Historical debugging
- Replay metrics

It does **not** own:

- Trading logic
- Position persistence
- Order execution
- Workflow scheduling

---

# Replay Sources

Replay consumes events from:

- Event Bus
- Event Store
- Trade History
- Workflow History
- Position History
- Decision History

Replay never consumes logs directly.

---

# Replay Levels

## Level 1

Event Replay

Reconstruct:

```
Signal

↓

Risk

↓

Execution
```

---

## Level 2

Trade Replay

Reconstruct

```
Entry

↓

Position

↓

Exit
```

---

## Level 3

Workflow Replay

Reconstruct

```
Trade Workflow

↓

Journal Workflow

↓

Research Workflow
```

---

## Level 4

System Replay

Reconstruct

Entire runtime.

---

# Replay Timeline

Example

```text
09:00

SignalDetected

↓

09:00:02

RiskApproved

↓

09:00:03

OrderSubmitted

↓

09:00:05

OrderFilled

↓

09:00:05

PositionOpened

↓

10:20

TrailingActivated

↓

11:40

PositionClosed

↓

11:40

TradeCompleted
```

Every event becomes observable.

---

# Replay Modes

## Trade Replay

Replay one trade.

Example

```
Trade

#58291
```

---

## Symbol Replay

Replay

```
BTCUSDT

Last Month
```

---

## Strategy Replay

Replay

```
Momentum Strategy

January
```

---

## Workflow Replay

Replay

```
Trade Workflow

ID

2031
```

---

## Full Session Replay

Replay

```
Entire Trading Day
```

---

# Replay Pipeline

```text
Load Events

↓

Sort Timeline

↓

Restore State

↓

Execute Replay

↓

Capture Output

↓

Generate Report
```

No external communication occurs.

---

# State Reconstruction

Replay rebuilds:

- Orders
- Positions
- Decisions
- Workflows
- Policies
- Memory

Example

```text
Order Filled

↓

Position Open

↓

Trailing Enabled

↓

Position Closed
```

State is reconstructed exactly as it existed.

---

# Event Ordering

Replay preserves:

- timestamp
- sequence number
- aggregate version

Ordering is deterministic.

---

# Replay Context

Every replay loads:

- strategy version
- configuration
- policy version
- market snapshot
- runtime metadata

This guarantees reproducibility.

---

# Event Store

Future architecture

```text
Event Store

├── Market Events

├── Order Events

├── Position Events

├── Workflow Events

├── Decision Events

├── Journal Events

└── System Events
```

Replay reads from the Event Store.

---

# Replay Report

Example

```text
Replay

Trade #521

Duration

3h 18m

Events

41

Warnings

0

Result

Identical

PnL

+4.1%
```

---

# Debugging

Replay enables debugging such as:

Example

```
Duplicate Exit

↓

Replay

↓

Timeline

↓

Find

Second Exit Request
```

Instead of searching logs.

---

# Regression Testing

Replay enables regression validation.

Example

```
Historical Trade

↓

New Exit Engine

↓

Replay

↓

Result

Same?

↓

Pass
```

Architecture changes become measurable.

---

# Strategy Validation

Example

```
Current Strategy

↓

Replay

↓

Compare

↓

Improved?

↓

Deploy
```

Replay supports safe experimentation.

---

# AI Integration

Replay supports AI.

Example

```text
Replay

↓

Trade Timeline

↓

Claude

↓

Generate

Post Mortem
```

AI never executes replay.

AI only analyzes results.

---

# Workflow Integration

Workflow

↓

Replay

↓

Restore

↓

Continue Analysis

Replay never resumes production workflows.

---

# Memory Integration

Replay

↓

Trade Memory

↓

Lessons Learned

Memory stores conclusions.

Replay reconstructs facts.

---

# Position Manager Integration

Replay reconstructs:

```
PositionOpened

↓

PositionReduced

↓

PositionClosed
```

without modifying Position Manager.

---

# Repository Structure

Recommended package

```text
src/replay/

├── engine.py

├── player.py

├── timeline.py

├── state.py

├── loader.py

├── event_store.py

├── report.py

├── comparison.py

├── metrics.py

└── models.py
```

---

# Replay API

Example

```python
ReplayEngine.replay_trade(trade_id)

ReplayEngine.replay_workflow(workflow_id)

ReplayEngine.replay_symbol(symbol)

ReplayEngine.replay_session(session_id)
```

---

# Replay Report Output

Every replay produces:

- Timeline
- State transitions
- Event count
- Decision trace
- Exit reason
- Strategy version
- Runtime duration
- Warnings

---

# Migration Strategy

## Phase 1

Persist business events.

---

## Phase 2

Replay single trades.

---

## Phase 3

Replay workflows.

---

## Phase 4

Replay complete sessions.

---

## Phase 5

Replay integrated into CI/CD.

---

# Rollback Strategy

Replay is isolated.

Disabling Replay Engine has zero production impact.

---

# Testing Strategy

Replay validation includes:

- Event ordering
- State reconstruction
- Timeline consistency
- Regression comparison
- Historical validation
- Performance benchmarking

Replay itself must be deterministic.

---

# Success Criteria

Replay implementation is complete when:

- Every trade can be replayed.
- Every workflow can be reconstructed.
- Every position transition is reproducible.
- Replay produces identical deterministic outcomes.
- Architecture changes are validated through replay.
- Debugging no longer depends primarily on log inspection.

---

# Risks

| Risk | Mitigation |
|------|------------|
| Missing events | Business Event Catalog |
| Event ordering | Aggregate versioning |
| Storage growth | Event retention policies |
| Replay drift | Versioned configuration |
| Performance | Incremental loading |

---

# Future Evolution

Future capabilities include:

- Interactive replay UI
- Time-travel debugging
- Side-by-side strategy comparison
- Historical market simulation
- Paper trading from replay
- AI-assisted root cause analysis
- Compliance reporting
- Replay-driven regression testing in CI

---

# Relationship with Other Components

| Component | Responsibility |
|-----------|----------------|
| Event Bus | Publishes events |
| Event Store | Persists events |
| Replay Engine | Reconstructs history |
| Memory | Learns from history |
| Workflow Engine | Executes business processes |
| Decision Engine | Produces recommendations |
| Position Manager | Owns live position state |

Replay is entirely observational.

It never becomes part of the production execution path.

---

# Architectural Benefits

The Replay Engine transforms Karsa from a system that merely records activity into one that can **reconstruct and explain its own behavior**.

Rather than relying on scattered logs and manual investigation, every historical trading session becomes reproducible.

This provides:

- Deterministic debugging
- Explainable trading decisions
- Safe architecture refactoring
- Replay-based regression testing
- AI-assisted post-mortem analysis
- Strategy comparison
- Operational auditing
- Compliance support

Most importantly, Replay ensures that every architectural change can be validated against historical production behavior before deployment.

It becomes the foundation for **confidence-driven development**, allowing Karsa to evolve safely while preserving deterministic execution.