# Concurrency & Async Safety Audit

Because Karsa runs an autonomous session loop every 15 minutes while simultaneously handling risk management tasks, its `asyncio` event loop must remain unblocked. A single synchronous `time.sleep()` or HTTP request could freeze the bot during a flash crash.

### The Verdict: Safe & Well-Architected
I scanned the entire repository for blocking calls (`time.sleep`, `requests.get`, `urllib.request`) that could disrupt the event loop.

### Key Findings

**1. No Blocking Sleeps**
- There is absolutely zero usage of `time.sleep()` in the execution path. All delays correctly use `await asyncio.sleep()`, allowing other tasks (like the kill switch or risk monitors) to continue running in the background.

**2. Safe Synchronous Fallbacks**
- In `src/advisory/crypto_regime.py`, there is a legacy `urllib.request` call to CoinGecko. However, it is perfectly wrapped in `await asyncio.to_thread(_fetch)`. This is the exact correct pattern to prevent a synchronous HTTP request from blocking the async loop.

**3. Asynchronous Broker Clients**
- The `BybitClient` and all data clients (`defillama`, `onchain`) are properly utilizing `aiohttp`, ensuring maximum concurrency.

### Recommendation
**Action**: None. The concurrency model is solid. The bot will not lock up under heavy API load.
