# Sequence Diagrams

**Document ID:** KARSA-ARCH-016  
**Title:** Business Sequence Diagrams  
**Version:** 1.0 (Draft)  
**Status:** Architecture Contract  
**Author:** Karsa Architecture Team  
**Last Updated:** July 2026

---

# Purpose

This document defines the **runtime interaction sequences** between major Karsa components.

Unlike the **State Machine** document, which describes how a single entity changes state, this document explains:

> **How multiple components collaborate to accomplish a business operation.**

Every sequence diagram should describe:

- participating components
- execution order
- published events
- ownership boundaries
- failure handling

---

# Sequence Design Principles

Every sequence should satisfy:

- One business objective
- Clear ownership
- Deterministic execution
- Event-driven communication
- Replay compatibility

---

# Trading Lifecycle

The complete trading lifecycle.

```mermaid
sequenceDiagram

participant Analyzer
participant Decision
participant Policy
participant Risk
participant Execution
participant OMS
participant Position
participant EventBus
participant Exit

Analyzer->>Decision: SignalDetected

Decision->>Policy: Evaluate()

Policy-->>Decision: PASS

Decision->>Risk: Validate()

Risk-->>Decision: APPROVED

Decision->>Execution: ExecuteTrade()

Execution->>OMS: SubmitOrder()

OMS-->>Execution: OrderFilled

Execution->>Position: OpenPosition()

Position->>EventBus: PositionOpened

EventBus-->>Exit: PositionOpened
```

---

# Position Open

```mermaid
sequenceDiagram

participant OMS
participant PositionManager
participant EventBus
participant Telegram
participant Metrics
participant Replay

OMS->>PositionManager: OrderFilled

PositionManager->>PositionManager: Create Position

PositionManager->>EventBus: PositionOpened

EventBus-->>Telegram: Notify

EventBus-->>Metrics: Update

EventBus-->>Replay: Store Event
```

---

# Stop Loss Trigger

```mermaid
sequenceDiagram

participant Market
participant ExitEngine
participant PositionManager
participant Execution
participant OMS
participant EventBus

Market->>ExitEngine: Price Update

ExitEngine->>ExitEngine: Evaluate SL

ExitEngine->>PositionManager: Close Position

PositionManager->>Execution: Submit Exit

Execution->>OMS: Market Sell

OMS-->>PositionManager: Filled

PositionManager->>EventBus: PositionClosed
```

---

# Break Even Activation

```mermaid
sequenceDiagram

participant Market
participant ExitEngine
participant PositionManager
participant EventBus

Market->>ExitEngine: Price Update

ExitEngine->>ExitEngine: Profit >= 1R?

ExitEngine->>PositionManager: Move SL

PositionManager->>EventBus: BreakEvenActivated
```

---

# Trailing Stop

```mermaid
sequenceDiagram

participant Market
participant ExitEngine
participant PositionManager
participant EventBus

Market->>ExitEngine: Price Update

ExitEngine->>ExitEngine: Calculate ATR

ExitEngine->>PositionManager: Update Trailing

PositionManager->>EventBus: TrailingActivated
```

---

# Partial Exit

```mermaid
sequenceDiagram

participant Market
participant ExitEngine
participant PositionManager
participant Execution
participant OMS

Market->>ExitEngine: Price Update

ExitEngine->>ExitEngine: Target Reached

ExitEngine->>PositionManager: Reduce Position

PositionManager->>Execution: Sell 50%

Execution->>OMS: Submit Order

OMS-->>PositionManager: Filled
```

---

# Time Exit

```mermaid
sequenceDiagram

participant Scheduler
participant ExitEngine
participant PositionManager
participant Execution

Scheduler->>ExitEngine: Evaluate Time Exit

ExitEngine->>ExitEngine: Holding > 48h?

ExitEngine->>PositionManager: Close Position

PositionManager->>Execution: Execute Exit
```

---

# Position Reconciliation

```mermaid
sequenceDiagram

participant Scheduler
participant Exchange
participant PositionManager
participant Database

Scheduler->>Exchange: Fetch Positions

Exchange-->>PositionManager: Exchange State

PositionManager->>Database: Local State

PositionManager->>PositionManager: Compare

PositionManager->>Database: Repair Differences
```

---

# Trade Completion

```mermaid
sequenceDiagram

participant PositionManager
participant EventBus
participant Journal
participant Memory
participant Replay

PositionManager->>EventBus: PositionClosed

EventBus-->>Journal: Generate Journal

EventBus-->>Memory: Store Trade

EventBus-->>Replay: Record Event
```

---

# Decision Engine

```mermaid
sequenceDiagram

participant Analyzer
participant Portfolio
participant AI
participant Decision
participant Policy

Analyzer->>Decision: Recommendation

Portfolio->>Decision: Exposure

AI->>Decision: Research

Decision->>Policy: Validate

Policy-->>Decision: PASS

Decision-->>Analyzer: Approved
```

---

# Policy Evaluation

```mermaid
sequenceDiagram

participant Decision
participant Policy
participant Risk

Decision->>Policy: Evaluate

Policy->>Policy: Trading Rules

Policy->>Policy: Portfolio Rules

Policy->>Policy: Emergency Rules

Policy-->>Risk: PASS
```

Alternative:

```mermaid
sequenceDiagram

participant Decision
participant Policy

Decision->>Policy: Evaluate

Policy-->>Decision: REJECT
```

---

# Workflow Execution

```mermaid
sequenceDiagram

participant Workflow
participant Agent
participant EventBus

Workflow->>Agent: Execute Research

Agent-->>Workflow: Completed

Workflow->>EventBus: WorkflowCompleted
```

---

# Workflow Waiting

```mermaid
sequenceDiagram

participant Workflow
participant EventBus

Workflow->>Workflow: Wait OrderFilled

EventBus-->>Workflow: OrderFilled

Workflow->>Workflow: Resume
```

---

# Agent Execution

```mermaid
sequenceDiagram

participant Scheduler
participant Runtime
participant Analyzer

Scheduler->>Runtime: Schedule Task

Runtime->>Analyzer: Execute

Analyzer-->>Runtime: Result

Runtime-->>Scheduler: Complete
```

---

# Replay

```mermaid
sequenceDiagram

participant Replay
participant EventStore
participant Timeline
participant Report

Replay->>EventStore: Load Events

EventStore-->>Replay: Events

Replay->>Timeline: Reconstruct

Timeline-->>Replay: Complete

Replay->>Report: Generate
```

---

# Memory Update

```mermaid
sequenceDiagram

participant Journal
participant Memory

Journal->>Memory: Store Trade

Memory->>Memory: Categorize

Memory->>Memory: Index

Memory-->>Journal: Complete
```

---

# Emergency Shutdown

```mermaid
sequenceDiagram

participant Admin
participant Policy
participant Execution
participant Workflow
participant Telegram

Admin->>Policy: Activate Kill Switch

Policy->>Execution: Stop Orders

Policy->>Workflow: Cancel Workflows

Policy->>Telegram: Notify Users
```

---

# Startup Sequence

```mermaid
sequenceDiagram

participant Runtime
participant Config
participant Database
participant Redis
participant Exchange
participant EventBus

Runtime->>Config: Load

Runtime->>Database: Connect

Runtime->>Redis: Connect

Runtime->>Exchange: Connect

Runtime->>EventBus: Initialize

Runtime-->>Runtime: Ready
```

---

# Shutdown Sequence

```mermaid
sequenceDiagram

participant Runtime
participant Workflow
participant Exchange
participant Database

Runtime->>Workflow: Stop

Workflow-->>Runtime: Completed

Runtime->>Exchange: Disconnect

Runtime->>Database: Flush

Runtime-->>Runtime: Shutdown
```

---

# Crash Recovery

```mermaid
sequenceDiagram

participant Runtime
participant Workflow
participant Position
participant Exchange

Runtime->>Workflow: Load Checkpoints

Runtime->>Position: Load Positions

Runtime->>Exchange: Sync

Exchange-->>Position: Current State

Position-->>Runtime: Recovered
```

---

# Event Publishing

```mermaid
sequenceDiagram

participant Position
participant EventBus
participant Telegram
participant Metrics
participant Replay

Position->>EventBus: Publish

par Notify
EventBus->>Telegram: PositionOpened
and Metrics
EventBus->>Metrics: PositionOpened
and Replay
EventBus->>Replay: PositionOpened
end
```

---

# Event Replay

```mermaid
sequenceDiagram

participant Replay
participant EventStore
participant Position
participant Decision

Replay->>EventStore: Read Events

EventStore-->>Replay: Stream

Replay->>Decision: Replay Decisions

Replay->>Position: Replay Position

Position-->>Replay: State Restored
```

---

# Failure Scenario — Order Rejected

```mermaid
sequenceDiagram

participant OMS
participant EventBus
participant Journal
participant Telegram

OMS->>EventBus: OrderRejected

EventBus->>Journal: Record

EventBus->>Telegram: Notify
```

---

# Failure Scenario — Exchange Disconnect

```mermaid
sequenceDiagram

participant Exchange
participant Runtime
participant Monitoring

Exchange--x Runtime: Connection Lost

Runtime->>Runtime: Retry

Runtime->>Monitoring: Health Alert

Runtime->>Exchange: Reconnect
```

---

# Component Interaction Matrix

| Sequence | Primary Owner |
|----------|---------------|
| Trading Lifecycle | Decision Engine |
| Position Open | Position Manager |
| Exit | Exit Engine |
| Workflow | Workflow Engine |
| Replay | Replay Engine |
| Agent Execution | Agent Runtime |
| Policy Evaluation | Policy Engine |
| Memory Update | Memory Manager |
| Startup | Runtime |
| Recovery | Runtime |

---

# Design Guidelines

Every new feature added to Karsa should include:

- A sequence diagram
- A state machine
- Published events
- Consumed events
- Failure sequence
- Recovery sequence

No major business feature should be implemented without documenting its interaction flow first.

---

# Summary

These sequence diagrams define the **runtime collaboration model** for Karsa.

They complement the:

- **State Machines** (entity lifecycle)
- **Event Catalog** (business contracts)
- **Workflow Engine** (long-running orchestration)

Together, these documents form the executable architectural blueprint for implementing, testing, replaying, and evolving Karsa while preserving deterministic execution and production safety.