# Current Architecture

**Document ID:** KARSA-ARCH-001  
**Title:** Current Architecture Assessment  
**Version:** 1.0 (Draft)  
**Status:** Architecture Audit  
**Author:** Karsa Architecture Team  
**Last Updated:** July 2026

---

# Purpose

This document describes the **current production architecture** of Karsa.

Unlike the Target Architecture document, this document is descriptive rather than prescriptive. It captures how the system works today, identifies architectural strengths, highlights technical debt, and establishes the baseline for future migration.

This document should always reflect the current production implementation.

---

# Scope

This document covers:

- High-level architecture
- Core modules
- Responsibility boundaries
- Runtime flow
- Trading lifecycle
- Component dependencies
- Architectural strengths
- Current technical debt
- Production observations

It intentionally does **not** describe the proposed architecture. Those changes are documented separately.

---

# System Overview

Karsa is currently a modular algorithmic trading platform designed around domain-oriented services.

The architecture has evolved organically through multiple iterations and now consists of several independent subsystems.

Current responsibilities include:

- Market analysis
- Trading advisory
- Risk management
- Portfolio management
- Order execution
- Position synchronization
- Exit management
- Telegram notifications
- Metrics
- Monitoring
- Backtesting

Although the architecture is modular, communication between modules is primarily synchronous.

---

# High-Level Architecture

```text
                        User
                         │
                         ▼
                  Telegram Bot
                         │
                         ▼
                    Analyzer
                         │
                         ▼
                    Advisory
                         │
                         ▼
                    Risk Layer
                         │
              ┌──────────┴──────────┐
              ▼                     ▼
     Portfolio Allocator     Position Manager
              │                     │
              └──────────┬──────────┘
                         ▼
                 Execution Layer
                         │
              ┌──────────┴──────────┐
              ▼                     ▼
               OMS            Stop Loss Engine
                         │
                         ▼
                     Exchange
```

---

# Layered Architecture

Current architecture can be grouped into five logical layers.

---

## Layer 1 — Presentation

Responsibilities:

- Telegram commands
- User interaction
- Notifications
- Manual trading actions

Primary modules:

```
src/bot/
```

---

## Layer 2 — Analysis

Responsibilities:

- Market analysis
- Signal generation
- Trading advisory
- Recommendations

Primary modules:

```
src/agents/

src/advisory/
```

Outputs:

- Buy recommendations
- Sell recommendations
- Portfolio advice

---

## Layer 3 — Risk

Responsibilities:

- Position sizing
- Portfolio allocation
- Stop loss
- Trailing stop
- Exposure management
- Position synchronization

Primary modules:

```
src/risk/
```

This is currently one of the largest domains in the project.

---

## Layer 4 — Execution

Responsibilities:

- Order creation
- Order validation
- Exchange interaction
- Order lifecycle
- Stop-loss execution

Primary modules:

```
src/execution/
```

Contains:

- OMS
- SL Engine
- Exchange adapters

---

## Layer 5 — Infrastructure

Responsibilities:

- Redis
- Database
- Metrics
- Logging
- Configuration

Supports all upper layers.

---

# Current Trading Flow

The current trading lifecycle is approximately:

```text
Market Data

↓

Analyzer

↓

Advisory

↓

Risk Validation

↓

Portfolio Allocation

↓

Execution

↓

OMS

↓

Exchange

↓

Position Synchronization

↓

Trailing Stop

↓

Stop Loss

↓

Position Closed
```

Most communication occurs through direct service invocation.

---

# Existing Domains

## Analyzer

Responsibilities

- Analyze market data
- Produce trading signals
- Generate recommendations

Characteristics

- Advisory
- Non-execution
- Market-facing

---

## Advisory

Responsibilities

- Explain signals
- Produce recommendations
- Generate human-readable output

Characteristics

- AI-assisted
- Non-critical
- User-facing

---

## Risk

Responsibilities

- Exposure calculation
- Leverage validation
- Portfolio allocation
- Position synchronization
- Stop-loss management
- Trailing stop

Characteristics

- Deterministic
- Production critical

Observation:

The Risk domain currently owns several unrelated responsibilities.

---

## Execution

Responsibilities

- Execute approved trades
- Submit orders
- Track fills
- Manage order lifecycle

Characteristics

- Deterministic
- Latency sensitive

---

## OMS

Responsibilities

- Manage order state
- Track fills
- Maintain execution status

Characteristics

- Single order authority

Strength:

Well separated from market analysis.

---

## Stop Loss Engine

Responsibilities

- Monitor active positions
- Execute stop losses
- React to market events

Strength:

Independent from trading strategy.

Current limitation:

Exit responsibilities are fragmented across multiple modules.

---

# Current Position Ownership

One of the most important architectural observations.

Today position state is influenced by multiple services.

Examples include:

```
Position Manager

Position Sync

Trailing Stop

Profit Lock

Stop Loss Engine

Execution
```

This results in multiple writers.

Potential issues:

- race conditions
- duplicated reconciliation
- unclear ownership
- difficult debugging

Current architecture lacks a single authoritative position lifecycle manager.

---

# Current Exit Logic

Exit behaviour is currently distributed.

Examples

```
Trailing Stop

Profit Lock

Stop Loss

Manual Close

Time Exit
```

Each service independently evaluates exit conditions.

Although functional, this increases maintenance complexity.

---

# Runtime Communication

Current communication model:

```text
Analyzer

↓

Risk

↓

Execution

↓

OMS

↓

Telegram
```

Characteristics

- synchronous
- tightly coupled
- request driven

Missing capability

Publish / Subscribe

---

# Architectural Strengths

## Excellent Domain Separation

Compared to many open-source trading bots, Karsa already separates:

- analysis
- execution
- portfolio
- risk
- advisory

This provides a strong foundation.

---

## Mature Execution Layer

Execution logic is clearly isolated.

Advantages:

- deterministic
- testable
- production-oriented

---

## Mature Risk Layer

Current implementation already supports:

- trailing stop
- stop loss
- portfolio allocation
- synchronization

The challenge is not capability.

The challenge is ownership.

---

## Good Observability

Current platform already includes:

- metrics
- monitoring
- structured logging

These capabilities significantly reduce operational risk.

---

## AI Boundary

Current AI usage is already relatively well separated from execution.

This should be preserved.

---

# Architectural Weaknesses

## Tight Coupling

Services directly invoke other services.

Result

Higher maintenance cost.

---

## Position Ownership

Multiple services modify the same domain.

Result

Inconsistent lifecycle.

---

## Exit Fragmentation

Exit logic exists in multiple locations.

Result

Harder reasoning.

---

## Missing Event Model

No centralized event distribution.

Result

Every new integration requires direct dependency.

---

## Missing Workflow Layer

Long-running business processes are implicit.

Example

```
Open Position

↓

Wait Fill

↓

Wait Break Even

↓

Wait Trailing

↓

Close
```

These workflows are not explicitly represented.

---

## Missing Replay

Trade reconstruction is difficult.

Current implementation cannot replay the complete decision chain.

---

# Production Assessment

Current architecture is suitable for:

- personal trading
- automated trading
- small-scale deployment

Strengths outweigh weaknesses.

Most architectural improvements should focus on reducing coupling rather than replacing existing modules.

---

# Key Findings

The audit identified several important observations.

## Observation 1

Execution architecture is already strong.

Do not rewrite it.

---

## Observation 2

Risk capabilities are mature.

Responsibilities should be reorganized rather than redesigned.

---

## Observation 3

The largest architectural issue is fragmented ownership of position state.

This should become the highest priority migration target.

---

## Observation 4

Most future improvements can be introduced through infrastructure rather than business logic changes.

Examples

- Event Bus
- Position Manager
- Exit Engine
- Replay Engine

---

## Observation 5

Current AI integration is already aligned with deterministic execution principles.

This separation should remain.

---

# Summary

Overall maturity assessment:

| Domain | Assessment |
|---------|------------|
| Execution | Excellent |
| OMS | Excellent |
| Risk | Very Good |
| Portfolio | Good |
| Advisory | Good |
| AI Integration | Good |
| Monitoring | Very Good |
| Architecture | Good |
| Event Model | Missing |
| Workflow | Missing |
| Replay | Missing |

Overall architectural maturity is estimated at **70–80%** of the proposed target architecture.

The remaining work is focused primarily on improving coordination, ownership, and extensibility rather than replacing existing business logic.

This assessment establishes the baseline for the Gap Analysis and Target Architecture documents that follow.