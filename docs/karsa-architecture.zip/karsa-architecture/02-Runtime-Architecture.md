# Runtime Architecture

**Document ID:** KARSA-ARCH-002  
**Title:** Current Runtime Architecture  
**Version:** 1.0 (Draft)  
**Status:** Architecture Assessment  
**Author:** Karsa Architecture Team  
**Last Updated:** July 2026

---

# Purpose

This document describes **how Karsa executes at runtime**, rather than how the source code is organized.

Unlike the Current Architecture document, which focuses on logical components and responsibilities, this document explains:

- Runtime lifecycle
- Startup sequence
- Background workers
- Service interaction
- Runtime dependencies
- Data flow
- Failure recovery
- Current runtime limitations

Understanding the runtime is essential before introducing architectural changes such as Event Bus, Position Manager, Workflow Engine, or Agent Runtime.

---

# Runtime Philosophy

Karsa is fundamentally an **event-reactive trading system**.

The system continuously reacts to:

- Market events
- User commands
- Exchange updates
- Position updates
- Timer-based tasks
- Internal state changes

Although the architecture is service-oriented, the runtime already behaves similarly to an event-driven platform.

---

# Runtime Overview

```text
                        Process Startup
                               │
                               ▼
                    Configuration Loader
                               │
                               ▼
                    Dependency Initialization
                               │
      ┌────────────────────────┼────────────────────────┐
      ▼                        ▼                        ▼
 Redis Connection        Database             Exchange Client
      │                        │                        │
      └───────────────┬────────┴───────────────┬────────┘
                      ▼
              Runtime Initialization
                      │
      ┌───────────────┼────────────────────────────────┐
      ▼               ▼                ▼               ▼
 Analyzer       Scheduler        Telegram Bot     Monitoring
      │               │                │               │
      └───────────────┼────────────────┴───────────────┘
                      ▼
                 Trading Runtime
```

---

# Runtime Components

Current runtime consists of several long-running services.

## Configuration

Responsibilities

- Environment loading
- API keys
- Trading configuration
- Risk configuration

Loaded once during startup.

---

## Exchange Client

Responsibilities

- REST communication
- WebSocket communication
- Order submission
- Market data
- Position synchronization

Characteristics

- Long-lived connection
- External dependency
- Critical runtime component

---

## Redis

Responsibilities

- Runtime communication
- Distributed cache
- Pub/Sub (currently limited)
- Shared state

Current usage is primarily infrastructure support rather than architectural messaging.

---

## Database

Responsibilities

- Trade history
- Positions
- Signals
- Metrics
- Journal

Persistent storage.

---

## Scheduler

Responsibilities

Execute periodic jobs.

Examples

```
Market Scan

Portfolio Review

Position Sync

Funding Update

Cleanup

Health Check
```

Current scheduler executes independent tasks rather than workflow orchestration.

---

## Analyzer Runtime

Responsibilities

- Scan markets
- Analyze symbols
- Generate signals

Characteristics

CPU-bound

Stateless between executions.

---

## Risk Runtime

Responsibilities

- Validate positions
- Calculate exposure
- Evaluate stop losses
- Evaluate trailing stops

Runs whenever new trading activity occurs.

---

## Execution Runtime

Responsibilities

- Submit orders
- Track fills
- Monitor execution status

Latency-sensitive.

---

## Telegram Runtime

Responsibilities

- Receive commands
- Notify users
- Manual overrides

User interaction layer.

---

# Runtime Lifecycle

Current runtime approximately follows:

```text
Process Start

↓

Load Configuration

↓

Initialize Infrastructure

↓

Initialize Exchange

↓

Initialize Database

↓

Initialize Redis

↓

Start Background Tasks

↓

Start Telegram

↓

Start Analyzer

↓

Runtime Ready
```

Shutdown is the reverse sequence.

---

# Market Event Flow

Current runtime reacts to incoming market data.

```text
Market Tick

↓

Analyzer

↓

Signal

↓

Risk Validation

↓

Execution

↓

OMS

↓

Exchange

↓

Position Sync

↓

Trailing Stop

↓

Metrics

↓

Telegram
```

Most transitions occur synchronously.

---

# Position Runtime

Position management currently involves several independent services.

```text
Position Open

↓

Execution

↓

Position Manager

↓

Position Sync

↓

Trailing Stop

↓

Profit Lock

↓

Stop Loss

↓

Close Position
```

Observation

There is no single runtime owner.

Multiple services monitor and modify position state.

---

# Order Runtime

Current order lifecycle

```text
Trade Signal

↓

Risk Validation

↓

Order Creation

↓

OMS

↓

Exchange

↓

Order Fill

↓

Position Update
```

Strength

OMS provides centralized order tracking.

Weakness

Position state continues to evolve outside OMS.

---

# Exit Runtime

Current exit evaluation occurs in several independent services.

```text
Price Update

↓

Trailing Stop

↓

Profit Lock

↓

Stop Loss

↓

Manual Close

↓

Exchange
```

Each component independently evaluates exit conditions.

This increases runtime complexity.

---

# Background Jobs

Current runtime executes multiple scheduled tasks.

Examples

- Position synchronization
- Funding updates
- Portfolio review
- Health monitoring
- Market scanning
- Metrics collection

Characteristics

Independent

Periodic

Non-workflow aware.

---

# Runtime Threads

Conceptually, runtime consists of several concurrent execution paths.

```text
Main Runtime

├── Telegram

├── Analyzer

├── Scheduler

├── Exchange WebSocket

├── Metrics

├── Monitoring

└── Background Tasks
```

Each subsystem operates independently.

Synchronization occurs through service interaction.

---

# Runtime Dependencies

Current dependency graph

```text
Telegram

↓

Analyzer

↓

Risk

↓

Execution

↓

OMS

↓

Exchange
```

Infrastructure dependencies

```
Redis

Database

Configuration

Logging

Metrics
```

---

# Runtime State

Current runtime state exists in multiple locations.

Examples

```
Memory

Redis

Database

Exchange

Configuration
```

Observation

Runtime state ownership is distributed.

No centralized state registry exists.

---

# Failure Recovery

Current recovery strategy is component-based.

Examples

## Exchange Disconnect

Current behavior

Reconnect.

Resume market data.

---

## Telegram Failure

Restart polling.

Continue runtime.

---

## Scheduler Failure

Retry task.

Continue runtime.

---

## Order Failure

Handled within execution layer.

---

## Position Synchronization Failure

Retry synchronization.

---

Observation

Recovery mechanisms exist but are implemented independently.

There is no centralized runtime recovery coordinator.

---

# Runtime Observability

Current runtime already supports:

- Structured logging
- Metrics
- Health checks
- Notifications

Strength

Operational visibility is already relatively mature.

Future improvements should integrate with existing monitoring rather than replacing it.

---

# Runtime Limitations

## No Event Bus

Services communicate directly.

Result

Higher coupling.

---

## No Workflow Runtime

Business processes span multiple tasks.

Current runtime cannot checkpoint or resume workflows.

---

## No Replay Runtime

Past execution cannot be deterministically replayed.

---

## No Runtime Registry

No centralized registry exists for:

- active services
- capabilities
- runtime health
- ownership

---

## No Runtime State Machine

Components implement their own lifecycle.

Examples

```
Analyzer

Scheduler

Telegram

Execution
```

Each lifecycle is different.

---

# Runtime Maturity Assessment

| Capability | Status |
|------------|---------|
| Startup | Mature |
| Shutdown | Mature |
| Exchange Integration | Mature |
| Scheduler | Mature |
| Execution | Mature |
| OMS | Mature |
| Monitoring | Mature |
| Recovery | Good |
| Workflow | Missing |
| Event Runtime | Missing |
| Replay | Missing |
| Runtime Registry | Missing |

---

# Architectural Observations

## Observation 1

Current runtime is stable.

Most improvements should preserve existing runtime behavior.

---

## Observation 2

Execution runtime should remain deterministic.

Future AI integration must not modify execution timing.

---

## Observation 3

Infrastructure already supports future evolution.

Redis, logging, monitoring, and scheduling provide a strong foundation for introducing:

- Event Bus
- Replay Engine
- Workflow Engine

---

## Observation 4

Current runtime is service-oriented rather than event-oriented.

Introducing business events can significantly reduce coupling without changing business logic.

---

## Observation 5

Long-running trading processes currently emerge from multiple scheduled tasks rather than explicit workflow definitions.

This should become a dedicated runtime capability.

---

# Runtime Evolution Goals

The runtime should evolve toward:

```text
                    Karsa Runtime
                           │
        ┌──────────────────┼──────────────────┐
        ▼                  ▼                  ▼
   Workflow Engine     Event Bus      Runtime Registry
        │                  │                  │
        └──────────────┬───┴──────────────────┘
                       ▼
               Deterministic Services
        ┌─────────────────────────────────────┐
        │ Analyzer                           │
        │ Risk                               │
        │ Position Manager                   │
        │ Exit Engine                        │
        │ Execution                          │
        │ OMS                               │
        └─────────────────────────────────────┘
                       │
                       ▼
                  Exchange Client
```

The objective is not to replace the existing runtime, but to provide stronger coordination, clearer ownership, and safer long-running execution while preserving the deterministic behavior of the current production system.