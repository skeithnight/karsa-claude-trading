# Event Bus Architecture

**Document ID:** KARSA-ARCH-004  
**Title:** Event Bus Architecture & Business Event Model  
**Version:** 1.0 (Draft)  
**Status:** Proposed Architecture  
**Author:** Karsa Architecture Team  
**Last Updated:** July 2026

---

# Purpose

This document defines the **Event Bus architecture** for Karsa.

The Event Bus is the first architectural component introduced during the migration because it enables gradual decoupling of existing services **without changing business behavior**.

Unlike a message broker or queueing system, the Event Bus is primarily an **internal application integration layer** that allows independent components to react to business events.

---

# Why an Event Bus?

## Current Architecture

Today, components communicate through direct service invocation.

```text
Analyzer
    │
    ▼
Risk
    │
    ▼
Execution
    │
    ▼
OMS
    │
    ▼
Telegram
```

Problems:

- Tight coupling
- Hard to extend
- Difficult testing
- Multiple dependencies
- High maintenance cost

Every new feature requires modifying existing services.

---

## Proposed Architecture

Instead of direct communication:

```text
Execution
      │
      ▼
 Publish Event
      │
      ▼
 ┌──────────────────────┐
 │      Event Bus       │
 └──────────────────────┘
      │
 ┌────┼───────────┬──────────┐
 ▼    ▼           ▼          ▼
Telegram Metrics Journal Replay
```

Execution has no knowledge of downstream consumers.

---

# Architectural Goals

The Event Bus should provide:

- Loose coupling
- Business event distribution
- Asynchronous processing
- Extensibility
- Observability
- Replay support
- Minimal production impact

The Event Bus should **not** become a distributed messaging platform.

It remains an internal runtime abstraction.

---

# Design Principles

## 1. Business Events Only

Publish events that describe business outcomes.

Good:

```text
PositionOpened

PositionClosed

OrderFilled

TradeCompleted

RiskRejected
```

Bad:

```text
FunctionStarted

LoopExecuted

HandlerCalled

ContextLoaded
```

Technical implementation details are not business events.

---

## 2. Immutable Events

Events are immutable.

Once published:

- never modified
- never overwritten
- only consumed

This allows:

- replay
- auditing
- debugging

---

## 3. Fire-and-Forget

Publishers do not wait for subscribers.

Example

```text
Execution

↓

Publish PositionOpened

↓

Continue Execution
```

Telegram or Metrics failures must never affect trading execution.

---

## 4. At-Least-Once Delivery

Subscribers must assume duplicate delivery.

Every handler should be idempotent.

Example

```
PositionClosed

↓

Already processed?

↓

Ignore
```

---

## 5. Execution Never Depends on Subscribers

Trading continues even if:

- Telegram is offline
- Metrics fail
- Journal crashes

Execution is always isolated.

---

# Event Flow

Current

```text
Analyzer

↓

Risk

↓

Execution

↓

Telegram

↓

Metrics
```

Future

```text
Analyzer

↓

Risk

↓

Execution

↓

Publish PositionOpened

↓

Event Bus

↓

Telegram

Metrics

Journal

Replay

Dashboard
```

---

# Event Categories

Events are grouped by business domain.

---

## Market Events

Publisher

Analyzer

Examples

```
MarketScanned

SignalDetected

SignalRejected

RegimeChanged

VolatilityUpdated
```

---

## Risk Events

Publisher

Risk Service

Examples

```
RiskApproved

RiskRejected

ExposureExceeded

LeverageAdjusted
```

---

## Order Events

Publisher

OMS

Examples

```
OrderCreated

OrderSubmitted

OrderPartiallyFilled

OrderFilled

OrderCancelled

OrderRejected
```

---

## Position Events

Publisher

Position Manager

Examples

```
PositionOpened

PositionUpdated

BreakEvenActivated

TrailingActivated

PositionClosed
```

---

## Exit Events

Publisher

Exit Engine

Examples

```
StopLossTriggered

TrailingTriggered

TimeExitTriggered

EmergencyExitTriggered
```

---

## Portfolio Events

Publisher

Portfolio Service

Examples

```
PortfolioRebalanced

AllocationChanged

CashUpdated
```

---

## AI Events

Publisher

Analyzer Agent

Examples

```
ResearchCompleted

RecommendationGenerated

JournalGenerated
```

---

# Event Schema

Every event follows the same structure.

```json
{
  "eventId": "uuid",
  "eventType": "PositionOpened",
  "aggregateId": "BTCUSDT",
  "timestamp": "2026-07-05T12:30:00Z",
  "publisher": "PositionManager",
  "version": 1,
  "payload": {}
}
```

---

# Event Naming Convention

Format

```
<Noun><PastTenseVerb>
```

Examples

```
OrderFilled

PositionClosed

TradeCompleted

RiskRejected
```

Avoid

```
DoRisk

StartExecution

CheckSignal
```

Commands are not events.

---

# Publisher Responsibilities

Publishers:

- own business state
- create events
- never know subscribers

Example

```
Position Manager

↓

PositionOpened
```

Position Manager does not know:

- Telegram
- Metrics
- Dashboard
- Replay

---

# Subscriber Responsibilities

Subscribers:

- react
- never change publisher state

Example

```
Telegram

↓

PositionOpened

↓

Send Message
```

---

# Event Ownership

| Event | Publisher |
|--------|-----------|
| SignalDetected | Analyzer |
| RiskApproved | Risk Service |
| OrderSubmitted | OMS |
| OrderFilled | OMS |
| PositionOpened | Position Manager |
| PositionClosed | Position Manager |
| StopLossTriggered | Exit Engine |
| TradeCompleted | Exit Engine |
| JournalGenerated | Journal Agent |

Every event has exactly one publisher.

---

# Event Routing

Conceptually

```text
Publish

↓

Event Bus

↓

Find Subscribers

↓

Invoke Handlers
```

Publishers never perform routing.

---

# Event Bus Components

```text
Event Bus

├── Publisher API

├── Subscriber Registry

├── Event Dispatcher

├── Event Middleware

├── Retry Handler

├── Dead Letter Queue (Future)

└── Metrics
```

---

# Middleware Pipeline

Every event passes through:

```text
Publish

↓

Validation

↓

Logging

↓

Metrics

↓

Dispatch

↓

Subscribers
```

Future middleware may include:

- tracing
- replay recording
- authorization

---

# Error Handling

Subscriber failures never stop publishers.

Example

```text
PositionOpened

↓

Telegram Error

↓

Retry

↓

Execution continues
```

Trading remains unaffected.

---

# Event Replay

Every published event may optionally be persisted.

Future

```text
Event Store

↓

Replay Engine

↓

Reconstruct Runtime
```

Replay is a consumer of events, not part of execution.

---

# Migration Strategy

## Phase 1

Introduce Event Bus.

Publish events.

No subscribers.

Behavior unchanged.

---

## Phase 2

Convert:

- Telegram
- Metrics
- Journal

into subscribers.

---

## Phase 3

Convert Dashboard.

---

## Phase 4

Position Manager publishes Position events.

---

## Phase 5

Exit Engine publishes Exit events.

---

# Implementation Strategy

Recommended interfaces

```python
class EventPublisher:
    publish(event)

class EventSubscriber:
    handle(event)

class EventBus:
    register(subscriber)
    publish(event)
```

Publishers depend only on `EventPublisher`.

Subscribers implement `EventSubscriber`.

---

# Technology Considerations

### Initial Implementation

In-process event dispatcher.

Advantages:

- Simple
- Fast
- No infrastructure changes
- Easy rollback

---

### Future Evolution

Optional:

- Redis Pub/Sub
- Kafka
- NATS

Only when scaling requires distributed messaging.

Current production does not justify this complexity.

---

# Success Criteria

The Event Bus migration is successful when:

- Existing behavior remains unchanged.
- Telegram no longer receives direct calls.
- Metrics become event-driven.
- Journal becomes event-driven.
- Execution does not depend on downstream consumers.
- New integrations require only event subscriptions.

---

# Risks

| Risk | Mitigation |
|------|------------|
| Duplicate delivery | Idempotent subscribers |
| Subscriber failure | Retry independently |
| Event ordering | Use aggregate ordering where required |
| Performance overhead | In-process dispatcher initially |
| Event explosion | Publish business events only |

---

# Architectural Benefits

Introducing the Event Bus provides:

- Lower coupling
- Cleaner module boundaries
- Easier testing
- Simpler feature additions
- Better observability
- Event replay support
- Foundation for Workflow Engine
- Foundation for Agent Runtime

Importantly, these benefits are achieved **without modifying the existing trading logic**, making the Event Bus the safest first step in Karsa's architectural evolution.