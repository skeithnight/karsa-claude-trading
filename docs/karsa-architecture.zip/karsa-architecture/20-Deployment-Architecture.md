# Deployment Architecture

**Document ID:** KARSA-ARCH-020  
**Title:** Deployment Architecture & Infrastructure Topology  
**Version:** 1.0 (Draft)  
**Status:** Proposed Architecture  
**Author:** Karsa Architecture Team  
**Last Updated:** July 2026

---

# Purpose

This document defines the **physical deployment architecture** of Karsa.

Unlike the logical architecture documents, this document answers:

- Where does each component run?
- How do services communicate?
- Which components are stateful?
- Which components are horizontally scalable?
- Which components require high availability?

The objective is to provide a deployment model that supports:

- production reliability
- incremental scaling
- fault isolation
- observability
- future distributed execution

---

# Deployment Philosophy

Karsa is designed to evolve through **four infrastructure stages**.

The software architecture remains consistent while the infrastructure gradually becomes more distributed.

```text
Stage 1

Single Machine

↓

Stage 2

Home Lab Cluster

↓

Stage 3

Production Cluster

↓

Stage 4

Distributed Runtime
```

---

# Infrastructure Principles

## Stateless Services

Whenever possible:

- Decision Engine
- Exit Engine
- Workflow Engine
- Agent Runtime

should remain stateless.

---

## Stateful Components

State should exist only in:

- PostgreSQL
- Redis
- Event Store
- Object Storage

---

## Horizontal Scaling

Adding nodes should increase capacity without changing business logic.

---

## Infrastructure Independence

Business services should not depend on deployment topology.

---

# Stage 1 — Development

Single machine.

```text
                 Developer Laptop

--------------------------------------------------------

CLI

Telegram Bot

Dashboard

Trading Runtime

PostgreSQL

Redis

Binance Testnet

--------------------------------------------------------
```

Characteristics

- Local development
- Docker Compose
- Single database
- Single Redis
- No HA

---

# Stage 2 — Home Lab

Recommended for continuous operation.

```text
                 Home Network

                 ┌───────────────┐
                 │ Reverse Proxy │
                 └───────┬───────┘
                         │
         ┌───────────────┴──────────────┐
         │                              │
         ▼                              ▼
 Trading Runtime                Dashboard/API
         │                              │
         └───────────────┬──────────────┘
                         │
          ┌──────────────┴─────────────┐
          ▼                            ▼
      PostgreSQL                    Redis
                         │
                         ▼
                     Binance
```

Suitable for:

- Paper trading
- Small production
- Personal infrastructure

---

# Stage 3 — Production

Logical deployment.

```text
                         Internet

                             │

                    Reverse Proxy / Load Balancer

                             │

      ┌──────────────────────┼──────────────────────┐

      ▼                      ▼                      ▼

 Telegram API          Dashboard API          REST API

                             │

                     Trading Runtime Cluster

        ┌─────────────┬──────────────┬──────────────┐

        ▼             ▼              ▼

 Decision      Position Manager   Workflow Engine

 Engine

        ▼             ▼              ▼

 Exit Engine    Policy Engine   Agent Runtime

                             │

                             ▼

                     OMS / Exchange Gateway

                             │

                         Binance

                             │

      ┌──────────────────────┼──────────────────────┐

      ▼                      ▼                      ▼

 PostgreSQL              Redis              Object Storage
```

---

# Stage 4 — Distributed Platform

Future deployment.

```text
                 Global Architecture

                    API Gateway

                         │

       ┌─────────────────┼─────────────────┐

       ▼                 ▼                 ▼

 Trading Cluster   Research Cluster   Dashboard Cluster

       │                 │                 │

       ▼                 ▼                 ▼

 Position         Agent Runtime      Web Frontend

 Exit Engine      Workflow

 Decision         Memory

 OMS

       └─────────────────┬─────────────────┘

                         ▼

                  Shared Infrastructure

           PostgreSQL

           Redis

           Event Store

           Vector Database

           Object Storage
```

---

# Runtime Components

## Trading Runtime

Contains

- Analyzer
- Decision Engine
- Risk
- Position Manager
- Exit Engine
- OMS

Requirements

- Low latency
- High availability

---

## Research Runtime

Contains

- Agent Runtime
- Research
- Planner
- Journal

Requirements

- High throughput
- GPU optional

Trading never depends on this runtime.

---

## Dashboard Runtime

Contains

- REST API
- Authentication
- UI
- Monitoring

Completely independent.

---

# Database Architecture

Recommended

```text
                PostgreSQL

────────────────────────────────────

Orders

Positions

Trades

Policies

Workflows

Users

Configurations

────────────────────────────────────
```

Only business state belongs here.

---

# Redis Architecture

Redis responsibilities

```text
Redis

├── Event Pub/Sub

├── Distributed Lock

├── Cache

├── Rate Limiting

├── Session

└── Temporary Queue
```

Redis is **not** the source of truth.

---

# Event Store

Future deployment

```text
Event Store

├── Position Events

├── Order Events

├── Workflow Events

├── Decision Events

└── Replay Events
```

Used by

- Replay
- Auditing
- Historical analysis

---

# Object Storage

Purpose

Store

- reports
- journals
- exports
- replay archives
- historical datasets

Examples

- S3
- MinIO

---

# Vector Database (Future)

Supports

- semantic search
- RAG
- trade similarity
- research memory

Examples

- Qdrant
- pgvector
- Weaviate

Not required for production trading.

---

# External Services

```text
External

├── Binance

├── Telegram

├── Email

├── Slack

├── Grafana

├── Prometheus

└── Ollama / Claude / OpenAI
```

All accessed through adapters.

---

# Network Segmentation

```text
Internet

↓

DMZ

↓

API Layer

↓

Trading Runtime

↓

Database Network
```

Trading services should never be directly exposed to the Internet.

---

# Service Communication

Preferred communication

```text
Queries

↓

Direct API
```

```text
Business Events

↓

Event Bus
```

Avoid synchronous service chains longer than three hops.

---

# Container Layout

Each major component becomes an independent container.

```text
Docker

├── trading-runtime

├── dashboard

├── telegram-bot

├── postgres

├── redis

├── nginx

├── monitoring

└── replay-worker
```

---

# Kubernetes Layout (Future)

```text
Namespace

karsa-core

├── trading-runtime

├── decision-engine

├── workflow-engine

├── position-manager

├── exit-engine

├── replay

├── policy-engine

└── oms
```

Research

```text
Namespace

karsa-ai

├── agent-runtime

├── research

├── planner

├── memory

└── ollama
```

---

# Scaling Strategy

## Stateless

Scale horizontally.

Examples

- Dashboard
- Replay
- Workflow
- Agent Runtime

---

## Stateful

Scale carefully.

Examples

- PostgreSQL
- Redis

---

## Singleton

Examples

Position Manager

OMS

These should have only one active leader.

---

# High Availability

Recommended

```text
Load Balancer

↓

Trading Runtime A

Trading Runtime B

↓

Shared Database

↓

Shared Redis
```

Leader election prevents duplicate execution.

---

# Disaster Recovery

Backup

- PostgreSQL
- Event Store
- Configuration
- Policies

Recovery sequence

```text
Restore Database

↓

Restore Event Store

↓

Replay

↓

Resume Trading
```

---

# Deployment Pipeline

```text
Git Push

↓

Build

↓

Unit Tests

↓

Integration Tests

↓

Replay Validation

↓

Docker Image

↓

Registry

↓

Deploy

↓

Shadow Mode

↓

Production
```

---

# Configuration Management

Configuration hierarchy

```text
Default

↓

Environment

↓

Secrets

↓

Runtime Overrides
```

Secrets should never be stored in Git.

---

# Secrets Management

Examples

- Binance API Keys
- Telegram Token
- Database Password
- Redis Password
- AI API Keys

Recommended

- Docker Secrets
- Kubernetes Secrets
- Vault

---

# Environment Strategy

```text
Development

↓

QA

↓

Paper Trading

↓

Shadow Production

↓

Production
```

Every environment uses identical architecture whenever possible.

---

# Health Checks

Each service exposes

```text
/liveness

/readiness

/health
```

Health checks should validate:

- database
- Redis
- exchange connectivity
- internal dependencies

---

# Resource Requirements

| Component | CPU | Memory | Notes |
|------------|-----|--------|-------|
| Trading Runtime | Medium | Medium | Low latency |
| Dashboard | Low | Low | Stateless |
| Replay Engine | Medium | High | Batch processing |
| Agent Runtime | High | High | AI inference |
| PostgreSQL | High | High | Persistent |
| Redis | Medium | Medium | Cache & Pub/Sub |
| Ollama | Very High | Very High | GPU preferred |

---

# Deployment Responsibility Matrix

| Component | Deployment Type |
|------------|----------------|
| Trading Runtime | Singleton / Leader |
| OMS | Singleton |
| Position Manager | Singleton |
| Exit Engine | Singleton |
| Decision Engine | Stateless |
| Workflow Engine | Stateless |
| Agent Runtime | Horizontal |
| Dashboard | Horizontal |
| Replay Engine | Horizontal |
| Memory Service | Horizontal |

---

# Future Evolution

Future infrastructure additions

- Kubernetes
- Service Mesh
- Multi-region deployment
- Distributed Event Store
- GPU inference cluster
- Auto-scaling
- Dedicated replay cluster
- Dedicated research cluster

These additions should not require business logic changes.

---

# Production Readiness Checklist

Before production deployment

- HA database configured
- Redis persistence enabled
- Backup strategy verified
- Monitoring enabled
- Replay validated
- Feature flags configured
- Secrets externalized
- Health checks operational
- Disaster recovery tested

---

# Summary

The deployment architecture separates **logical business design** from **physical infrastructure**.

The platform evolves through four infrastructure stages:

1. Development
2. Home Lab
3. Production Cluster
4. Distributed Platform

This approach enables Karsa to grow from a single-machine deployment into a scalable, event-driven trading platform without requiring architectural rewrites.

The key principles remain constant:

- Stateless business services
- Centralized persistent state
- Event-driven communication
- Incremental scalability
- Production safety
- Infrastructure independence

By keeping deployment concerns separate from business logic, Karsa can scale operational capacity while preserving deterministic execution and architectural consistency.