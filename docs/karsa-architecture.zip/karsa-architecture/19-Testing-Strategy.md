# Testing Strategy

**Document ID:** KARSA-ARCH-019  
**Title:** Testing Strategy & Validation Framework  
**Version:** 1.0 (Draft)  
**Status:** Architecture Contract  
**Author:** Karsa Architecture Team  
**Last Updated:** July 2026

---

# Purpose

This document defines the **end-to-end testing strategy** for Karsa.

The objective is not simply to achieve high test coverage, but to ensure that every architectural change is validated against:

- correctness
- determinism
- production safety
- financial accuracy
- replayability
- operational reliability

For an algorithmic trading platform, **correctness is more important than code coverage**.

---

# Testing Philosophy

Karsa follows the principle:

> **Test behavior, not implementation.**

Every architectural component should prove that it behaves correctly under both normal and abnormal conditions.

---

# Testing Pyramid

```text
                    Manual Validation
                          ▲
                    Paper Trading
                          ▲
                   Shadow Testing
                          ▲
                 Replay Regression
                          ▲
              Integration Testing
                          ▲
                 Component Testing
                          ▲
                    Unit Testing
```

Unlike traditional applications, trading systems rely heavily on **Replay**, **Paper Trading**, and **Shadow Mode** before production.

---

# Testing Layers

## Layer 1 — Unit Tests

Purpose

Validate isolated business logic.

Examples

- ATR calculation
- Position sizing
- Risk formulas
- Exit rules
- Policy evaluation
- Confidence scoring

No external dependencies.

---

### Example

```python
assert ATR(20) == expected_value
```

---

# Layer 2 — Component Tests

Purpose

Validate a single component with mocked dependencies.

Examples

- Decision Engine
- Exit Engine
- Position Manager
- Workflow Engine

Dependencies are mocked.

Business rules remain real.

---

# Layer 3 — Integration Tests

Purpose

Validate interaction between components.

Examples

```text
Decision Engine

↓

Policy Engine

↓

Risk Engine

↓

Execution
```

Focus:

- API contracts
- Event publishing
- State transitions

---

# Layer 4 — Replay Regression

Purpose

Replay historical production events.

Expected outcome

```
Old System

==

New System
```

Every architectural migration must pass replay validation.

Replay is the most important regression mechanism.

---

# Layer 5 — Shadow Mode

Purpose

Run new architecture in production **without executing trades**.

Example

```text
Production Analyzer

↓

Old Decision

↓

Real Trade
```

Simultaneously

```text
Same Signal

↓

New Decision Engine

↓

Compare

↓

Discard Result
```

No production impact.

---

# Layer 6 — Paper Trading

Purpose

Execute against live market data using simulated capital.

Objectives

- Validate behavior
- Measure profitability
- Observe stability

No real orders are placed.

---

# Layer 7 — Production Validation

Purpose

Gradually enable new functionality.

Example rollout

```
10%

↓

25%

↓

50%

↓

100%
```

Feature flags control deployment.

---

# Test Categories

```text
Testing

├── Unit

├── Component

├── Integration

├── Replay

├── Paper Trading

├── Shadow Mode

├── Chaos

├── Performance

├── Recovery

├── Security

└── Production
```

---

# Unit Testing

Target

Business logic.

Examples

- Indicator calculation
- Policy evaluation
- State transitions
- Validation logic
- Portfolio allocation

Coverage target

> 90%+

---

# Component Testing

Examples

Position Manager

Tests

- open position
- reduce position
- close position
- reconciliation

Exit Engine

Tests

- break even
- trailing
- partial exit
- stop loss

---

# Integration Testing

Examples

```
Analyzer

↓

Decision

↓

Risk

↓

Execution
```

Verify

- APIs
- events
- ownership
- persistence

---

# Contract Testing

Every internal API must satisfy:

- schema validation
- backward compatibility
- version compatibility

Example

```text
Decision API

v1

↓

v2

↓

Both Supported
```

---

# Event Testing

Every event should validate:

- publisher
- subscribers
- payload
- ordering
- idempotency

Example

```
PositionOpened

↓

Exactly Once
```

---

# State Machine Testing

Every state machine requires:

- valid transitions
- invalid transitions
- recovery transitions
- replay validation

Example

```
OPEN

↓

BREAK_EVEN

↓

TRAILING

↓

CLOSED
```

---

# Workflow Testing

Validate

- checkpoint
- timeout
- retry
- cancellation
- recovery

---

# Replay Testing

Replay validates:

- historical trades
- decisions
- exits
- workflows
- policies

Success

```
Replay Output

=

Historical Output
```

---

# Regression Testing

Every release executes:

- historical replay
- integration suite
- paper trading

Regression failures block deployment.

---

# Paper Trading

Purpose

Validate:

- latency
- behavior
- market interaction

Environment

Live market

Simulated orders

---

# Shadow Testing

Current

```
Production

↓

Old Exit Engine
```

Shadow

```
Same Position

↓

New Exit Engine

↓

Compare

↓

Ignore Result
```

Once outputs match,

the new implementation may be promoted.

---

# Chaos Testing

Inject failures.

Examples

- Exchange timeout
- Redis unavailable
- Database restart
- AI timeout
- Event duplication

Verify

Safe recovery.

---

# Recovery Testing

Examples

Crash after

```
OrderFilled
```

Restart.

Verify

```
Position Restored
```

---

# Performance Testing

Measure

- latency
- throughput
- CPU
- memory
- event processing
- replay speed

Targets should be defined for every component.

---

# Load Testing

Examples

```
100 symbols

↓

500 symbols

↓

1000 symbols
```

Measure

- event queue
- memory
- CPU

---

# Soak Testing

Run continuously.

Example

```
72 Hours

Continuous Market Data
```

Verify

No memory leaks.

---

# Security Testing

Validate

- authentication
- authorization
- API keys
- secrets
- policy enforcement

---

# AI Testing

Validate

- schema
- hallucination detection
- timeout
- retries
- prompt version

AI never bypasses deterministic validation.

---

# Replay Validation

Every migration phase requires:

```
Historical Events

↓

Replay

↓

Compare

↓

Identical?
```

Differences require investigation.

---

# Exit Strategy Testing

Every exit strategy requires scenarios for:

- profit
- loss
- gap down
- flash crash
- partial fill
- trailing

No exit rule should be deployed without scenario coverage.

---

# Position Manager Testing

Validate

- duplicate updates
- concurrent updates
- reconciliation
- restart recovery
- event publishing

---

# Decision Engine Testing

Scenarios

```
BUY

SELL

IGNORE

CONFLICT

NO SIGNAL
```

Confidence calculations must be deterministic.

---

# Policy Testing

Test

- policy pass
- policy reject
- priority
- versioning
- rollback

---

# Workflow Testing

Validate

- resume
- retry
- timeout
- compensation
- persistence

---

# Agent Runtime Testing

Test

- scheduling
- retries
- health
- timeout
- lifecycle

Agents should never affect deterministic execution.

---

# Acceptance Criteria

Every feature must satisfy:

✅ Unit Tests

↓

✅ Component Tests

↓

✅ Integration Tests

↓

✅ Replay Tests

↓

✅ Paper Trading

↓

✅ Shadow Mode

↓

✅ Production

No exceptions for production trading logic.

---

# CI/CD Pipeline

```text
Commit

↓

Static Analysis

↓

Unit Tests

↓

Component Tests

↓

Integration Tests

↓

Replay Regression

↓

Paper Trading Validation

↓

Shadow Deployment

↓

Production Approval
```

---

# Coverage Goals

| Category | Target |
|-----------|---------|
| Unit | ≥ 90% |
| Component | ≥ 85% |
| Integration | Critical Paths 100% |
| Replay | 100% Historical Trades |
| Event Contracts | 100% |
| State Machines | 100% Valid Transitions |
| API Contracts | 100% Public Interfaces |

Coverage is measured by business behavior, not just lines of code.

---

# Production Readiness Checklist

Before enabling any new feature:

- Unit tests pass
- Integration tests pass
- Replay identical
- Shadow mode validated
- Paper trading successful
- Performance acceptable
- Recovery tested
- Rollback verified
- Monitoring configured
- Feature flag available

Failure of any item blocks deployment.

---

# Quality Gates

| Gate | Requirement |
|--------|-------------|
| G1 | Build Success |
| G2 | Static Analysis |
| G3 | Unit Tests |
| G4 | Integration Tests |
| G5 | Replay Validation |
| G6 | Paper Trading |
| G7 | Shadow Validation |
| G8 | Production Approval |

A release progresses only after passing every gate.

---

# Testing Ownership

| Component | Primary Owner |
|-----------|---------------|
| Unit Tests | Developer |
| Integration Tests | QA Automation |
| Replay Validation | Platform Team |
| Paper Trading | Trading Team |
| Shadow Mode | Platform Team |
| Chaos Testing | DevOps |
| Production Validation | Engineering Lead |

---

# Architectural Validation Matrix

| Architecture Component | Validation Method |
|------------------------|-------------------|
| Event Bus | Event Contract Tests |
| Position Manager | State Machine + Replay |
| Exit Engine | Historical Trade Replay |
| Decision Engine | Recommendation Comparison |
| Policy Engine | Rule Evaluation Tests |
| Workflow Engine | Recovery & Checkpoint Tests |
| Agent Runtime | Lifecycle & Timeout Tests |
| Memory | Retrieval Accuracy Tests |
| Replay Engine | Historical Reconstruction |

---

# Success Metrics

The testing strategy is successful when:

- No duplicate trades occur.
- Historical trades replay identically.
- Every failure scenario has automated validation.
- Architectural migrations introduce zero production regressions.
- Rollback can be executed safely.
- Deterministic behavior is preserved across releases.

---

# Summary

Testing in Karsa is designed around **confidence**, not just coverage.

The platform validates changes through multiple layers:

- deterministic unit testing
- component isolation
- integration verification
- historical replay
- paper trading
- shadow deployment
- gradual production rollout

This strategy ensures that architectural evolution can continue without compromising capital protection, operational stability, or deterministic execution—the three core requirements of a production-grade algorithmic trading platform.