# Event Catalog

**Document ID:** KARSA-ARCH-014  
**Title:** Business Event Catalog  
**Version:** 1.0 (Draft)  
**Status:** Architecture Contract  
**Author:** Karsa Architecture Team  
**Last Updated:** July 2026

---

# Purpose

This document defines the **official Business Event Catalog** for Karsa.

It serves as the **contract** between independent components.

Unlike API contracts, events represent **facts that already happened**.

Example

Good

```
PositionOpened
```

Bad

```
OpenPosition
```

Commands request work.

Events announce completed work.

---

# Objectives

This catalog provides:

- Standard event names
- Event ownership
- Event payloads
- Publishers
- Subscribers
- Ordering rules
- Versioning
- Event lifecycle

Every business event published inside Karsa must be registered here.

---

# Event Design Principles

## Events Describe Facts

Events always use the past tense.

Examples

```
OrderSubmitted

OrderFilled

PositionOpened

TradeCompleted
```

---

## One Publisher

Every event has exactly one publisher.

Never multiple publishers.

---

## Multiple Subscribers

Events may have many subscribers.

Publishers never know subscribers.

---

## Immutable

Events are append-only.

Never edited.

Never overwritten.

---

## Versioned

Every event contains:

```
eventVersion
```

Breaking changes create a new version.

---

# Standard Event Envelope

Every event shares the same metadata.

```json
{
  "eventId": "UUID",
  "eventType": "PositionOpened",
  "eventVersion": 1,
  "aggregateId": "BTCUSDT",
  "aggregateType": "Position",
  "timestamp": "2026-07-05T12:00:00Z",
  "publisher": "PositionManager",
  "correlationId": "workflow-id",
  "causationId": "previous-event-id",
  "payload": {}
}
```

---

# Event Categories

```text
Business Events

├── Market

├── Signal

├── Decision

├── Policy

├── Risk

├── Order

├── Position

├── Exit

├── Portfolio

├── Workflow

├── Agent

├── Journal

├── Replay

├── System

└── Emergency
```

---

# Market Events

---

## MarketScanned

Publisher

Analyzer

Purpose

Market scan completed.

Subscribers

- Research
- Metrics
- Journal

Payload

```json
{
  "symbols": [],
  "scanDuration": 0,
  "timestamp": ""
}
```

---

## MarketRegimeChanged

Publisher

Analyzer

Subscribers

- Decision Engine
- Strategy
- Metrics

Payload

```json
{
  "symbol": "BTCUSDT",
  "oldRegime": "Ranging",
  "newRegime": "Trending"
}
```

---

## VolatilityUpdated

Publisher

Analyzer

Subscribers

- Exit Engine
- Risk

Payload

```json
{
  "atr": 0,
  "volatility": 0
}
```

---

# Signal Events

---

## SignalDetected

Publisher

Analyzer

Subscribers

- Decision Engine

Payload

```json
{
  "symbol": "BTCUSDT",
  "direction": "LONG",
  "confidence": 0.82
}
```

---

## SignalRejected

Publisher

Analyzer

Subscribers

- Metrics
- Journal

---

# Decision Events

---

## DecisionApproved

Publisher

Decision Engine

Subscribers

- Risk

Payload

```json
{
  "decisionId": "",
  "symbol": "",
  "confidence": 0.81
}
```

---

## DecisionRejected

Publisher

Decision Engine

Subscribers

- Journal
- Dashboard

---

## DecisionExplained

Publisher

Decision Engine

Subscribers

- Journal
- Telegram

---

# Policy Events

---

## PolicyPassed

Publisher

Policy Engine

Subscribers

- Metrics

---

## PolicyRejected

Publisher

Policy Engine

Subscribers

- Journal
- Telegram

---

## PolicyChanged

Publisher

Policy Engine

Subscribers

- Decision Engine
- Workflow Engine

---

# Risk Events

---

## RiskApproved

Publisher

Risk Engine

Subscribers

- Execution

---

## RiskRejected

Publisher

Risk Engine

Subscribers

- Journal
- Telegram

---

## ExposureExceeded

Publisher

Risk Engine

Subscribers

- Policy Engine

---

## LeverageAdjusted

Publisher

Risk Engine

Subscribers

- Position Manager

---

# Order Events

---

## OrderCreated

Publisher

OMS

Subscribers

- Metrics

---

## OrderSubmitted

Publisher

OMS

Subscribers

- Dashboard
- Replay

---

## OrderPartiallyFilled

Publisher

OMS

Subscribers

- Position Manager

---

## OrderFilled

Publisher

OMS

Subscribers

- Position Manager
- Workflow Engine

---

## OrderCancelled

Publisher

OMS

Subscribers

- Workflow Engine

---

## OrderRejected

Publisher

OMS

Subscribers

- Journal
- Telegram

---

# Position Events

---

## PositionOpened

Publisher

Position Manager

Subscribers

- Exit Engine
- Journal
- Metrics
- Dashboard
- Replay

Payload

```json
{
  "positionId": "",
  "symbol": "",
  "entryPrice": 0,
  "quantity": 0
}
```

---

## PositionUpdated

Publisher

Position Manager

Subscribers

- Dashboard

---

## PositionReduced

Publisher

Position Manager

Subscribers

- Journal

---

## BreakEvenActivated

Publisher

Position Manager

Subscribers

- Telegram

---

## TrailingActivated

Publisher

Position Manager

Subscribers

- Telegram

---

## PositionClosed

Publisher

Position Manager

Subscribers

- Journal
- Replay
- Metrics
- Memory
- Portfolio

---

## PositionReconciled

Publisher

Position Manager

Subscribers

- Monitoring

---

# Exit Events

---

## StopLossTriggered

Publisher

Exit Engine

Subscribers

- Journal
- Replay

---

## TrailingTriggered

Publisher

Exit Engine

Subscribers

- Replay

---

## PartialExitExecuted

Publisher

Exit Engine

Subscribers

- Position Manager

---

## TimeExitTriggered

Publisher

Exit Engine

Subscribers

- Position Manager

---

## EmergencyExitTriggered

Publisher

Exit Engine

Subscribers

- Dashboard
- Telegram

---

## TradeCompleted

Publisher

Exit Engine

Subscribers

- Memory
- Journal
- Replay
- Metrics

---

# Portfolio Events

---

## PortfolioUpdated

Publisher

Portfolio Service

Subscribers

- Dashboard

---

## AllocationChanged

Publisher

Portfolio Service

Subscribers

- Decision Engine

---

## CashBalanceUpdated

Publisher

Portfolio Service

Subscribers

- Metrics

---

# Workflow Events

---

## WorkflowStarted

Publisher

Workflow Engine

Subscribers

- Metrics

---

## WorkflowWaiting

Publisher

Workflow Engine

Subscribers

- Dashboard

---

## WorkflowResumed

Publisher

Workflow Engine

Subscribers

- Metrics

---

## WorkflowCompleted

Publisher

Workflow Engine

Subscribers

- Journal

---

## WorkflowFailed

Publisher

Workflow Engine

Subscribers

- Monitoring

---

# Agent Events

---

## AgentStarted

Publisher

Agent Runtime

Subscribers

- Metrics

---

## AgentCompleted

Publisher

Agent Runtime

Subscribers

- Metrics

---

## AgentFailed

Publisher

Agent Runtime

Subscribers

- Monitoring

---

## ResearchCompleted

Publisher

Research Agent

Subscribers

- Memory
- Journal

---

## RecommendationGenerated

Publisher

Advisor Agent

Subscribers

- Decision Engine

---

# Journal Events

---

## JournalGenerated

Publisher

Journal Agent

Subscribers

- Memory

---

## PostMortemGenerated

Publisher

Journal Agent

Subscribers

- Dashboard

---

# Replay Events

---

## ReplayStarted

Publisher

Replay Engine

Subscribers

- Metrics

---

## ReplayCompleted

Publisher

Replay Engine

Subscribers

- Dashboard

---

## ReplayFailed

Publisher

Replay Engine

Subscribers

- Monitoring

---

# System Events

---

## ApplicationStarted

Publisher

Runtime

Subscribers

- Monitoring

---

## ApplicationStopped

Publisher

Runtime

Subscribers

- Monitoring

---

## ConfigurationReloaded

Publisher

Runtime

Subscribers

- All Components

---

## HealthCheckFailed

Publisher

Monitoring

Subscribers

- Alerting

---

# Emergency Events

---

## KillSwitchActivated

Publisher

Policy Engine

Subscribers

- Execution
- Workflow
- Dashboard

---

## TradingSuspended

Publisher

Policy Engine

Subscribers

- Analyzer
- Decision Engine

---

## TradingResumed

Publisher

Policy Engine

Subscribers

- All Components

---

# Event Dependency Matrix

| Publisher | Primary Subscribers |
|------------|---------------------|
| Analyzer | Decision Engine |
| Decision Engine | Risk Engine |
| Policy Engine | Risk Engine |
| Risk Engine | Execution |
| OMS | Position Manager |
| Position Manager | Exit Engine, Replay, Memory |
| Exit Engine | Position Manager |
| Workflow Engine | Metrics, Dashboard |
| Agent Runtime | Metrics |
| Replay Engine | Dashboard |

---

# Event Ordering Rules

For each aggregate, event ordering must be preserved.

Example

```text
OrderCreated

↓

OrderSubmitted

↓

OrderFilled

↓

PositionOpened

↓

BreakEvenActivated

↓

TrailingActivated

↓

PositionClosed

↓

TradeCompleted
```

Out-of-order processing is not permitted for a single aggregate.

---

# Event Naming Convention

Format

```
<Noun><PastTenseVerb>
```

Examples

```
PositionOpened

OrderFilled

TradeCompleted

PolicyRejected
```

Avoid

```
OpenPosition

ExecuteTrade

RunAnalysis
```

Those are commands.

---

# Correlation IDs

Every workflow shares the same correlation ID.

Example

```text
Trade Workflow

↓

SignalDetected

↓

DecisionApproved

↓

RiskApproved

↓

OrderSubmitted

↓

PositionOpened

↓

TradeCompleted
```

The correlation ID allows complete timeline reconstruction.

---

# Event Versioning

Rules

- Additive changes do not require a new version.
- Breaking payload changes increment `eventVersion`.
- Publishers and subscribers must support backward compatibility during migration.

---

# Event Retention

| Category | Retention |
|----------|-----------|
| Orders | Permanent |
| Positions | Permanent |
| Trades | Permanent |
| Policies | Permanent |
| Workflow | 1 Year |
| Agent | 90 Days |
| Market | Configurable |
| System | 30 Days |

---

# Future Events

Future versions of Karsa may introduce:

- StrategyOptimized
- ModelRetrained
- PortfolioRebalanced
- CorrelationChanged
- FundingUpdated
- WhaleDetected
- MacroEventDetected
- EarningsReleased
- LiquidityChanged
- MarketStructureChanged

These should be added to this catalog before implementation.

---

# Governance

Every new business event must answer the following questions before implementation:

- What business fact does this event represent?
- Who is the single publisher?
- Who are the subscribers?
- Is this event immutable?
- Can it be replayed?
- Is it idempotent?
- Does it belong in an existing category?
- Does it require a new version?

No event should be introduced directly into the codebase without first being registered in this catalog.

---

# Summary

The Event Catalog is the **official contract** for all business events within Karsa.

It ensures:

- Consistent event naming
- Clear ownership
- Stable contracts
- Replay compatibility
- Event-driven integration
- Loose coupling
- Auditable workflows
- Safe architectural evolution

As Karsa grows, this catalog becomes the authoritative reference for every component that publishes or consumes business events.