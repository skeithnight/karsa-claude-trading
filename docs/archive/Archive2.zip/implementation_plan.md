# Crypto Analyst: Profit-Probability Scoring + Performance Optimization

## Goal

Two objectives:
1. **Profit-chance focus**: Pre-score each coin *before* LLM call using deterministic TA. Only high-probability setups reach the LLM. LLM gets richer context (historical win-rate hint, expected move %, risk/reward estimate) so it can output a calibrated `probability_of_profit` score alongside the signal.
2. **Resource reduction**: Cut LLM token spend and API calls by ~60% via aggressive pre-filtering, TA result caching, and a deterministic fast-path that skips the LLM entirely on poor setups.

---

## Proposed Changes

### Component 1 — Deterministic Pre-Filter (`src/advisory/crypto_technicals.py`)

#### [MODIFY] [crypto_technicals.py](file:///Users/dwiki.nugraha/dwikicode/karsa-claude-trading/src/advisory/crypto_technicals.py)

Add `quick_score(ohlcv, quote)` → pure-Python function that:
- Runs RSI, BB, EMA-20/50 crossover, MACD histogram, ATR on 1H candles
- Returns a numeric **setup score (0–100)** + dict of signals
- **No OHLCV re-fetch** (caller passes already-fetched data)
- Used as pre-filter gate before LLM call

Key formula:
```
setup_score =
  + rsi_score         (0–25)   # 25 = deeply oversold/overbought aligned with trend
  + ema_cross_score   (0–25)   # 25 = fresh 20/50 EMA crossover
  + macd_score        (0–20)   # 20 = histogram flipped positive
  + bb_score          (0–15)   # 15 = price at/beyond band edge
  + funding_score     (0–15)   # 15 = contrarian funding extreme
```

---

### Component 2 — Pre-filter gate in Orchestrator (`src/agents/orchestrator.py`)

#### [MODIFY] [orchestrator.py](file:///Users/dwiki.nugraha/dwikicode/karsa-claude-trading/src/agents/orchestrator.py)

In `_scan_crypto_parallel()`, **before** building LLM batch tasks:

1. Fetch 1H OHLCV + quote for all coins **in parallel** (already cached by Bybit client)
2. Run `quick_score()` on each
3. **Gate**: only coins with `setup_score >= 35` go to LLM scan (configurable via `CRYPTO_MIN_SETUP_SCORE` setting)
4. Coins with `setup_score < 35` → skip entirely (log `pre_filter_skip`)
5. Pass `setup_score` + signals dict into the LLM prompt as structured context

Expected reduction: 50–70% fewer LLM calls on low-signal markets.

---

### Component 3 — Profit-probability context in CryptoAnalyst prompt (`src/agents/crypto_analyst.py`)

#### [MODIFY] [crypto_analyst.py](file:///Users/dwiki.nugraha/dwikicode/karsa-claude-trading/src/agents/crypto_analyst.py)

1. **Prompt enrichment**: inject pre-computed context into task string:
   ```
   PRE-SCORED SETUP (deterministic):
   - Setup Score: 72/100
   - RSI: 28.5 (oversold), EMA cross: bullish (20>50 just crossed), MACD: bullish_cross
   - Bollinger: below_lower band, ATR: 2.3% (moderate volatility)
   - Funding: -0.045% (shorts crowded → contrarian long edge)
   - Expected move (1x ATR): ±2.3% | Risk/Reward at 3:1 SL → target ≈ +6.9%
   ```
2. **New output field**: add `probability_of_profit` (0–100) to the JSON schema, defined as LLM's estimate of P(this trade hits target before stop). Instruct LLM to reason from: setup quality, regime, funding sentiment, historical analog.
3. **Combine scores**: final `confidence_score` = weighted blend:
   ```
   confidence_score = 0.6 * llm_confidence + 0.4 * setup_score
   ```
   This anchors LLM confidence to deterministic signals, preventing hallucinated overconfidence.

---

### Component 4 — OHLCV cache for pre-filter (`src/data/cache.py` or inline)

#### [MODIFY] [cache.py](file:///Users/dwiki.nugraha/dwikicode/karsa-claude-trading/src/data/cache.py)  *(or inline in orchestrator)*

- After fetching OHLCV for pre-filter, store result in a short-lived dict `{ticker: ohlcv}` scoped to the scan cycle
- Pass into `_handle_tool_call` so `get_crypto_full_analysis` reuses the already-fetched 1H data instead of re-fetching
- **Saves**: N × 2 OHLCV API calls (1H + 4H) per coin per scan cycle

---

### Component 5 — Batch prompt shrinkage

#### [MODIFY] [orchestrator.py](file:///Users/dwiki.nugraha/dwikicode/karsa-claude-trading/src/agents/orchestrator.py)

Current `BATCH_SIZE = 5`. After pre-filtering, batches are already smaller. Additionally:
- **Reduce prompt verbosity**: only inject pre-scored context (not position_context) for low-score coins that still passed gate
- **Trim tool calls**: in `PURE_DEAD_CHOP` / `DEAD_CHOP` regimes, call `quick_score` only, skip LLM entirely → return `confidence=0` immediately

---

## Impact Summary

| Change | Token reduction | API call reduction |
|--------|----------------|---------------------|
| Pre-filter gate (setup_score < 35 skip) | ~55% | ~60% |
| OHLCV scan-cycle cache | 0 tokens | ~40% fewer Bybit calls |
| Deterministic fast-path on DEAD_CHOP | ~5% | ~10% |
| **Total estimated** | **~60%** | **~50%** |

---

## Open Questions

> [!IMPORTANT]
> **Q1**: What threshold for `setup_score` gate? Default 35 (out of 100). Lower → more signals, more LLM cost. Higher → fewer but higher-quality. OK with 35?

> [!IMPORTANT]
> **Q2**: `probability_of_profit` field — should this appear in Telegram notifications? Or internal use only (for filtering/ranking)?

> [!NOTE]
> **Q3**: Confidence blend `0.6 * llm + 0.4 * setup` — want to tune weights, or leave to post-launch tuning?

---

## Verification Plan

### Automated
- Unit test `quick_score()` on synthetic OHLCV with known setups
- Assert pre-filter correctly gates at threshold

### Manual
- Trigger one scan cycle, verify logs show `pre_filter_skip` for low-setup coins
- Confirm signals still include `probability_of_profit` field
- Compare signal count before/after (expect reduction, not elimination)
