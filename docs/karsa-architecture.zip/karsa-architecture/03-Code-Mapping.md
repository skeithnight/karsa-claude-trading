# Code Mapping

**Document ID:** KARSA-ARCH-003  
**Title:** Current Code Mapping & Refactoring Blueprint  
**Version:** 1.0 (Draft)  
**Status:** Architecture Audit  
**Author:** Karsa Architecture Team  
**Last Updated:** July 2026

---

# Purpose

This document bridges the gap between **architecture** and **implementation**.

Unlike the previous documents, this document answers:

> **Which source code implements each architectural responsibility?**

This mapping becomes the foundation for future refactoring.

Every migration phase should update this document.

---

# Objectives

This document serves five purposes:

- Map architectural domains to source code.
- Identify duplicated responsibilities.
- Identify missing ownership.
- Define migration targets.
- Prevent unnecessary rewrites.

---

# Repository Overview

Current repository structure (simplified)

```text
src/
│
├── agents/
├── advisory/
├── execution/
├── risk/
├── portfolio/
├── metrics/
├── models/
├── monitoring/
├── exchange/
├── bot/
├── backtest/
├── storage/
└── utils/
```

Observation:

The repository is already organized by **business domains**, not technical layers.

This is a strong architectural foundation.

---

# Domain Mapping

| Domain | Current Package | Status |
|----------|----------------|---------|
| Analyzer | `src/agents/` | ✅ Mature |
| Advisory | `src/advisory/` | ✅ Mature |
| Risk | `src/risk/` | ⚠ Large Responsibility |
| Portfolio | `src/portfolio/` | ✅ Good |
| Execution | `src/execution/` | ✅ Mature |
| Exchange | `src/exchange/` | ✅ Mature |
| Telegram | `src/bot/` | ✅ Good |
| Metrics | `src/metrics/` | ✅ Good |
| Storage | `src/storage/` | ✅ Good |

---

# Current Component Ownership

## Analyzer

Current

```text
src/agents/
```

Responsibilities

- Market analysis
- Signal generation
- Strategy analysis

Future

Remain unchanged.

Only wrapped by Agent Runtime.

Migration

None.

---

## Advisory

Current

```text
src/advisory/
```

Responsibilities

- Recommendations
- AI explanations
- User-facing advice

Future

Advisor Agent

Migration

Minimal.

---

## Execution

Current

```text
src/execution/
```

Responsibilities

- Order creation
- OMS
- Exchange execution
- Fill tracking

Future

Remain deterministic.

No AI.

Migration

Low.

---

## OMS

Current

```text
src/execution/oms.py
```

Responsibilities

- Order lifecycle
- Fill tracking
- Exchange status

Future

Remain almost unchanged.

Only publish business events.

Migration

Phase 1

---

## Stop Loss Engine

Current

```text
src/execution/sl_engine.py
```

Responsibilities

- Execute stop losses

Current limitation

Owns only one exit mechanism.

Future

Merged into Exit Engine.

Migration

Phase 4

---

# Risk Package Analysis

Current package

```text
src/risk/
```

Current responsibilities

- Position Manager
- Position Sync
- Trailing Stop
- Profit Lock
- Portfolio Allocation
- Funding
- Exposure
- Smart Order Routing

Observation

The package has become a collection of multiple domains.

Recommendation

Split into dedicated subdomains.

---

# Current Risk Mapping

| Current Component | Responsibility | Future |
|-------------------|---------------|---------|
| position_manager.py | Position | Position Manager |
| position_sync.py | Exchange Sync | Position Manager |
| trailing_stop.py | Exit | Exit Engine |
| profit_lock.py | Exit | Exit Engine |
| portfolio_allocator.py | Portfolio | Portfolio Service |
| funding_tracker.py | Funding | Funding Service |
| exposure.py | Exposure | Risk Calculator |
| sor.py | Order Routing | Execution |

---

# Position Ownership

Current

```text
Execution

↓

Position Manager

↓

Position Sync

↓

Trailing Stop

↓

Profit Lock

↓

SL Engine
```

Observation

Multiple writers.

Future

```text
Execution

↓

Position Manager

↓

Position Repository
```

Everyone else becomes a consumer.

---

# Exit Logic Mapping

Current

```text
Trailing Stop

Profit Lock

Stop Loss

Manual Close

Time Exit
```

Future

```text
Exit Engine

├── Initial Stop Loss

├── Break Even

├── Partial Exit

├── Trailing Stop

├── Time Exit

└── Emergency Exit
```

Migration

Phase 4

---

# Telegram

Current

```text
src/bot/
```

Responsibilities

- Commands
- Notifications
- Manual actions

Future

Become Event Subscriber.

Migration

Phase 2

---

# Metrics

Current

```text
src/metrics/
```

Responsibilities

- Runtime metrics
- Trading metrics

Future

Subscribe to business events.

Migration

Phase 2

---

# Monitoring

Current

```text
src/monitoring/
```

Responsibilities

- Health
- Runtime monitoring

Future

No structural changes.

---

# Exchange

Current

```text
src/exchange/
```

Responsibilities

- Binance API
- WebSocket
- REST

Future

Remain isolated.

Never depend on AI.

Migration

None.

---

# Storage

Current

```text
src/storage/
```

Responsibilities

- Database
- Persistence

Future

Support Event Store.

Replay Engine.

Migration

Phase 8

---

# AI Components

Current

```text
Analyzer

Advisory
```

Future

```text
Analyzer Agent

Advisor Agent

Research Agent

Journal Agent
```

Only these components become AI agents.

---

# Components That Must Remain Deterministic

The following modules **must never depend on an LLM**.

| Component | Reason |
|------------|---------|
| OMS | Production critical |
| Exchange Client | Latency |
| Position Manager | State consistency |
| Exit Engine | Risk management |
| Risk Calculator | Deterministic calculations |
| Portfolio Allocator | Financial correctness |
| Funding Calculator | Mathematical |
| Execution | Order integrity |

---

# New Components

The following components do not currently exist.

| Component | Phase |
|------------|-------|
| Event Bus | 1 |
| Position Manager (new ownership model) | 2 |
| Exit Engine | 4 |
| Decision Engine | 5 |
| Replay Engine | 6 |
| Policy Engine | 7 |
| Agent Runtime | 8 |
| Workflow Engine | 9 |
| Memory | 10 |

---

# Migration Matrix

| Current | Future | Phase | Rewrite Required |
|----------|---------|------|-----------------|
| Analyzer | Analyzer Agent | 8 | No |
| Advisory | Advisor Agent | 8 | No |
| OMS | OMS + Events | 1 | No |
| SL Engine | Exit Engine | 4 | Partial |
| Position Manager | Position Manager | 2 | Refactor |
| Position Sync | Position Manager | 2 | Merge |
| Trailing Stop | Exit Engine | 4 | Merge |
| Profit Lock | Exit Engine | 4 | Merge |
| Telegram | Event Subscriber | 2 | Small |
| Metrics | Event Subscriber | 2 | Small |
| Monitoring | Monitoring | None | No |
| Exchange | Exchange | None | No |

---

# Components That Should Not Be Rewritten

The following components are considered architecturally stable.

- OMS
- Exchange Client
- Execution Layer
- Portfolio Allocator
- Monitoring
- Metrics
- Database Layer

Recommendation

Extend them.

Do not replace them.

---

# Components That Require Refactoring

Priority order

1. Position Ownership
2. Exit Logic
3. Event Communication
4. Runtime Lifecycle

Everything else can remain largely unchanged.

---

# Technical Debt Inventory

| Area | Severity | Recommendation |
|------|----------|----------------|
| Position Ownership | Critical | Single owner |
| Exit Logic | High | Consolidate |
| Service Coupling | High | Event Bus |
| Runtime Lifecycle | Medium | Agent Runtime |
| Workflow | Medium | Workflow Engine |
| Replay | Medium | Event Store |

---

# Code Migration Principles

Every migration must satisfy:

- Preserve production behavior.
- Maintain backward compatibility.
- Introduce feature flags where appropriate.
- Support rollback.
- Avoid large-scale rewrites.

---

# Definition of Done

A component migration is complete when:

- Old responsibility has been removed.
- New ownership is established.
- Business behavior remains unchanged.
- Automated tests pass.
- Replay tests succeed.
- Production metrics remain unchanged.

---

# Summary

This document establishes the **mapping between architecture and implementation**.

It identifies:

- which modules already align with the target architecture,
- which modules require refactoring,
- which responsibilities should be merged,
- and which components should remain untouched.

The most important conclusion is that **Karsa already contains most of the required business logic**.

The migration effort should therefore focus on **reorganizing ownership and communication**, not rewriting existing functionality.

This document serves as the primary reference for all migration phases and should be updated whenever responsibilities move between components.