# Policy Engine

**Document ID:** KARSA-ARCH-013  
**Title:** Policy Engine Architecture  
**Version:** 1.0 (Draft)  
**Status:** Proposed Architecture  
**Author:** Karsa Architecture Team  
**Last Updated:** July 2026

---

# Purpose

The **Policy Engine** is responsible for enforcing **business rules, governance, and operational constraints** across the Karsa platform.

Unlike the Decision Engine, which determines whether a trade is desirable, or the Risk Engine, which validates financial safety, the Policy Engine answers a different question:

> **"Is this action allowed?"**

Policies represent organizational rules rather than trading strategies.

---

# Why a Policy Engine?

As Karsa evolves, business rules become scattered across multiple components.

Examples:

- Maximum daily trades
- Weekend trading restrictions
- Allowed exchanges
- Portfolio concentration
- Emergency shutdown
- AI approval requirements
- Maximum leverage

Without a centralized Policy Engine:

- Business rules become duplicated.
- Rule changes require code changes.
- Governance becomes inconsistent.
- Auditing becomes difficult.

---

# Architecture Position

```text
                 Trading Opportunity

                         │

                         ▼

                 Decision Engine

                         │

                         ▼

                  Policy Engine

                         │

              ┌──────────┴──────────┐

              ▼                     ▼

         Policy Passed        Policy Failed

              │                     │

              ▼                     ▼

         Risk Validation       Reject Trade

              │

              ▼

          Execution
```

The Policy Engine sits between **Decision** and **Risk**.

---

# Responsibilities

The Policy Engine owns:

- Business policies
- Trading governance
- Approval rules
- Compliance rules
- Feature restrictions
- Emergency controls
- Runtime policy evaluation
- Policy auditing

It does **not** own:

- Risk calculations
- Strategy logic
- Market analysis
- Order execution
- Position lifecycle

---

# Core Principles

## Policies Are Business Rules

Policies define **what is permitted**, not **what is profitable**.

Example:

Good policy

```
Maximum Daily Loss = 5%
```

Bad policy

```
Buy BTC above EMA200
```

Trading logic belongs elsewhere.

---

## Policies Are Declarative

Policies should describe constraints.

Instead of

```python
if pnl < -5:
    stop()
```

Policies become

```yaml
max_daily_loss: 5%
```

The engine interprets the rule.

---

## Policies Are Versioned

Every policy change creates a new version.

Historical trades remain associated with the policy version used during execution.

---

# Policy Categories

```text
Policy Engine

├── Trading Policies

├── Portfolio Policies

├── Risk Policies

├── Operational Policies

├── Compliance Policies

├── User Policies

├── AI Policies

└── Emergency Policies
```

---

# Trading Policies

Examples

```
Maximum trades/day

Allowed trading hours

Weekend trading

Holiday trading

Allowed symbols

Allowed exchanges
```

---

# Portfolio Policies

Examples

```
Maximum allocation

Maximum sector exposure

Maximum correlation

Minimum cash reserve

Maximum concurrent positions
```

---

# Risk Policies

Examples

```
Maximum leverage

Maximum drawdown

Maximum unrealized loss

Liquidation buffer

Maximum position size
```

Risk Engine performs calculations.

Policy Engine determines acceptable limits.

---

# Operational Policies

Examples

```
Maintenance mode

Read-only mode

Paper trading only

Shadow mode

Exchange whitelist
```

These affect system behavior.

---

# AI Policies

Examples

```
AI allowed?

Human approval required?

Maximum AI confidence

Allowed models

Offline-only mode
```

AI remains governed by policy.

---

# Emergency Policies

Examples

```
Kill Switch

Stop New Trades

Close All Positions

Disable AI

Freeze Portfolio

Exchange Blacklist
```

Highest priority.

---

# Policy Lifecycle

```text
Draft

↓

Review

↓

Approved

↓

Active

↓

Deprecated

↓

Archived
```

Policies are managed like production code.

---

# Policy Evaluation Pipeline

```text
Incoming Decision

↓

Load Active Policies

↓

Evaluate Rules

↓

Collect Violations

↓

Generate Result

↓

Allow / Reject
```

Every decision follows the same pipeline.

---

# Policy Evaluation Result

Example

```json
{
  "status": "REJECTED",
  "policy": "MaximumDailyLoss",
  "reason": "Daily loss exceeded",
  "version": "3.2"
}
```

Possible outcomes:

```
PASS

REJECT

WARN

REQUIRE_APPROVAL
```

---

# Policy Priority

Policies are evaluated by priority.

```text
Emergency

↓

Compliance

↓

Operational

↓

Risk

↓

Portfolio

↓

Trading

↓

User
```

Higher-priority policies override lower ones.

---

# Example Trade Evaluation

Incoming trade

```text
BUY BTC

↓

Policy Engine

↓

Weekend?

PASS

↓

Daily Loss?

PASS

↓

Maximum Trades?

PASS

↓

Exchange Allowed?

PASS

↓

APPROVED
```

---

Example rejection

```text
BUY BTC

↓

Policy Engine

↓

Maximum Daily Loss

Exceeded

↓

REJECT
```

---

# Policy Types

## Static Policy

Configured values.

Example

```yaml
max_open_positions: 10
```

---

## Dynamic Policy

Calculated at runtime.

Example

```
Portfolio Drawdown

>

10%
```

---

## Context-Aware Policy

Depends on runtime state.

Example

```
Only trade AI sector

during US market hours.
```

---

## Manual Policy

Requires human intervention.

Example

```
Trade Size > $1,000,000

↓

Approval Required
```

---

# Policy Repository

Policies are stored centrally.

Example

```text
Policy Repository

├── Trading

├── Portfolio

├── Risk

├── Operations

├── Compliance

└── Emergency
```

Policies become configuration, not code.

---

# Policy Versioning

Every trade records:

```
Policy Version

↓

Executed

↓

Replay

↓

Load Same Policy
```

Replay remains deterministic.

---

# Policy Events

Consumes

```
DecisionApproved

PortfolioUpdated

PositionClosed

RiskUpdated

ConfigurationChanged
```

Publishes

```
PolicyPassed

PolicyRejected

PolicyChanged

EmergencyTriggered
```

---

# Policy Repository Structure

Recommended package

```text
src/policy/

├── engine.py

├── evaluator.py

├── repository.py

├── registry.py

├── models.py

├── events.py

├── rules/

│   ├── trading.py

│   ├── portfolio.py

│   ├── risk.py

│   ├── compliance.py

│   └── emergency.py

└── versioning.py
```

---

# Relationship with Decision Engine

Decision Engine

↓

Recommendation

↓

Policy Engine

↓

Allowed?

↓

Risk Engine

Decision recommends.

Policy governs.

---

# Relationship with Risk Engine

Policy

```
Maximum Leverage = 5x
```

↓

Risk Engine

↓

Calculate

↓

PASS

Risk calculates.

Policy defines limits.

---

# Relationship with Position Manager

No direct mutation.

Policy may reject actions before positions are opened.

---

# Relationship with Workflow Engine

Workflow

↓

Policy Check

↓

Continue

or

↓

Stop Workflow

Policies become workflow gates.

---

# Relationship with Replay Engine

Replay loads:

- Policy version
- Rule configuration
- Evaluation results

Historical decisions remain reproducible.

---

# Emergency Mode

Highest-priority policy.

Example

```text
Emergency Activated

↓

Stop New Orders

↓

Cancel Pending Orders

↓

Keep Monitoring

↓

Notify User
```

Emergency mode bypasses normal evaluation order.

---

# Migration Strategy

## Phase 1

Hardcoded policies remain.

---

## Phase 2

Move configuration into Policy Repository.

---

## Phase 3

Introduce Policy Evaluator.

Shadow mode.

---

## Phase 4

Enable production policy evaluation.

---

## Phase 5

Introduce versioning.

---

## Phase 6

Workflow integration.

---

# Rollback Strategy

Feature flag

```text
policy_engine_enabled = false
```

Current configuration-driven validation continues.

---

# Testing Strategy

Policy Engine requires:

- Rule tests
- Boundary tests
- Regression tests
- Historical replay tests
- Policy version tests
- Emergency scenario tests

---

# Success Criteria

The Policy Engine migration is complete when:

- Business rules are centralized.
- Trading behavior no longer depends on hardcoded policy checks.
- Policy changes require configuration updates rather than code deployments.
- Historical policy versions are replayable.
- Emergency controls are unified.
- Governance is fully auditable.

---

# Risks

| Risk | Mitigation |
|------|------------|
| Rule conflicts | Priority ordering |
| Policy sprawl | Versioned repository |
| Hidden dependencies | Central evaluation pipeline |
| Runtime overhead | Lightweight rule evaluation |
| Incorrect configuration | Validation and schema checking |

---

# Future Evolution

Future capabilities include:

- Rule DSL (Domain-Specific Language)
- Web-based policy management
- Scheduled policy activation
- Multi-tenant policy sets
- Exchange-specific policies
- Strategy-specific policies
- Regulatory compliance packs
- Human approval workflows
- Dynamic policy simulation

---

# Example End-to-End Flow

```text
Market Signal

↓

Decision Engine

↓

Policy Engine

↓

PASS

↓

Risk Engine

↓

PASS

↓

Execution

↓

OMS

↓

Position Manager
```

If any policy fails:

```text
Decision

↓

Policy Engine

↓

REJECT

↓

DecisionRejected Event

↓

Journal

↓

Metrics

↓

User Notification
```

No execution occurs.

---

# Architectural Benefits

The Policy Engine separates **business governance** from **business logic**.

Instead of embedding operational rules across the codebase, all governance becomes centralized, versioned, and auditable.

This architecture provides:

- Centralized governance
- Declarative business rules
- Version-controlled policies
- Replay compatibility
- Easier compliance
- Runtime configurability
- Emergency controls
- Cleaner separation of concerns

Most importantly, the Policy Engine ensures that **strategy determines what Karsa wants to do, while policy determines what Karsa is allowed to do**.

This distinction makes the platform significantly easier to maintain, audit, and evolve without compromising deterministic execution.