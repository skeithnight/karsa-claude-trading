# C4 Model

**Document ID:** KARSA-ARCH-025  
**Title:** C4 Architecture Model  
**Version:** 1.0 (Draft)  
**Status:** Architecture Blueprint  
**Author:** Karsa Architecture Team  
**Last Updated:** July 2026

---

# Purpose

This document describes the Karsa architecture using the **C4 Model** developed by Simon Brown.

The C4 Model provides four levels of abstraction:

| Level | Purpose | Audience |
|--------|----------|----------|
| Level 1 | System Context | Business & Stakeholders |
| Level 2 | Container | Architects & Tech Leads |
| Level 3 | Component | Developers |
| Level 4 | Code | Implementation |

Unlike UML, C4 focuses on **clarity** rather than implementation details.

---

# Architecture Philosophy

Karsa is designed as a **Trading Operating System** rather than a simple trading bot.

The platform separates:

```text
Thinking

↓

Decision

↓

Execution

↓

Learning
```

Every C4 level reflects this separation.

---

# Level 1 — System Context

## Objective

Show how Karsa interacts with external actors and external systems.

---

## Context Diagram

```text
                              Trader
                                 │
                                 │ Telegram / Dashboard
                                 ▼
                      +------------------------+
                      |        KARSA           |
                      | Trading Operating Sys. |
                      +------------------------+
                         ▲       ▲        ▲
                         │       │        │
                         │       │        │
                 Binance API  AI Models  Notification
                         │       │        │
                         ▼       ▼        ▼
                  Exchange   Claude/Ollama Telegram
```

---

## External Actors

### Trader

Responsibilities

- Monitor positions
- Receive notifications
- Configure policies
- Review journals
- Start replay sessions

---

### Administrator

Responsibilities

- Configure runtime
- Deploy releases
- Activate kill switch
- Manage policies

---

## External Systems

### Exchange

Responsibilities

- Execute orders
- Return fills
- Stream market data

Examples

- Binance
- Bybit

---

### AI Providers

Responsibilities

- Research
- Analysis
- Summarization

Examples

- Claude
- OpenAI
- Ollama

---

### Notification Providers

Examples

- Telegram
- Email
- Slack

---

# Level 2 — Container Diagram

## Objective

Describe major deployable services.

---

```text
                 +-----------------------------------+
                 |            Dashboard              |
                 +-----------------------------------+
                              │
                              ▼
                 +-----------------------------------+
                 |           REST API                |
                 +-----------------------------------+

                              │

        ┌─────────────────────┼──────────────────────┐

        ▼                     ▼                      ▼

+----------------+   +----------------+   +----------------+
| Trading Runtime|   | Workflow Runtime|   | Agent Runtime  |
+----------------+   +----------------+   +----------------+
        │                     │                      │
        ▼                     ▼                      ▼
+----------------------------------------------------------+
|                  Event Bus (Redis Pub/Sub)               |
+----------------------------------------------------------+
        │                     │                      │

        ▼

+----------------+

| Position Manager|

+----------------+

        │

        ▼

+----------------+

| Exit Engine |

+----------------+

        │

        ▼

+----------------+

| OMS |

+----------------+

        │

        ▼

Exchange
```

---

## Containers

| Container | Responsibility |
|------------|----------------|
| Dashboard | User Interface |
| REST API | External API |
| Trading Runtime | Core trading |
| Workflow Runtime | Long-running processes |
| Agent Runtime | AI orchestration |
| Position Manager | Position ownership |
| Exit Engine | Exit decisions |
| OMS | Order lifecycle |
| Replay Engine | Historical replay |
| Memory Service | Knowledge retrieval |

---

# Infrastructure Containers

```text
                PostgreSQL

                Redis

                Event Store

                Object Storage

                Vector Database
```

---

# Level 3 — Component Diagram

## Trading Runtime

```text
                 Trading Runtime

        +-----------------------------+

        | Analyzer                    |

        | Decision Engine             |

        | Policy Engine               |

        | Risk Engine                 |

        | Execution                   |

        +-----------------------------+

                    │

                    ▼

              Event Bus
```

---

## Position Management

```text
            Position Manager

     +----------------------------+

     | Position Aggregate          |

     | Position Repository         |

     | Reconciliation              |

     | Position Event Publisher    |

     +----------------------------+
```

---

## Exit Engine

```text
               Exit Engine

      +----------------------------+

      | Stop Loss Strategy          |

      | Break Even Strategy         |

      | Partial Exit Strategy       |

      | ATR Trailing Strategy       |

      | Time Exit Strategy          |

      +----------------------------+
```

---

## Workflow Runtime

```text
             Workflow Engine

      +----------------------------+

      | Workflow Scheduler          |

      | Checkpoint Manager          |

      | Retry Handler               |

      | Event Consumer              |

      +----------------------------+
```

---

## Agent Runtime

```text
              Agent Runtime

      +----------------------------+

      | Agent Registry              |

      | Scheduler                   |

      | Executor                    |

      | Retry Manager               |

      | Prompt Manager              |

      +----------------------------+
```

---

## Replay Engine

```text
              Replay Engine

      +----------------------------+

      | Event Loader                |

      | Timeline Builder            |

      | State Restorer              |

      | Comparator                  |

      | Report Generator            |

      +----------------------------+
```

---

# Component Dependencies

```text
Analyzer

↓

Decision

↓

Policy

↓

Risk

↓

Execution

↓

OMS

↓

Position Manager

↓

Exit Engine
```

Dependencies only move forward.

---

# Level 4 — Code Model

Level 4 maps architecture to the codebase.

---

## Package Structure

```text
src/

├── agents/

├── analyzer/

├── decision/

├── execution/

├── exchange/

├── exit/

├── memory/

├── oms/

├── policy/

├── portfolio/

├── position/

├── replay/

├── risk/

├── workflow/

├── runtime/

├── shared/

└── infrastructure/
```

---

## Position Package

```text
position/

├── manager.py

├── aggregate.py

├── repository.py

├── events.py

├── models.py

├── reconciliation.py

└── service.py
```

---

## Exit Package

```text
exit/

├── engine.py

├── strategies/

│   ├── stop_loss.py

│   ├── break_even.py

│   ├── trailing.py

│   ├── partial_exit.py

│   └── time_exit.py

└── models.py
```

---

## Workflow Package

```text
workflow/

├── engine.py

├── scheduler.py

├── checkpoint.py

├── state_machine.py

├── repository.py

└── events.py
```

---

## Replay Package

```text
replay/

├── engine.py

├── loader.py

├── timeline.py

├── comparator.py

├── report.py

└── models.py
```

---

# Dependency Rules

Code dependencies must follow the same hierarchy.

```text
Presentation

↓

Application

↓

Domain

↓

Infrastructure
```

Never reverse the dependency.

---

# Deployment Mapping

| Container | Deployment |
|------------|------------|
| Dashboard | Web Server |
| REST API | FastAPI |
| Trading Runtime | Python Service |
| Workflow Engine | Python Service |
| Agent Runtime | Python Service |
| Replay Engine | Worker |
| PostgreSQL | Database |
| Redis | Cache / PubSub |

---

# Communication Model

| Interaction | Pattern |
|-------------|----------|
| UI → API | HTTP |
| Service → Service | API / Event |
| Business Events | Event Bus |
| Replay | Event Store |
| Database | Repository Pattern |

---

# C4 Dependency Matrix

| Level | Artifact |
|---------|----------|
| L1 | Business Context |
| L2 | Deployable Containers |
| L3 | Internal Components |
| L4 | Source Code Packages |

Each lower level refines the previous one.

---

# Mapping to Architecture Documents

| Document | C4 Level |
|-----------|----------|
| Executive Summary | L1 |
| Current Architecture | L1 |
| Runtime Architecture | L2 |
| Event Bus | L3 |
| Position Manager | L3 |
| Exit Engine | L3 |
| Decision Engine | L3 |
| Workflow Engine | L3 |
| Agent Runtime | L3 |
| Replay Engine | L3 |
| Code Mapping | L4 |

---

# Architectural Constraints

Every C4 level must preserve:

- Single ownership
- Deterministic execution
- Event-driven communication
- Replay compatibility
- AI isolation
- Business-first design

---

# Evolution Strategy

As Karsa evolves:

- Level 1 changes rarely.
- Level 2 changes occasionally.
- Level 3 evolves regularly.
- Level 4 evolves continuously.

This separation keeps architectural discussions independent of implementation details.

---

# Success Criteria

The C4 model is complete when:

- Every stakeholder understands Level 1.
- Every architect understands Level 2.
- Every developer understands Level 3.
- Every contributor can map Level 4 directly to the repository.
- Every implementation can be traced back to an architectural component.

---

# Summary

The C4 Model provides a structured view of Karsa across four levels of abstraction:

- **Level 1** explains the platform's role within the broader trading ecosystem.
- **Level 2** defines the deployable runtime containers.
- **Level 3** decomposes those containers into cohesive business components.
- **Level 4** maps the architecture directly to the source code structure.

Together with the Event Catalog, Domain Model, API Contracts, State Machines, and Architecture Rules, the C4 Model forms the architectural backbone of Karsa, enabling developers and architects to reason consistently about the system from business vision down to implementation.