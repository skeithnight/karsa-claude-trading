# Failure Scenarios

**Document ID:** KARSA-ARCH-018  
**Title:** Failure Scenarios & Recovery Strategy  
**Version:** 1.0 (Draft)  
**Status:** Architecture Contract  
**Author:** Karsa Architecture Team  
**Last Updated:** July 2026

---

# Purpose

This document defines how Karsa behaves when failures occur.

Unlike normal business flow documentation, this document focuses on:

- unexpected failures
- partial failures
- infrastructure failures
- business inconsistencies
- recovery procedures

The objective is **not to eliminate failures**, but to ensure every failure is:

- detectable
- recoverable
- observable
- replayable
- non-destructive

---

# Design Philosophy

Failures are inevitable.

A production trading platform must assume:

- exchanges fail
- Redis fails
- databases fail
- APIs timeout
- processes crash
- networks disconnect
- humans make mistakes

The architecture must continue operating safely.

---

# Failure Handling Principles

## Fail Safe

Never create unintended trades.

---

## Never Lose Money Silently

Every financial inconsistency must generate alerts.

---

## Idempotent Recovery

Recovery may execute multiple times without corrupting state.

---

## Event Before Recovery

Failures generate business events.

Recovery reacts to events.

---

## Manual Override

Every automated recovery must support human intervention.

---

# Failure Categories

```text
Failures

├── Exchange

├── Network

├── Infrastructure

├── Database

├── Runtime

├── Business

├── Workflow

├── AI

├── Configuration

└── Human
```

---

# Exchange Failures

---

## Exchange Timeout

Scenario

```
Order Submitted

↓

No Response
```

Detection

- Request timeout
- No acknowledgement
- Retry exceeded

Recovery

1. Query order status
2. Check exchange
3. Reconcile
4. Update OMS

Never resubmit immediately.

---

## Exchange Disconnect

Scenario

```
WebSocket Lost
```

Recovery

```
Reconnect

↓

Resubscribe

↓

Synchronize Positions

↓

Resume Runtime
```

Maximum retry count configurable.

---

## Partial Fill

Scenario

```
BUY 10

↓

Filled 6
```

Recovery

OMS remains authoritative.

Position Manager opens position using:

```
Filled Quantity
```

Remaining quantity continues normally.

---

## Duplicate Fill Notification

Scenario

Exchange sends:

```
Filled

Filled

Filled
```

Recovery

OMS ignores duplicate events using:

- orderId
- executionId

Idempotency required.

---

## Unknown Order Status

Scenario

```
Submit Order

↓

Timeout

↓

Unknown
```

Recovery

Never submit again.

Instead

```
Query Exchange

↓

Resolve Status

↓

Continue
```

---

# Position Failures

---

## Position Exists on Exchange but Not Locally

Detection

Reconciliation.

Recovery

```
Exchange

↓

Position Found

↓

Create Missing Position

↓

Publish PositionRecovered
```

---

## Local Position Missing

Scenario

Database corruption.

Recovery

Reload from exchange.

---

## Duplicate Position

Detection

Same symbol

Same side

Same position ID

Recovery

Freeze.

Manual review.

---

## Negative Position Size

Detection

Validation.

Recovery

Reject update.

Raise critical alert.

---

# Order Failures

---

## Order Rejected

Recovery

Publish

```
OrderRejected
```

No retry.

Decision ends.

---

## Cancel Failed

Recovery

Query exchange.

Determine actual status.

---

## Duplicate Submission

Recovery

Use request ID.

Reject duplicate.

---

# Exit Failures

---

## Stop Loss Not Updated

Scenario

Exchange rejects stop loss.

Recovery

Retry.

If failed:

```
Emergency Alert
```

---

## Exit Executed Twice

Detection

Position version mismatch.

Recovery

Ignore second request.

---

## Trailing Stop Failed

Recovery

Fallback

```
Previous Stop Loss
```

Position remains protected.

---

# Workflow Failures

---

## Workflow Crash

Recovery

Load checkpoint.

Resume.

---

## Workflow Timeout

Recovery

Mark

```
FAILED
```

Alert operator.

---

## Workflow Deadlock

Detection

No progress.

Recovery

Cancel.

Restart from checkpoint.

---

# Agent Failures

---

## AI Timeout

Recovery

Retry.

Maximum retries configurable.

---

## AI Hallucination

Detection

Schema validation fails.

Recovery

Reject response.

Retry.

---

## AI Provider Unavailable

Recovery

Fallback model.

If unavailable:

Continue without AI.

---

## Invalid AI Output

Example

```
BUY EVERYTHING
```

Recovery

Schema validation.

Reject.

Never reach execution.

---

# Decision Failures

---

## Conflicting Recommendations

Example

Analyzer

```
BUY
```

Portfolio

```
SELL
```

Recovery

Decision Engine applies priority.

---

## No Recommendation

Recovery

Decision

```
IGNORE
```

---

# Policy Failures

---

## Policy Repository Unavailable

Recovery

Cached policy.

Read-only mode.

---

## Invalid Policy

Recovery

Reject deployment.

Previous version remains active.

---

# Replay Failures

---

## Missing Event

Recovery

Replay stops.

Generate incomplete report.

---

## Event Ordering Violation

Recovery

Reject replay.

Alert developer.

---

# Memory Failures

---

## Memory Store Unavailable

Recovery

Trading continues.

Memory writes queued.

---

## Vector Store Failure

Recovery

Disable semantic search.

Trading unaffected.

---

# Database Failures

---

## Database Offline

Recovery

Trading suspended.

No position mutation allowed.

---

## Database Slow

Recovery

Circuit breaker.

Backoff.

---

## Transaction Failure

Recovery

Rollback.

Retry.

---

# Redis Failures

---

## Redis Unavailable

Recovery

Reconnect.

If unavailable:

Disable event streaming.

Continue deterministic execution.

---

## Lost Pub/Sub Event

Recovery

Replay from Event Store.

---

# Configuration Failures

---

## Invalid Configuration

Recovery

Reject startup.

---

## Missing Secret

Recovery

Critical failure.

Do not start runtime.

---

## Feature Flag Conflict

Recovery

Disable conflicting feature.

---

# Runtime Failures

---

## Process Crash

Recovery

```text
Restart

↓

Load Positions

↓

Replay Events

↓

Resume
```

---

## Out of Memory

Recovery

Graceful shutdown.

Restart.

---

## Disk Full

Recovery

Suspend journaling.

Continue trading if state persistence remains safe.

Alert immediately.

---

# Network Failures

---

## Internet Lost

Recovery

Retry.

No new trades.

Maintain existing positions.

---

## DNS Failure

Recovery

Retry with exponential backoff.

---

# Monitoring Failures

---

## Metrics Down

Recovery

Continue runtime.

Buffer metrics.

---

## Logging Failure

Recovery

Fallback local logs.

---

# Emergency Scenarios

---

## Kill Switch

Actions

```
Reject New Trades

↓

Cancel Pending Orders

↓

Keep Monitoring Positions

↓

Notify Users
```

---

## Exchange Maintenance

Actions

```
Suspend Execution

↓

Continue Monitoring

↓

Resume Automatically
```

---

## Portfolio Drawdown

Trigger

```
Daily Loss > Threshold
```

Actions

```
Stop New Positions

↓

Notify

↓

Policy Lock
```

---

# Startup Recovery

Startup sequence

```text
Load Configuration

↓

Load Policies

↓

Load Open Positions

↓

Synchronize Exchange

↓

Resume Workflows

↓

Resume Runtime
```

Every step validates consistency.

---

# Recovery Priority

Priority order

```text
1. Protect Capital

2. Synchronize Positions

3. Restore Orders

4. Resume Workflows

5. Resume Agents

6. Resume Research
```

Money always comes before intelligence.

---

# Incident Severity

| Level | Description | Action |
|--------|-------------|--------|
| P0 | Capital at risk | Immediate halt |
| P1 | Incorrect trading behavior | Suspend execution |
| P2 | Component unavailable | Automatic recovery |
| P3 | Degraded performance | Monitor |
| P4 | Cosmetic issue | Log only |

---

# Automatic Recovery Matrix

| Failure | Auto Recover | Manual |
|----------|--------------|--------|
| Exchange Timeout | ✅ | |
| WebSocket Disconnect | ✅ | |
| AI Timeout | ✅ | |
| Replay Failure | ✅ | |
| Memory Failure | ✅ | |
| Database Offline | | ✅ |
| Duplicate Position | | ✅ |
| Policy Corruption | | ✅ |
| Negative Position | | ✅ |
| Capital Mismatch | | ✅ |

---

# Circuit Breakers

The following components should implement circuit breakers:

- Exchange API
- Database
- Redis
- AI Provider
- Notification Service

When thresholds are exceeded:

```text
Open Circuit

↓

Reject Requests

↓

Cooldown

↓

Half Open

↓

Recovered?
```

---

# Failure Events

Every failure publishes an event.

Examples

```
ExchangeDisconnected

DatabaseUnavailable

WorkflowFailed

ReplayFailed

AgentFailed

PolicyRejected

RiskRejected
```

These events are consumed by:

- Monitoring
- Dashboard
- Replay
- Alerting

---

# Post-Mortem Requirements

Every production incident should generate:

- Timeline
- Root Cause
- Trigger Event
- Recovery Action
- Impact Analysis
- Preventive Action
- Replay Session ID

No incident should be closed without a documented post-mortem.

---

# Validation Checklist

Before deploying a new feature, verify:

- What happens if it crashes?
- Can it recover automatically?
- Is the operation idempotent?
- Is state preserved?
- Are events replayable?
- Can operators intervene?
- Does it protect capital first?

If any answer is **No**, the feature is not production-ready.

---

# Summary

Failure handling is a first-class architectural concern in Karsa.

Rather than assuming success, every component is designed to:

- detect failures
- contain failures
- recover safely
- preserve deterministic state
- protect capital
- remain observable
- support replay and post-mortem analysis

This philosophy allows Karsa to operate reliably in the unpredictable environment of real-world algorithmic trading while minimizing operational risk and ensuring that failures become opportunities for continuous improvement rather than catastrophic system events.