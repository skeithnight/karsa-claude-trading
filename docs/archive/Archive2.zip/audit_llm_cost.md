# LLM Token & Cost Efficiency Audit

Because the Autonomous Session Manager (ASM) runs every 15 minutes, scanning multiple coins and asking an LLM (Claude/Gemini) to evaluate them, API token usage scales exponentially. 

### The Verdict: Massive Prompt Bloat
The current payload structure is sending an excessive amount of raw, uncompressed data to the LLM. 

### Key Findings

**1. Excessive Candle History (`crypto_analyst.py`)**
Currently, the analyst fetches up to 200 candles of 4H data:
```python
ohlcv = await self.mcp.get_ohlcv(ticker, "CRYPTO", timeframe="4h", limit=200)
```
Each candle contains Open, High, Low, Close, Volume, and Timestamp. 
200 candles = 1,200 data points *per evaluation*. 
For the LLM to confirm a breakout, it really only needs the last 30-50 candles. The remaining 150 candles are purely wasted input tokens.

**2. JSON Formatting Overhead**
The raw JSON format injects repeated keys (`"open": ... "high": ...`) for every single candle. This inflates the token count by roughly 40% compared to a dense CSV format.

**3. Full Market Snapshots**
The analyst is handed a full `market_snapshot_card` containing global data, even if it is only evaluating a single coin.

### Recommendation: "Truncate & Compress"
**Action 1**: Drop the `limit=200` to `limit=50` for OHLCV fetches. The deterministic TA tools (like RSI/MACD) calculate using 200 candles behind the scenes, but the LLM only needs to *see* the recent 50.
**Action 2**: Convert OHLCV JSON payloads into dense CSV format before injecting them into the LLM prompt. This alone will reduce input token costs by thousands of tokens per hour.
