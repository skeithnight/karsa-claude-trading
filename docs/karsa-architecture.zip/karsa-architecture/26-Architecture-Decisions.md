# Architecture Decision Records (ADR)

**Document ID:** KARSA-ARCH-026  
**Title:** Architecture Decision Records  
**Version:** 1.0 (Draft)  
**Status:** Living Document  
**Author:** Karsa Architecture Team  
**Last Updated:** July 2026

---

# Purpose

This document records the **major architectural decisions** made during the evolution of Karsa.

Unlike design documents that explain *what* the architecture is, Architecture Decision Records (ADRs) explain:

- Why a decision was made
- Which alternatives were considered
- Why they were rejected
- What consequences the decision introduces

These records preserve architectural knowledge for future contributors.

---

# ADR Lifecycle

```text
Proposed

↓

Accepted

↓

Implemented

↓

Superseded

↓

Deprecated
```

Every significant architectural decision should have an ADR.

---

# ADR Template

Every ADR follows the same structure.

```text
Title

Status

Context

Decision

Alternatives

Consequences

Migration

Review Date
```

---

# ADR-001 — Event-Driven Architecture

**Status**

Accepted

---

## Context

The current architecture relies heavily on direct service-to-service calls.

Example

```text
Execution

↓

Telegram

↓

Journal

↓

Metrics
```

As the platform grows:

- coupling increases
- new integrations require code changes
- replay becomes difficult
- testing becomes more complex

---

## Decision

Adopt an **Event Bus** for business communication.

Components publish immutable business events.

Subscribers react independently.

Example

```text
PositionOpened

↓

Event Bus

↓

Telegram

Journal

Metrics

Replay
```

---

## Alternatives Considered

### Direct Service Calls

Pros

- Simple
- Easy to understand

Cons

- Tight coupling
- Difficult replay
- Hard to extend

---

### Kafka

Pros

- Enterprise scale

Cons

- Operational complexity
- Overkill for current deployment

---

### Redis Pub/Sub

Pros

- Lightweight
- Already part of infrastructure
- Sufficient throughput

Cons

- Not persistent

Chosen for Phase 1.

---

## Consequences

Positive

- Loose coupling
- Easier extensibility
- Replay support
- Cleaner architecture

Negative

- Eventual consistency
- More infrastructure
- Event catalog required

---

## Migration

Phase 1

Introduce Event Bus without changing business logic.

---

# ADR-002 — Position Manager as Aggregate Owner

**Status**

Accepted

---

## Context

Position state is currently modified by multiple modules.

Examples

- Execution
- Trailing Stop
- Profit Lock
- Synchronization

This creates inconsistent ownership.

---

## Decision

Introduce **Position Manager** as the single owner of all position state.

Every position mutation must go through Position Manager.

---

## Alternatives

### Distributed Ownership

Rejected.

Creates race conditions.

---

### Database Ownership

Rejected.

Databases store state.

They do not own business logic.

---

## Consequences

Positive

- Single source of truth
- Replay consistency
- Simplified reconciliation

Negative

- Initial migration effort

---

## Migration

Shadow mode.

Then migrate write operations incrementally.

---

# ADR-003 — AI Separation

**Status**

Accepted

---

## Context

LLMs provide valuable reasoning.

However,

LLMs are:

- probabilistic
- non-deterministic
- occasionally inconsistent

Financial execution requires deterministic behavior.

---

## Decision

Separate architecture into:

```text
Thinking Layer

↓

Decision

↓

Execution Layer
```

AI remains in the Thinking Layer.

Execution remains deterministic.

---

## Alternatives

### AI Executes Trades

Rejected.

Unacceptable operational risk.

---

### Human Approval for Every Trade

Rejected.

Does not support automation.

---

## Consequences

Positive

- Safe automation
- Explainability
- Deterministic execution

Negative

- Additional orchestration layer

---

# ADR-004 — Replay-Driven Validation

**Status**

Accepted

---

## Context

Regression testing alone cannot validate trading behavior.

Historical correctness matters.

---

## Decision

Introduce Replay Engine.

Every major architectural change must be validated through replay.

---

## Alternatives

### Unit Tests Only

Rejected.

Cannot validate historical behavior.

---

### Paper Trading Only

Rejected.

Too slow.

Limited historical coverage.

---

## Consequences

Positive

- Historical regression
- Safer migration
- Better debugging

Negative

- Event Store required

---

# ADR-005 — Policy Engine

**Status**

Accepted

---

## Context

Business rules are scattered across services.

Examples

- leverage limits
- trading hours
- exposure limits

---

## Decision

Move governance into Policy Engine.

Policies become versioned configuration.

---

## Alternatives

### Hardcoded Rules

Rejected.

Difficult to evolve.

---

### Database Triggers

Rejected.

Business logic belongs in the domain layer.

---

## Consequences

Positive

- Centralized governance
- Easier auditing
- Runtime configuration

---

# ADR-006 — Workflow Engine

**Status**

Accepted

---

## Context

Long-running business processes are becoming increasingly complex.

Examples

- Research
- Journal generation
- Trade lifecycle

---

## Decision

Introduce Workflow Engine.

Workflow coordinates.

Services execute.

---

## Alternatives

### Scheduler Only

Rejected.

No persistence.

---

### State Machines Everywhere

Rejected.

State machines model entities, not business processes.

---

## Consequences

Positive

- Resumable workflows
- Retry
- Visibility

---

# ADR-007 — Event Sourcing for Replay

**Status**

Accepted

---

## Context

Logs cannot reconstruct complete business history.

---

## Decision

Business events become replay source.

Replay never parses logs.

---

## Alternatives

### Log Replay

Rejected.

Logs are implementation details.

---

### Database Snapshots

Rejected.

Missing business intent.

---

## Consequences

Positive

- Deterministic replay
- Better debugging

---

# ADR-008 — Repository Pattern

**Status**

Accepted

---

## Context

Direct database access creates coupling.

---

## Decision

Business services interact through repositories.

Repositories isolate persistence.

---

## Alternatives

### Active Record

Rejected.

Business logic leaks into persistence.

---

### Raw SQL Everywhere

Rejected.

Maintenance burden.

---

## Consequences

Positive

- Cleaner testing
- Storage independence

---

# ADR-009 — Feature Flag Migration

**Status**

Accepted

---

## Context

Large production migrations are risky.

---

## Decision

Every major architectural component must support feature flags.

Examples

- Event Bus
- Replay
- Workflow
- Position Manager

---

## Alternatives

### Big Bang Deployment

Rejected.

Operational risk too high.

---

## Consequences

Positive

- Rollback
- Progressive rollout
- Safer migration

---

# ADR-010 — Single Aggregate Ownership

**Status**

Accepted

---

## Context

Multiple services writing the same aggregate leads to inconsistency.

---

## Decision

Each aggregate has one authoritative owner.

Examples

| Aggregate | Owner |
|-----------|-------|
| Position | Position Manager |
| Order | OMS |
| Decision | Decision Engine |
| Workflow | Workflow Engine |

---

## Alternatives

Shared ownership.

Rejected.

---

## Consequences

Positive

- Consistency
- Simpler reasoning
- Clear responsibility

---

# ADR Dependency Graph

```text
ADR-001

Event Bus

↓

ADR-002

Position Manager

↓

ADR-010

Aggregate Ownership

↓

ADR-004

Replay

↓

ADR-006

Workflow

↓

ADR-003

AI Separation

↓

ADR-005

Policy Engine
```

Each decision builds on previous decisions.

---

# Decision Matrix

| ADR | Decision | Status |
|------|----------|--------|
| ADR-001 | Event Bus | Accepted |
| ADR-002 | Position Manager | Accepted |
| ADR-003 | AI Separation | Accepted |
| ADR-004 | Replay Engine | Accepted |
| ADR-005 | Policy Engine | Accepted |
| ADR-006 | Workflow Engine | Accepted |
| ADR-007 | Event Sourcing | Accepted |
| ADR-008 | Repository Pattern | Accepted |
| ADR-009 | Feature Flags | Accepted |
| ADR-010 | Aggregate Ownership | Accepted |

---

# Governance

Every new architectural decision must answer:

- What problem does it solve?
- Why is the current architecture insufficient?
- What alternatives were considered?
- Why were they rejected?
- What are the operational consequences?
- How will it be migrated?
- How will it be rolled back?

No significant architectural change should be implemented without an accompanying ADR.

---

# Review Process

Architecture decisions should be reviewed when:

- introducing a new bounded context
- adding a new runtime component
- changing ownership
- changing deployment topology
- modifying execution flow
- introducing new infrastructure dependencies

Existing ADRs should never be rewritten. If a decision changes, create a new ADR that supersedes the previous one.

---

# Summary

Architecture Decision Records capture the reasoning behind Karsa's most important architectural choices.

They provide:

- Historical context
- Engineering rationale
- Alternative analysis
- Migration guidance
- Governance

Together with the Architecture Rules, Domain Model, C4 Model, and Migration Strategy, ADRs ensure that future architectural evolution remains intentional, explainable, and consistent rather than driven by short-term implementation convenience.