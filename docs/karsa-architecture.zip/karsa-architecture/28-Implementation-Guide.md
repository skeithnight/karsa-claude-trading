# Implementation Guide

**Document ID:** KARSA-ARCH-028  
**Title:** Implementation Guide & Migration Playbook  
**Version:** 1.0 (Draft)  
**Status:** Implementation Standard  
**Author:** Karsa Architecture Team  
**Last Updated:** July 2026

---

# Purpose

This document describes **how the target architecture should be implemented**.

Unlike the architecture documents that describe *what* the system should become, this guide explains:

- how to implement it safely
- how to migrate incrementally
- how to validate each phase
- how to avoid production regressions

The primary goal is **continuous evolution without disrupting production trading**.

---

# Guiding Principles

The implementation strategy follows four principles.

## 1. No Big Bang

Never replace the architecture in a single release.

Every migration must be incremental.

---

## 2. Production First

Production stability is always more important than architectural purity.

---

## 3. Backward Compatible

Every phase must continue supporting the current production system.

---

## 4. Replay Before Release

Any architectural change affecting trading logic must pass replay validation before deployment.

---

# Migration Strategy

The implementation is divided into **nine phases**.

```text
Current Production

↓

Phase 1

Foundation

↓

Phase 2

Event Bus

↓

Phase 3

Position Manager

↓

Phase 4

Exit Engine

↓

Phase 5

Decision Engine

↓

Phase 6

Workflow Engine

↓

Phase 7

Replay

↓

Phase 8

Agent Runtime

↓

Phase 9

Production Optimization
```

Each phase is independently deployable.

---

# Phase 1 — Foundation

## Objective

Prepare the codebase without changing runtime behavior.

---

## Deliverables

- Shared interfaces
- Common models
- Domain events
- Event contracts
- Repository interfaces
- Feature flag framework
- Dependency cleanup

---

## Validation

- Build passes
- Unit tests pass
- No runtime behavior changes

---

## Rollback

No rollback required.

No business logic changed.

---

# Phase 2 — Event Bus

## Objective

Introduce event-driven communication.

---

## Current

```text
Execution

↓

Telegram

↓

Metrics

↓

Journal
```

---

## Target

```text
Execution

↓

Event Bus

↓

Subscribers
```

---

## Deliverables

- Event Publisher
- Event Subscriber
- Event Registry
- Event Versioning

---

## Validation

- Events published
- Subscribers receive events
- Legacy flow unchanged

---

## Feature Flag

```
event_bus_enabled
```

Default

```
false
```

---

# Phase 3 — Position Manager

## Objective

Centralize ownership of position state.

---

## Current

Multiple services update positions.

---

## Target

```text
Execution

↓

Position Manager

↓

Repository
```

---

## Deliverables

- Position Aggregate
- Position Repository
- Reconciliation
- Position Events

---

## Validation

- Position replay
- Exchange reconciliation
- Historical comparison

---

## Rollback

Disable feature flag.

Resume legacy implementation.

---

# Phase 4 — Exit Engine

## Objective

Consolidate all exit logic.

---

## Current

Exit logic exists in multiple modules.

---

## Target

```text
Exit Engine

├── Stop Loss

├── Break Even

├── Trailing

├── Partial Exit

└── Time Exit
```

---

## Deliverables

- Strategy interface
- Exit orchestration
- Strategy registry

---

## Validation

Replay

Historical exits must match production.

---

# Phase 5 — Decision Engine

## Objective

Separate decision making from execution.

---

## Current

Analyzer contains business decisions.

---

## Target

```text
Analyzer

↓

Decision Engine

↓

Policy

↓

Risk

↓

Execution
```

---

## Deliverables

- Decision Aggregate
- Confidence scoring
- Decision explanation
- Decision events

---

## Validation

Decision comparison.

---

# Phase 6 — Workflow Engine

## Objective

Introduce orchestration.

---

## Deliverables

- Workflow runtime
- Checkpoints
- Retry
- Resume
- Timeout handling

---

## Validation

Recovery tests.

---

# Phase 7 — Replay Engine

## Objective

Enable deterministic replay.

---

## Deliverables

- Event loader
- Timeline reconstruction
- Comparison engine
- Replay report

---

## Validation

Replay historical trades.

Expected

```
Replay == Production
```

---

# Phase 8 — Agent Runtime

## Objective

Introduce AI orchestration.

---

## Scope

- Research
- Journal
- Advisor

---

## Not Included

- Execution
- OMS
- Position updates

---

## Validation

Shadow mode only.

---

# Phase 9 — Production Optimization

## Objective

Optimize performance and operations.

---

## Deliverables

- Monitoring
- Replay dashboards
- Health monitoring
- Auto recovery
- Resource optimization

---

# Feature Flag Strategy

Every architectural change requires a feature flag.

| Feature | Flag |
|----------|------|
| Event Bus | `event_bus_enabled` |
| Position Manager | `position_manager_enabled` |
| Exit Engine | `exit_engine_enabled` |
| Replay | `replay_enabled` |
| Workflow | `workflow_enabled` |
| Agent Runtime | `agent_runtime_enabled` |

Feature flags enable instant rollback.

---

# Branch Strategy

```text
main

↓

release

↓

feature/*
```

Architecture work should be isolated in dedicated feature branches.

---

# Pull Request Requirements

Every PR must include:

- Architecture impact
- Updated documentation
- Unit tests
- Replay validation
- Rollback plan

---

# Code Review Checklist

Reviewers verify:

- Architecture Rules followed
- Aggregate ownership maintained
- No forbidden dependencies
- API contracts respected
- Events documented
- State machines updated

---

# Development Workflow

```text
Requirement

↓

Architecture Review

↓

ADR

↓

Implementation

↓

Unit Tests

↓

Replay Validation

↓

Code Review

↓

Merge
```

---

# Testing Strategy Per Phase

| Phase | Validation |
|--------|------------|
| Foundation | Unit Tests |
| Event Bus | Integration Tests |
| Position Manager | Replay |
| Exit Engine | Historical Exit Replay |
| Decision Engine | Decision Comparison |
| Workflow | Recovery Tests |
| Replay | Replay Regression |
| Agent Runtime | Shadow Mode |
| Optimization | Performance Tests |

---

# Deployment Workflow

```text
Build

↓

Unit Tests

↓

Integration Tests

↓

Replay

↓

Paper Trading

↓

Shadow Deployment

↓

Production
```

---

# Rollback Strategy

Every deployment must support rollback.

Example

```text
New Feature

↓

Unexpected Behaviour

↓

Disable Feature Flag

↓

Resume Legacy Flow
```

Rollback must not require code changes.

---

# Production Validation

Every deployment verifies:

- Position consistency
- Order consistency
- Replay validation
- Dashboard health
- Exchange synchronization

---

# Replay Validation

Replay is mandatory for:

- Position changes
- Exit logic
- Decision logic
- Policy changes

Replay must produce identical business outcomes.

---

# Monitoring During Rollout

Monitor:

- Orders
- Positions
- Event throughput
- Replay differences
- Latency
- Error rate

---

# Migration Gates

Every phase passes:

```
Development

↓

QA

↓

Paper Trading

↓

Shadow

↓

Production
```

No phase skips validation.

---

# Coding Standards

Developers must:

- Follow Architecture Rules
- Respect aggregate ownership
- Publish business events
- Separate commands from queries
- Avoid direct infrastructure coupling

---

# Dependency Injection

All services should depend on interfaces.

Never instantiate infrastructure directly.

---

# Event Versioning

Business events are immutable.

Breaking changes require:

```
PositionOpened.v2
```

Never modify published contracts.

---

# API Versioning

Breaking changes require:

```
/v2
```

Existing clients continue using previous versions.

---

# Documentation Requirements

Every new feature updates:

- Architecture Rules
- Event Catalog
- API Contracts
- State Machine
- Sequence Diagram
- Testing Strategy

Documentation is part of the implementation.

---

# Production Checklist

Before enabling a feature:

- Unit tests pass
- Integration tests pass
- Replay matches production
- Feature flag enabled
- Monitoring configured
- Rollback verified
- Documentation updated

---

# Anti-Patterns

Avoid:

- Big Bang rewrites
- Multiple aggregate owners
- Direct database writes
- Business logic in controllers
- AI executing trades
- Hidden feature flags
- Breaking event contracts

---

# Team Responsibilities

| Role | Responsibility |
|------|----------------|
| Architect | Design & ADRs |
| Platform Engineer | Infrastructure |
| Backend Engineer | Services |
| QA Engineer | Replay & Regression |
| DevOps | Deployment |
| Trading Engineer | Business Validation |

---

# Success Metrics

The implementation is successful when:

- Every phase is independently deployable.
- Rollback requires only feature flag changes.
- Replay validates every trading change.
- Production behavior remains stable throughout migration.
- No architectural rules are violated.
- New engineers can implement features without introducing architectural drift.

---

# Long-Term Evolution

After the nine migration phases are complete, the platform should continue evolving through the same governance process:

```text
Requirement

↓

Architecture Review

↓

ADR

↓

Implementation

↓

Replay Validation

↓

Production

↓

Post-Mortem

↓

Continuous Improvement
```

Architecture is never considered "finished"; it is continuously refined while preserving compatibility and operational safety.

---

# Summary

This Implementation Guide provides the execution roadmap for evolving Karsa from its current architecture into the target architecture.

By combining:

- incremental migration,
- feature flags,
- replay validation,
- architecture governance,
- deterministic testing,
- and production-first deployment,

the platform can modernize safely without disrupting live trading operations.

This document should serve as the primary reference for all implementation work and should be consulted before introducing any new architectural component or modifying an existing one.